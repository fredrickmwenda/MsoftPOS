<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Http\Request;

use App\Http\Controllers\AccountsController;
use App\Http\Controllers\ApprovalController;
use App\Http\Controllers\AddonInstallController;
use App\Http\Controllers\AdjustmentController;
use App\Http\Controllers\AdminPolicyController;
use App\Http\Controllers\AIAssistantController;
use App\Http\Controllers\AIConversationController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\BillerController;
use App\Http\Controllers\BrandController;
use App\Http\Controllers\CashRegisterController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\ClientAutoUpdateController;
use App\Http\Controllers\CouponController;
use App\Http\Controllers\CurrencyController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CustomerGroupController;
use App\Http\Controllers\CustomFieldController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\DeliveryController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\DeveloperSectionController;
use App\Http\Controllers\DiscountController;
use App\Http\Controllers\DiscountPlanController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ExpenseCategoryController;
use App\Http\Controllers\ExpenseController;
use App\Http\Controllers\GiftCardController;
use App\Http\Controllers\CourierController;
use App\Http\Controllers\HirePurchaseController;
use App\Http\Controllers\HolidayController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\MoneyTransferController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\PayrollController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\PurchaseController;
use App\Http\Controllers\QuotationController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\ReturnController;
use App\Http\Controllers\ReturnPurchaseController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\SaleController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\StockCountController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\TableController;
use App\Http\Controllers\TaxController;
use App\Http\Controllers\TransferController;
use App\Http\Controllers\UnitController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\WarehouseController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

// --- NEW USE STATEMENTS ADDED BELOW ---
use App\Http\Controllers\Auth\CustomerAuthController;
use App\Http\Controllers\Customer\DashboardController as CustomerDashboardController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\Customer\WishlistController;
use App\Http\Controllers\DamageStockController;
use App\Http\Controllers\DesignationController;
use App\Http\Controllers\HR\LeaveController;
use App\Http\Controllers\LeaveController as ControllersLeaveController;
use App\Http\Controllers\LeaveTypeController;
use App\Http\Controllers\OvertimeController;
use App\Http\Controllers\PaymentGatewayController;
use App\Http\Controllers\SaleAgentController;
use App\Http\Controllers\SaleExchangeController;
use App\Http\Controllers\ShiftController;
use App\Http\Controllers\SmsTemplateController;
use App\Http\Controllers\StructuredPromptController;
use App\Http\Controllers\WhatsappController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\HRMController;
use App\Http\Controllers\PolicyController;
use App\Http\Controllers\SalaryTemplateController;
use App\Http\Controllers\PayrollPaymentController;
use App\Http\Controllers\SocialMediaController;


// ---------------------------------------

Route::get('migrate', function() {
    Artisan::call('migrate');
});

// Your original shop index
// Route::get('/', [\App\Http\Controllers\StorefrontController::class, 'index'])->name('shop.index');


Route::get('clear',function() {
    Artisan::call('optimize:clear');
    return redirect()->back();
});
//storage link
Route::get('storage-link', function() {
    Artisan::call('storage:link');
   // return to the previous page
    return redirect()->back();
});


Route::get('/customer-display', function() {
    $general_setting = \App\Models\GeneralSetting::latest()->first();
    $currency = \App\Models\Currency::where('is_active', true)->first();
    return view('backend.sale.customer-display', compact('general_setting', 'currency'));
})->name('customer.display');


Route::get('stock-count/products',[StockCountController::class, 'getProducts'])->name('stock-count.products');
Route::get('stock-count/batches',[StockCountController::class, 'getBatches'])->name('stock-count.batches');



Route::get('update-coupon', [CouponController::class, 'updateCoupon']);

Route::get('auto-update-dashboard', [DashboardController::class, 'index'])->name('dashboard');

// Auto Update
Route::group(['prefix' => 'developer-section'], function () {
    Route::controller(DeveloperSectionController::class)->group(function () {
        Route::get('/', 'index')->name('developer-section.index');
        Route::post('/', 'submit')->name('developer-section.submit');
        Route::post('/bug-update-setting', 'bugUpdateSetting')->name('bug-update-setting.submit');
        Route::post('/version-upgrade-setting', 'versionUpgradeSetting')->name('version-upgrade-setting.submit');
     });
});

Route::controller(ClientAutoUpdateController::class)->group(function () {
    Route::get('/new-release', 'newVersionReleasePage')->name('new-release');
    Route::get('/bugs', 'bugUpdatePage')->name('bug-update-page');
    // Action on Client server
    Route::post('version-upgrade', 'versionUpgrade')->name('version-upgrade');
    Route::post('bug-update', 'bugUpdate')->name('bug-update');
});
Route::get('/documentation', [HomeController::class, 'documentation']);
//Auth::routes();


Route::get('delete-account', [\App\Http\Controllers\DeleteAccountRequestController::class, 'show'])->name('delete-account');
Route::post('delete-account', [\App\Http\Controllers\DeleteAccountRequestController::class, 'submit'])->name('delete-account.submit');

// // ─── Admin login routes ───────────────────────────────────────────
Route::get('login',  [App\Http\Controllers\Auth\LoginController::class, 'showLoginForm'])->name('login');
Route::post('login', [App\Http\Controllers\Auth\LoginController::class, 'login'])->name('login.post');
Route::post('logout', [App\Http\Controllers\Auth\LoginController::class, 'logout'])->name('logout');







Route::group(['middleware' => 'auth'], function() {
    Route::controller(HomeController::class)->group(function () {
        Route::get('home', 'home');
    });
});




Route::middleware('ecommerce')->group(function () {

    Route::get('/', [StorefrontController::class, 'index'])->name('shop.index');
    Route::get('/all-products', [StorefrontController::class, 'viewAllProducts'])->name('all.products');
    Route::get('/product/{id}', [StorefrontController::class, 'show'])->name('products.show');

    Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
    Route::post('/cart/add/{id}', [CartController::class, 'add'])->name('cart.add');
    Route::post('/cart/update', [CartController::class, 'update'])->name('cart.update');
    Route::get('/cart/remove/{id}', [CartController::class, 'remove'])->name('cart.remove');

    Route::post('/checkout', [CartController::class, 'checkout'])->name('checkout.process');
    Route::get('/checkout/paystack/callback', [CartController::class, 'paystackCallback'])->name('checkout.paystack.callback');

    Route::get('/track-order', [CartController::class, 'trackOrder'])->name('track.order');
    Route::post('/track-order', [CartController::class, 'trackOrder'])->name('track.order.search');

    Route::get('/contact-us', [ContactController::class, 'index'])->name('contact.us');
    Route::post('/contact-us', [ContactController::class, 'store'])->name('contact.us.store');

    // Customer auth + portal — hide the whole customer-facing side too
    Route::get('/customer/login', [CustomerAuthController::class, 'showLoginForm'])->name('customer.login');
    Route::post('/customer/login', [CustomerAuthController::class, 'login'])->name('customer.login.post');
    Route::get('/customer/register', [CustomerAuthController::class, 'showRegistrationForm'])->name('customer.register');
    Route::post('/customer/register', [CustomerAuthController::class, 'register'])->name('customer.register.post');


    Route::middleware('auth:customer')->group(function () {
        Route::get('/customer/dashboard', [CustomerDashboardController::class, 'index'])->name('customer.dashboard');
        Route::get('/customer/wishlist', [WishlistController::class, 'index'])->name('customer.wishlist');
        Route::post('/wishlist/add/{productId}', [WishlistController::class, 'store'])->name('wishlist.add');
        Route::get('/wishlist/remove/{id}', [WishlistController::class, 'destroy'])->name('wishlist.remove');
        Route::post('/customer/logout', [CustomerAuthController::class, 'logout'])->name('customer.logout');
        Route::get('/customer/orders', [CustomerDashboardController::class, 'orders'])->name('customer.orders');
        Route::get('/customer/orders/{sale}', [CustomerDashboardController::class, 'showOrder'])->name('customer.orders.show');
        Route::get('/customer/orders/{sale}/confirmation', [CustomerDashboardController::class, 'orderConfirmation'])->name('customer.orders.confirmation');
    });

    Route::get('/policy',            [PolicyController::class, 'index'])->name('policy.index');
    Route::get('/policy/{policy}',   [PolicyController::class, 'show'])->name('policy.show');
});

// ==========================================
// PAYMENT GATEWAY — PUBLIC ROUTES
// (no auth — must be reachable by Paystack's servers)
// ==========================================
Route::prefix('payment')->group(function () {
    // Browser redirect-back after Paystack authorization
    Route::get ('{gateway}/callback', [PaymentGatewayController::class, 'callback'])->name('payment.callback');

    // Customer polling for transaction status
    Route::get ('{gateway}/status',   [PaymentGatewayController::class, 'queryStatus'])->name('payment.status');
});

// Webhook — server-to-server, no session/CSRF. Excluded from CSRF below.
Route::post('payment/{gateway}/webhook', [PaymentGatewayController::class, 'callback'])->name('payment.webhook');;

Route::group(['middleware' => ['auth', 'common', 'active']], function() {
    Route::controller(HomeController::class)->group(function () {
        Route::get('/index', 'index');
        Route::get('/dashboard', 'dashboard');
        Route::get('/yearly-best-selling-price', 'yearlyBestSellingPrice');
        Route::get('/yearly-best-selling-qty', 'yearlyBestSellingQty');
        Route::get('/monthly-best-selling-qty', 'monthlyBestSellingQty');
        Route::get('/recent-sale', 'recentSale');
        Route::get('/recent-purchase', 'recentPurchase');
        Route::get('/recent-quotation', 'recentQuotation');
        Route::get('/recent-payment', 'recentPayment');
        Route::get('switch-theme/{theme}', 'switchTheme')->name('switchTheme');
        Route::get('/dashboard-filter/{start_date}/{end_date}', 'dashboardFilter');
        Route::get('addon-list', 'addonList');
        Route::get('my-transactions/{year}/{month}', 'myTransaction');
    });


    Route::resource('policies', AdminPolicyController::class);
    Route::post('policies/{policy}/toggle', [AdminPolicyController::class, 'toggleActive'])->name('policies.toggle');


    // Need to check again
    Route::resource('products',ProductController::class)->except([ 'show']);
    Route::controller(ProductController::class)->group(function () {
        Route::post('products/product-data', 'productData');
        Route::get('products/gencode', 'generateCode');
        Route::get('products/search', 'search');
        Route::get('products/saleunit/{id}', 'saleUnit');
        Route::get('products/getdata/{id}/{variant_id}', 'getData');
        Route::get('products/product_warehouse/{id}', 'productWarehouseData');
        Route::get('products/print_barcode','printBarcode')->name('product.printBarcode');
        Route::get('products/lims_product_search', 'limsProductSearch')->name('product.search');
        Route::post('products/deletebyselection', 'deleteBySelection');
        Route::post('products/update', 'updateProduct');
        Route::get('products/variant-data/{id}','variantData');
        Route::get('products/history', 'history')->name('products.history');
        Route::post('products/sale-history-data', 'saleHistoryData');
        Route::post('products/purchase-history-data', 'purchaseHistoryData');
        Route::post('products/sale-return-history-data', 'saleReturnHistoryData');
        Route::post('products/purchase-return-history-data', 'purchaseReturnHistoryData');

        Route::post('importproduct', 'importProduct')->name('product.import');
        Route::post('exportproduct', 'exportProduct')->name('product.export');
        Route::get('check-batch-availability/{product_id}/{batch_no}/{warehouse_id}', 'checkBatchAvailability');
     });


    Route::get('language_switch/{locale}', [LanguageController::class, 'switchLanguage']);

    Route::resource('role',RoleController::class);
    Route::controller(RoleController::class)->group(function () {
        Route::get('role/permission/{id}', 'permission')->name('role.permission');
        Route::post('role/set_permission', 'setPermission')->name('role.setPermission');
    });


    Route::resource('unit', UnitController::class);
    Route::controller(UnitController::class)->group(function () {
        Route::post('importunit', 'importUnit')->name('unit.import');
        Route::post('unit/deletebyselection', 'deleteBySelection');
        Route::get('unit/lims_unit_search', 'limsUnitSearch')->name('unit.search');
     });


    Route::controller(CategoryController::class)->group(function () {
        // Category routes
        Route::post('category/import', 'import')->name('category.import');
        Route::post('category/deletebyselection', 'deleteBySelection');
        Route::post('category/category-data', 'categoryData');

        // Department routes (under Category)
        Route::get('category-department', 'categoryDepartment')->name('category-department.index');
        Route::post('category-department/store', 'storeDepartment')->name('category-department.store');
        Route::put('category-department/update/{id}', 'updateDepartment')->name('category-department.update');
        Route::get('category-department/{id}/edit', 'editDepartment')->name('category-department.edit');
        Route::post('category-department/department-data', 'departmentData')->name('category-department.data');

        Route::post('category-department/deletebySelection', 'deleteDepartmentBySelection');
        Route::delete('category-department/{id}', 'deleteDepartment')->name('category-department.destroy');
    });

    Route::resource('category', CategoryController::class);


    Route::controller(BrandController::class)->group(function () {
        Route::post('importbrand', 'importBrand')->name('brand.import');
        Route::post('brand/deletebyselection', 'deleteBySelection');
        Route::get('brand/lims_brand_search', 'limsBrandSearch')->name('brand.search');
    });
    Route::resource('brand', BrandController::class);


    Route::controller(SupplierController::class)->group(function () {
        Route::post('importsupplier', 'importSupplier')->name('supplier.import');
        Route::post('supplier/deletebyselection', 'deleteBySelection');
        Route::post('suppliers/clear-due', 'clearDue')->name('supplier.clearDue');
        Route::get('suppliers/all', 'suppliersAll')->name('supplier.all');
        Route::get('suppliers/all-companies', 'allCompanies')->name('supplier.allCompanies');
        // Product search filtered by warehouse (for purchase create)
        Route::get('lims_product_search_warehouse', 'productSearchByWarehouse')->name('lims_product_search_warehouse');

        // Quick supplier creation from modal (AJAX)
        Route::post('suppliers/quick-store', 'quickStoreSupplier')->name('suppliers.quick_store');
    });
    Route::resource('supplier', SupplierController::class)->except('show');


    Route::controller(WarehouseController::class)->group(function () {
        Route::post('importwarehouse', 'importWarehouse')->name('warehouse.import');
        Route::post('warehouse/deletebyselection', 'deleteBySelection');
        Route::get('warehouse/lims_warehouse_search', 'limsWarehouseSearch')->name('warehouse.search');
        Route::get('warehouse/all', 'warehouseAll')->name('warehouse.all');
    });
    Route::resource('warehouse', WarehouseController::class);

    Route::resource('tables', TableController::class);





    // ==========================================
    // ACCOUNTING ROUTES (Reconciliation + Reports)
    // ==========================================
    Route::controller(\App\Http\Controllers\AccountingReconciliationController::class)->group(function () {
        Route::get('accounting/reconciliation', 'index')->name('accounting.reconciliation.index');
        Route::post('accounting/reconciliation/retry/{id}', 'retry')->name('accounting.reconciliation.retry');
    });

    Route::controller(\App\Http\Controllers\AccountingReportController::class)->group(function () {
        Route::get('accounting/balance-sheet', 'balanceSheet')->name('accounting.balance-sheet');
        Route::get('accounting/profit-loss', 'profitAndLoss')->name('accounting.profit-loss');
        Route::get('accounting/trial-balance', 'trialBalance')->name('accounting.trial-balance');
        Route::get('accounting/general-ledger', 'generalLedger')->name('accounting.general-ledger');
        Route::get('accounting/cash-flow', 'cashFlowStatement')->name('accounting.cash-flow');
    });


    Route::controller(TaxController::class)->group(function () {
        Route::post('importtax', 'importTax')->name('tax.import');
        Route::post('tax/deletebyselection', 'deleteBySelection');
        Route::get('tax/lims_tax_search', 'limsTaxSearch')->name('tax.search');
    });
    Route::resource('tax', TaxController::class);


    Route::controller(CustomerGroupController::class)->group(function () {
        Route::post('importcustomer_group', 'importCustomerGroup')->name('customer_group.import');
        Route::post('customer_group/deletebyselection', 'deleteBySelection');
        Route::get('customer_group/lims_customer_group_search', 'limsCustomerGroupSearch')->name('customer_group.search');
        Route::get('customer_group/all', 'customerGroupAll')->name('customer_group.all');
    });
    Route::resource('customer_group', CustomerGroupController::class);


    Route::resource('discount-plans', DiscountPlanController::class);
    Route::resource('discounts', DiscountController::class);
    Route::get('product-autocomplete', [DiscountController::class, 'productAutocomplete'])->name('product.autocomplete');
    Route::get('discounts/product-search/{code}', [DiscountController::class,'productSearch']);


    Route::controller(CustomerController::class)->group(function () {
        Route::post('importcustomer', 'importCustomer')->name('customer.import');
        Route::get('customer/getDeposit/{id}', 'getDeposit');
        Route::post('customer/add_deposit', 'addDeposit')->name('customer.addDeposit');
        Route::post('customer/update_deposit', 'updateDeposit')->name('customer.updateDeposit');
        Route::post('customer/deleteDeposit', 'deleteDeposit')->name('customer.deleteDeposit');
        Route::post('customer/deletebyselection', 'deleteBySelection');
        Route::get('customer/lims_customer_search', 'limsCustomerSearch')->name('customer.search');
        Route::post('customers/clear-due', 'clearDue')->name('customer.clearDue');
        Route::get('customers/all', 'customersAll')->name('customer.all');
        Route::get('customers/black-list-customers', 'black_list_customers')->name('customer.blackListCustomers');
        Route::get('delete-black-list-customer/{id}', 'delete_black_list_customer')->name('customer.deleteBlackListCustomers');
         Route::get('/customer/check-customer-status/{whatsapp_number}', 'customer_status')->name('customer.status');

         //Store Customer From Pos Modal use storeCustomer function
        Route::post('customer/store-customer', 'storeCustomer')->name('customer.storeCustomer');
    });
    Route::resource('customer', CustomerController::class)->except('show');


    Route::controller(BillerController::class)->group(function () {
        Route::post('importbiller', 'importBiller')->name('biller.import');
        Route::post('biller/deletebyselection', 'deleteBySelection');
        Route::get('biller/lims_biller_search', 'limsBillerSearch')->name('biller.search');
    });
    Route::resource('biller', BillerController::class);


    Route::controller(SaleController::class)->group(function () {
        Route::get('shippings', 'shippings2')->name('sales.shippings');
        Route::post('shipping-update/{shipping_id}', 'shipping_update')->name('shipping.update');
        Route::post('shipping-post', 'shipping_post')->name('shipping.post');
        Route::post('location-update/{location_id}', 'location_update')->name('location.update');
        Route::get('sales/orders', 'salesorder')->name('sales.orders');
        Route::get('location-delete/{location_id}', 'location_delete')->name('location.delete');
        Route::get('shipping-delete/{shipping_id}', 'shipping_delete')->name('shipping.delete');
        Route::post('location-add', 'location_add')->name('location.add');
        Route::post('sales/sale-data', 'saleData');
        Route::post('sales/sendmail', 'sendMail')->name('sale.sendmail');
        Route::get('sales/sale_by_csv', 'saleByCsv');
        Route::get('sales/product_sale/{id}', 'productSaleData');
        Route::post('importsale', 'importSale')->name('sale.import');
        Route::get('pos', 'posSale')->name('sale.pos');
        Route::get('sales/lims_sale_search', 'limsSaleSearch')->name('sale.search');
        Route::get('sales/lims_product_search', 'limsProductSearch')->name('product_sale.search');

        Route::get('sales/offline_products/{warehouse_id}', 'offlineProductsData')->name('product_sale.offline_products');

        Route::get('sales/getcustomergroup/{id}', 'getCustomerGroup')->name('sale.getcustomergroup');
        Route::get('sales/getproduct/{id}', 'getProduct')->name('sale.getproduct');
        Route::get('sales/getproduct/{category_id}/{brand_id}', 'getProductByFilter');
        Route::get('sales/getfeatured', 'getFeatured');
        Route::get('sales/get_gift_card', 'getGiftCard');
        Route::get('sales/paypalSuccess', 'paypalSuccess');
        Route::get('sales/paypalPaymentSuccess/{id}', 'paypalPaymentSuccess');
        Route::get('sales/gen_invoice/{id}', 'genInvoice')->name('sale.invoice');
        Route::post('sales/add_payment', 'addPayment')->name('sale.add-payment');
        Route::get('sales/getpayment/{id}', 'getPayment')->name('sale.get-payment');
        Route::post('sales/updatepayment', 'updatePayment')->name('sale.update-payment');
        Route::post('sales/deletepayment', 'deletePayment')->name('sale.delete-payment');
        Route::get('sales/{id}/create', 'createSale')->name('sale.draft');
        Route::post('sales/deletebyselection', 'deleteBySelection');
        Route::get('sales/print-last-reciept', 'printLastReciept')->name('sales.printLastReciept');
        Route::get('sales/today-sale', 'todaySale');
        Route::get('sales/today-profit/{warehouse_id}', 'todayProfit');
        Route::get('sales/check-discount', 'checkDiscount');
        Route::get('ads', 'ads')->name('ads.index');
        Route::get('create-ad', 'createAd');
        Route::post('store-ad', 'storeAd')->name('ad.store');
        Route::get('delete-ad/{id}', 'deleteAd');
        Route::get('edit-ad/{id}', 'editAd');
        Route::post('update-ad', 'updateAd')->name('ad.update');

    });

    Route::post('sales/save-default-filter', [SaleController::class, 'saveDefaultFilter'])->name('sales.save-default-filter');
 // routes/web.php  (or wherever your sale routes are)
    Route::get('warehouse-products-sale', [SaleController::class, 'getWarehouseProductsForSale'])->name('warehouse.products.sale');
    Route::resource('sales', SaleController::class);


    // Route::get('/customer-display', [SaleController::class, 'customerDisplay'])->name('sales.customerDisplay');

    Route::controller(HirePurchaseController::class)->group(function () {
        Route::prefix('hire-purchase')->group(function () {
            Route::get('/', 'index')->name('hire_purchase.index');
            Route::get('dashboard', 'dashboard')->name('hire_purchase.dashboard');
            Route::get('pending', 'pending')->name('hire_purchase.pending');
            Route::get('overdue', 'overdue')->name('hire_purchase.overdue');
            Route::get('show/{id}', 'show')->name('hire_purchase.show');
            Route::get('get-installments', 'getInstallments')->name('hire_purchase.get_installments');
            Route::post('record-payment/{id}', 'recordPayment')->name('hire_purchase.record_payment');
            Route::get('report', 'report')->name('hire_purchase.report');
            Route::post('export-report', 'exportReport')->name('hire_purchase.export_report');
        });
    });


    Route::controller(DeliveryController::class)->group(function () {
        Route::prefix('delivery')->group(function () {
            Route::get('/', 'index')->name('delivery.index');
            Route::get('product_delivery/{id}','productDeliveryData');
            Route::get('create/{id}', 'create');
            Route::post('store', 'store')->name('delivery.store');
            Route::post('sendmail', 'sendMail')->name('delivery.sendMail');
            Route::get('{id}/edit', 'edit');
            Route::post('update', 'update')->name('delivery.update');
            Route::post('deletebyselection', 'deleteBySelection');
            Route::post('delete/{id}', 'delete')->name('delivery.delete');
        });
    });

    Route::post('delivery/{id}/mark-delivered', [DeliveryController::class, 'markDelivered'])->name('delivery.markDelivered');
    Route::post('delivery/update-status', [DeliveryController::class, 'updateStatus'])->name('delivery.updateStatus');
    Route::post('delivery/record-payment', [DeliveryController::class, 'recordDeliveryPayment'])->name('delivery.recordPayment');




    Route::controller(DamageStockController::class)->group(function () {
        Route::get('damage-stock/getproduct/{id}',       'getProduct')         ->name('damage-stock.getproduct');
        Route::get('damage-stock/lims_product_search',   'limsProductSearch')  ->name('damage-stock.search');
        Route::post('damage-stock/deletebyselection',    'deleteBySelection');
    });
    Route::resource('damage-stock', DamageStockController::class);

    Route::controller(QuotationController::class)->group(function () {
        Route::prefix('quotations')->group(function () {
            Route::post('quotation-data', 'quotationData')->name('quotations.data');
            Route::get('product_quotation/{id}','productQuotationData');
            Route::get('lims_product_search', 'limsProductSearch')->name('product_quotation.search');
            Route::get('getcustomergroup/{id}', 'getCustomerGroup')->name('quotation.getcustomergroup');
            Route::get('getproduct/{id}', 'getProduct')->name('quotation.getproduct');
            Route::get('{id}/create_sale', 'createSale')->name('quotation.create_sale');
            Route::get('{id}/create_purchase', 'createPurchase')->name('quotation.create_purchase');
            Route::post('sendmail', 'sendMail')->name('quotation.sendmail');
            Route::post('deletebyselection', 'deleteBySelection');
        });
    });
    Route::get('quotation/{id}/generate_proforma', [QuotationController::class, 'generateProforma'])->name('quotation.generate_proforma');
    Route::resource('quotations', QuotationController::class);


    Route::controller(PurchaseController::class)->group(function () {
        Route::prefix('purchases')->group(function () {
            Route::post('purchase-data', 'purchaseData')->name('purchases.data');
            Route::get('product_purchase/{id}', 'productPurchaseData');
            Route::get('lims_product_search', 'limsProductSearch')->name('product_purchase.search');
            Route::post('add_payment', 'addPayment')->name('purchase.add-payment');
            Route::get('getpayment/{id}', 'getPayment')->name('purchase.get-payment');
            //Authorize payment
            Route::post('authorize_payment/{id}', 'authorizePayment')->name('purchase.authorize-payment');
            //getPaymentData using id
            Route::get('get_payment_data/{id}', 'getPaymentData')->name('purchase.getPaymentData');
            Route::post('updatepayment', 'updatePayment')->name('purchase.update-payment');
            Route::post('deletepayment', 'deletePayment')->name('purchase.delete-payment');
            Route::post('approve-payment/{id}', 'approvePayment')->name('purchase.approve-payment');
            Route::post('reject-payment/{id}', 'rejectPayment')->name('purchase.reject-payment');
            Route::get('purchase_by_csv', 'purchaseByCsv');
            Route::post('deletebyselection', 'deleteBySelection');
            //show
            Route::get('{id}/show', 'show')->name('purchases.show');

            Route::get('get-warehouse-products',  'getWarehouseProducts')->name('warehouse.products');
        });
        Route::post('importpurchase', 'importPurchase')->name('purchase.import');
    });
    //set filter as in Sales
    Route::post('purchases/save-default-filter', [PurchaseController::class, 'saveDefaultFilter'])->name('purchases.save-default-filter');
    Route::resource('purchases', PurchaseController::class);


    Route::controller(TransferController::class)->group(function () {
        Route::prefix('transfers')->group(function () {
            Route::post('transfer-data', 'transferData')->name('transfers.data');
            Route::get('product_transfer/{id}', 'productTransferData');
            Route::get('transfer_by_csv', 'transferByCsv');
            Route::get('getproduct/{id}', 'getProduct')->name('transfer.getproduct');
            Route::get('lims_product_search', 'limsProductSearch')->name('product_transfer.search');
            Route::post('deletebyselection', 'deleteBySelection');
         });
        Route::post('importtransfer', 'importTransfer')->name('transfer.import');
    });
    Route::resource('transfers', TransferController::class);



    Route::controller(AdjustmentController::class)->group(function () {
        Route::get('qty_adjustment/getproduct/{id}', 'getProduct')->name('adjustment.getproduct');
        Route::get('qty_adjustment/lims_product_search', 'limsProductSearch')->name('product_adjustment.search');
        Route::post('qty_adjustment/deletebyselection', 'deleteBySelection');
    });
    Route::resource('qty_adjustment', AdjustmentController::class);


    Route::controller(ReturnController::class)->group(function () {
        Route::prefix('return-sale')->group(function () {
            Route::post('return-data', 'returnData');
            Route::get('getcustomergroup/{id}', 'getCustomerGroup')->name('return-sale.getcustomergroup');
            Route::post('sendmail', 'sendMail')->name('return-sale.sendmail');
            Route::get('getproduct/{id}', 'getProduct')->name('return-sale.getproduct');
            Route::get('lims_product_search', 'limsProductSearch')->name('product_return-sale.search');
            Route::get('product_return/{id}', 'productReturnData');
            Route::post('deletebyselection', 'deleteBySelection');
         });
    });
    Route::resource('return-sale', ReturnController::class);


    Route::controller(ReturnPurchaseController::class)->group(function () {
        Route::prefix('return-purchase')->group(function () {
            Route::post('return-data', 'returnData');
            Route::get('getcustomergroup/{id}', 'getCustomerGroup')->name('return-purchase.getcustomergroup');
            Route::post('sendmail', 'sendMail')->name('return-purchase.sendmail');
            Route::get('getproduct/{id}', 'getProduct')->name('return-purchase.getproduct');
            Route::get('lims_product_search', 'limsProductSearch')->name('product_return-purchase.search');
            Route::get('product_return/{id}', 'productReturnData');
            Route::post('deletebyselection', 'deleteBySelection');
         });
    });
    Route::resource('return-purchase', ReturnPurchaseController::class);


    Route::controller(ReportController::class)->group(function () {
        Route::prefix('report')->group(function () {
            Route::get('/', 'reportDashboard')->name('report.dashboard');
            Route::get('first-time-customers', 'firstTimeCustomers')->name('report.firstTimeCustomers');
            Route::get('installment-report', 'hirePurchaseInstallmentReport')->name('report.installmentReport');
            Route::get('product_quantity_alert', 'productQuantityAlert')->name('report.qtyAlert');
            Route::get('daily-sale-objective', 'dailySaleObjective')->name('report.dailySaleObjective');
            Route::post('daily-sale-objective-data', 'dailySaleObjectiveData');
            Route::get('product-expiry', 'productExpiry')->name('report.productExpiry');
            Route::get('warehouse_stock', 'warehouseStock')->name('report.warehouseStock');
            Route::match(['get','post'], 'report/warehouse-stock', [ReportController::class, 'warehouseStockReport'])->name('report.warehouseStockReport');
            //warehouse stock report data
            Route::post('report/warehouse-stock-data', [ReportController::class, 'warehouseStockReportData'])->name('report.warehouseStockData');

            Route::get('stock-coverage', [ReportController::class, 'stockCoverage'])->name('stock-coverage');
            Route::get('stock-coverage-data', [ReportController::class, 'stockCoverageData'])->name('stock-coverage.data');

            Route::get('daily_sale/{year}/{month}', 'dailySale')->name('report.dailySale');
            Route::post('daily_sale/{year}/{month}', 'dailySaleByWarehouse')->name('report.dailySaleByWarehouse');
            Route::get('monthly_sale/{year}', 'monthlySale')->name('report.monthlySale');
            Route::post('monthly_sale/{year}', 'monthlySaleByWarehouse')->name('report.monthlySaleByWarehouse');
            Route::get('daily_purchase/{year}/{month}', 'dailyPurchase')->name('report.dailyPurchase');
            Route::post('daily_purchase/{year}/{month}', 'dailyPurchaseByWarehouse')->name('report.dailyPurchaseByWarehouse');
            Route::get('monthly_purchase/{year}', 'monthlyPurchase')->name('report.monthlyPurchase');
            Route::post('monthly_purchase/{year}', 'monthlyPurchaseByWarehouse')->name('report.monthlyPurchaseByWarehouse');
            Route::get('best_seller', 'bestSeller')->name('report.bestSeller');
            Route::post('best_seller', 'bestSellerByWarehouse')->name('report.bestSellerByWarehouse');
            Route::post('profit_loss', 'profitLoss')->name('report.profitLoss');
            Route::any('profit_loss_data', 'profitLossData')->name('report.profitLossData');
            Route::get('product_report', 'productReport')->name('report.product');
            Route::post('product_report_data', 'productReportData');
            Route::post('purchase', 'purchaseReport')->name('report.purchase');
            Route::post('sale_report', 'saleReport')->name('report.sale');
            Route::post('sale-report-chart', 'saleReportChart')->name('report.saleChart');
            Route::get('payment_report', 'paymentReportByDate')->name('report.paymentReport');
            Route::post('payment_report_by_date', 'paymentReportByDate')->name('report.paymentByDate');
            Route::match(['get', 'post'], 'warehouse_report', 'warehouseReport')->name('report.warehouse');
            Route::post('warehouse-sale-data', 'warehouseSaleData');
            Route::post('warehouse-purchase-data', 'warehousePurchaseData');
            Route::post('warehouse-expense-data', 'warehouseExpenseData');
            Route::post('warehouse-quotation-data', 'warehouseQuotationData');
            Route::post('warehouse-return-data', 'warehouseReturnData');
            Route::post('user_report', 'userReport')->name('report.user');
            Route::post('user-sale-data', 'userSaleData');
            Route::post('user-purchase-data', 'userPurchaseData');
            Route::post('user-expense-data', 'userExpenseData');
            Route::post('user-quotation-data', 'userQuotationData');
            Route::post('user-payment-data', 'userPaymentData');
            Route::post('user-transfer-data', 'userTransferData');
            Route::post('user-payroll-data', 'userPayrollData');
            Route::post('customer_report', 'customerReport')->name('report.customer');
            Route::post('customer-sale-data', 'customerSaleData');
            Route::post('customer-payment-data', 'customerPaymentData');
            Route::post('customer-quotation-data', 'customerQuotationData');
            Route::post('customer-return-data', 'customerReturnData');
            Route::post('customer-group', 'customerGroupReport')->name('report.customer_group');
            Route::post('customer-group-sale-data', 'customerGroupSaleData');
            Route::post('customer-group-payment-data', 'customerGroupPaymentData');
            Route::post('customer-group-quotation-data', 'customerGroupQuotationData');
            Route::post('customer-group-return-data', 'customerGroupReturnData');
            Route::post('supplier', 'supplierReport')->name('report.supplier');
            Route::post('supplier-purchase-data', 'supplierPurchaseData');
            Route::post('supplier-payment-data', 'supplierPaymentData');
            Route::post('supplier-return-data', 'supplierReturnData');
            Route::post('supplier-quotation-data', 'supplierQuotationData');
            Route::post('customer-due-report', 'customerDueReportByDate')->name('report.customerDueByDate');
            Route::post('customer-due-report-data', 'customerDueReportData');
            Route::post('supplier-due-report', 'supplierDueReportByDate')->name('report.supplierDueByDate');
            Route::post('supplier-due-report-data', 'supplierDueReportData');
            Route::get('department', 'departmentReport')->name('report.department');
            Route::match(['get', 'post'], 'sales-person', 'salesPersonReport')->name('report.salesPerson');
            Route::post('sales-person-details', 'salesPersonReportDetails')->name('report.salesPersonDetails');

            /*
            |--------------------------------------------------------------------------
            | Stock Taking Report
            |--------------------------------------------------------------------------
            */
            Route::get('stock-taking', 'stockTaking')->name('report.stockTaking');

            Route::any('stock-taking-data', 'stockTakingData')->name('report.stockTakingData');

            Route::match(['get', 'post'], 'payment-method', 'paymentMethodReport')->name('report.paymentMethod');
            Route::post('payment-method-details', 'paymentMethodReportDetails')->name('report.paymentMethodDetails');

            Route::get('activity-log', 'activityLog')->name('report.activity-log');
            Route::get('activity-log-data', 'activityLogData')->name('report.activity-log-data');
            Route::get('activity-log-details/{id}', 'activityLogDetails')->name('report.activity-log-details');


        });
    });


    Route::controller(UserController::class)->group(function () {
        Route::get('user/profile/{id}', 'profile')->name('user.profile');
        Route::put('user/update_profile/{id}', 'profileUpdate')->name('user.profileUpdate');
        Route::put('user/changepass/{id}', 'changePassword')->name('user.password');
        Route::get('user/genpass', 'generatePassword');
        Route::post('user/deletebyselection', 'deleteBySelection');
        Route::get('user/notification', 'notificationUsers')->name('user.notification');
        Route::get('user/all', 'allUsers')->name('user.all');
    });
    Route::resource('user', UserController::class);


    Route::controller(SettingController::class)->group(function () {
        Route::prefix('setting')->group(function () {
            Route::get('general_setting', 'generalSetting')->name('setting.general');
            Route::post('general_setting_store', 'generalSettingStore')->name('setting.generalStore');

            Route::get('reward-point-setting', 'rewardPointSetting')->name('setting.rewardPoint');
            Route::post('reward-point-setting_store', 'rewardPointSettingStore')->name('setting.rewardPointStore');

            Route::get('general_setting/change-theme/{theme}', 'changeTheme');
            Route::get('mail_setting', 'mailSetting')->name('setting.mail');
            Route::get('sms_setting', 'smsSetting')->name('setting.sms');
            Route::get('createsms', 'createSms')->name('setting.createSms');
            Route::post('sendsms', 'sendSms')->name('setting.sendSms');
            Route::get('hrm_setting', 'hrmSetting')->name('setting.hrm');
            Route::post('hrm_setting_store', 'hrmSettingStore')->name('setting.hrmStore');
            Route::post('mail_setting_store', 'mailSettingStore')->name('setting.mailStore');
            Route::post('sms_setting_store', 'smsSettingStore')->name('setting.smsStore');
            Route::get('pos_setting', 'posSetting')->name('setting.pos');
            Route::post('pos_setting_store', 'posSettingStore')->name('setting.posStore');
            Route::get('empty-database', 'emptyDatabase')->name('setting.emptyDatabase');
         });
        Route::get('backup', 'backup')->name('setting.backup');
    });

    Route::controller(ExpenseCategoryController::class)->group(function () {
        Route::get('expense_categories/gencode', 'generateCode');
        Route::post('expense_categories/import', 'import')->name('expense_category.import');
        Route::post('expense_categories/deletebyselection', 'deleteBySelection');
        Route::get('expense_categories/all', 'expenseCategoriesAll')->name('expense_category.all');;
    });
    Route::resource('expense_categories', ExpenseCategoryController::class);

    Route::controller(ExpenseController::class)->group(function () {
        Route::post('expenses/expense-data', 'expenseData')->name('expenses.data');
        Route::post('expenses/deletebyselection', 'deleteBySelection');
        Route::post('expenses/{id}/authorize', 'authorizeExpense')->name('expenses.authorize');
        Route::post('expenses/{id}/approve', 'approveExpense')->name('expenses.approve');
    });
    Route::resource('expenses', ExpenseController::class);

    // Central Approvals (Purchase Payments + Expenses)
    Route::controller(ApprovalController::class)->group(function () {
        Route::get('approvals', 'index')->name('approvals.index');
        Route::post('approvals/expense/{id}/approve', 'approveExpense')->name('approval.expense.approve');
        Route::post('/approvals/stock-count/{id}/approve', 'approveStockCount')->name('approvals.stock-count.approve');
        Route::post('/approvals/stock-count/bulk-approve', 'bulkApproveStockCounts')->name('approvals.stock-count.bulk-approve');
    });

    Route::controller(GiftCardController::class)->group(function () {
        Route::get('gift_cards/gencode', 'generateCode');
        Route::post('gift_cards/recharge/{id}', 'recharge')->name('gift_cards.recharge');
        Route::post('gift_cards/deletebyselection', 'deleteBySelection');
    });
    Route::resource('gift_cards', GiftCardController::class);

    Route::resource('couriers', CourierController::class);

    Route::controller(CouponController::class)->group(function () {
        Route::get('coupons/gencode', 'generateCode');
        Route::post('coupons/deletebyselection', 'deleteBySelection');
    });
    Route::resource('coupons', CouponController::class);

    //accounting routes
    Route::controller(AccountsController::class)->group(function () {
        Route::get('make-default/{id}', 'makeDefault');
        Route::get('balancesheet', 'balanceSheet')->name('accounts.balancesheet');
        Route::post('account-statement', 'accountStatement')->name('accounts.statement');
        Route::get('accounts/all', 'accountsAll')->name('account.all');
        Route::get('accounts/sync-balance/{id}', 'syncBalance')->name('accounts.sync-balance');
    });
    Route::resource('accounts', AccountsController::class);

    Route::resource('money-transfers', MoneyTransferController::class);

    //HRM routes
    Route::post('departments/deletebyselection', [DepartmentController::class,'deleteBySelection']);
    Route::resource('departments', DepartmentController::class);
    Route::resource('designations', DesignationController::class);
    Route::resource('shift', ShiftController::class);
    // Route::resource('overtime', OvertimeController::class);
    Route::resource('leave-type', LeaveTypeController::class);
    Route::resource('leave', ControllersLeaveController::class);

    // Make Payment
    Route::get('payroll-payment',             [PayrollPaymentController::class, 'index'])->name('payroll-payment.index');
    Route::post('payroll-payment/store',      [PayrollPaymentController::class, 'store'])->name('payroll-payment.store');
    Route::delete('payroll-payment/{id}',     [PayrollPaymentController::class, 'destroy'])->name('payroll-payment.destroy');

    Route::get('overtime',                    [OvertimeController::class, 'index'])->name('overtime.index');
    Route::post('overtime/store',             [OvertimeController::class, 'store'])->name('overtime.store');
    Route::delete('overtime/{id}',            [OvertimeController::class, 'destroy'])->name('overtime.destroy');
    Route::get('hrm-panel', [HRMController::class, 'index'])->name('hrm-panel');


    Route::resource('sale-agents', SaleAgentController::class)->except('show');

    Route::post('employees/deletebyselection', [EmployeeController::class, 'deleteBySelection']);
    Route::resource('employees', EmployeeController::class);


    // Route::post('payroll/deletebyselection', [PayrollController::class, 'deleteBySelection']);
    // Route::post('payroll/generateCards', [PayrollController::class, 'generateCards'])->name('payroll.generateCards');
    // Route::get('payroll/get-employees', [PayrollController::class, 'getEmployeesByWarehouse'])->name('payroll.getEmployeesByWarehouse');
    // Route::get('payroll/monthly-data', [PayrollController::class, 'monthlyData'])->name('payroll.monthlyData');
    // Route::post('payroll-templates/store', [PayrollController::class, 'storeTemplate'])->name('payroll.templates.store');
    // Route::resource('payroll', PayrollController::class);
    //
    //

    // Salary Template (monthly) + Hourly Template
       Route::get('salary-template',              [SalaryTemplateController::class, 'index'])->name('salary-template.index');
       Route::post('salary-template/store',       [SalaryTemplateController::class, 'store'])->name('salary-template.store');
       Route::get('salary-template/hourly',       [SalaryTemplateController::class, 'hourly'])->name('salary-template.hourly');
       Route::post('salary-template/hourly/store',[SalaryTemplateController::class, 'storeHourly'])->name('salary-template.store-hourly');
       Route::post('salary-template/assign',      [SalaryTemplateController::class, 'assign'])->name('salary-template.assign');
       Route::delete('salary-template/{id}',      [SalaryTemplateController::class, 'destroy'])->name('salary-template.destroy');

       // Manage Salary
       Route::get('payroll',                     [PayrollController::class, 'index'])->name('payroll.index');
       Route::get('payroll/generate',            [PayrollController::class, 'generate'])->name('payroll.generate');
       Route::post('payroll/generate/store',     [PayrollController::class, 'generateStore'])->name('payroll.generate-store');
       Route::post('payroll/store',              [PayrollController::class, 'store'])->name('payroll.store');
       Route::get('payroll/{id}/details',        [PayrollController::class, 'details'])->name('payroll.details');
       Route::post('payroll/update/{id}',        [PayrollController::class, 'update'])->name('payroll.update');
       Route::delete('payroll/{id}',             [PayrollController::class, 'destroy'])->name('payroll.destroy');
    // AJAX endpoints for creating templates and template items from modal
    Route::post('payroll-templates/store', [\App\Http\Controllers\PayrollTemplateController::class, 'store']);



    Route::post('attendance/delete/{date}/{employee_id}', [AttendanceController::class, 'delete'])->name('attendances.delete');
    Route::post('attendance/deletebyselection', [AttendanceController::class, 'deleteBySelection']);
    Route::post('attendance/importDeviceCsv', [AttendanceController::class, 'importDeviceCsv'])->name('attendances.importDeviceCsv');
    Route::resource('attendance', AttendanceController::class);


    Route::controller(StockCountController::class)->group(function () {
        Route::post('stock-count/finalize', 'finalize')->name('stock-count.finalize');
        Route::get('stock-count/stockdif/{id}', 'stockDif');
        Route::get('stock-count/{id}/qty_adjustment', 'qtyAdjustment')->name('stock-count.adjustment');
    });
    Route::post('stock-count/save',[StockCountController::class, 'saveCount'])->name('stock-count.save');
    Route::resource('stock-count', StockCountController::class);

    Route::controller(HolidayController::class)->group(function () {
        Route::post('holidays/deletebyselection', 'deleteBySelection');
        Route::get('approve-holiday/{id}', 'approveHoliday')->name('approveHoliday');
        Route::get('holidays/my-holiday/{year}/{month}', 'myHoliday')->name('myHoliday');
    });
    Route::resource('holidays', HolidayController::class);

    Route::controller(CashRegisterController::class)->group(function () {
        Route::prefix('cash-register')->group(function () {
            Route::get('/', 'index')->name('cashRegister.index');
            Route::get('check-availability/{warehouse_id}', 'checkAvailability')->name('cashRegister.checkAvailability');
            Route::post('store', 'store')->name('cashRegister.store');
            Route::get('getDetails/{id}', 'getDetails');
            Route::get('showDetails/{warehouse_id}', 'showDetails');
            Route::post('close', 'close')->name('cashRegister.close');
        });
    });

    Route::controller(NotificationController::class)->group(function () {
        Route::prefix('notifications')->group(function () {
            Route::get('/', 'index')->name('notifications.index');
            Route::post('store', 'store')->name('notifications.store');
            Route::get('mark-as-read', 'markAsRead')->name('notifications.markAsRead');
        });
    });

    //Sms Template
    Route::resource('smstemplates', SmsTemplateController::class);

    Route::prefix('whatsapp')->group(function () {
        Route::get('/settings', [WhatsappController::class, 'settings'])->name('whatsapp.settings');
        Route::post('/settings', [WhatsappController::class, 'updateSettings'])->name('whatsapp.settings.update');

        Route::get('/templates', [WhatsappController::class, 'templates'])->name('whatsapp.templates');
        Route::delete('/template/delete/{name}', [WhatsappController::class, 'deleteTemplate'])->name('whatsapp.template.delete');

        Route::get('/send', [WhatsappController::class, 'sendPage'])->name('whatsapp.send.page');
        Route::post('/send', [WhatsappController::class, 'sendMessage'])->name('whatsapp.send');
    });


 $middlewares = array_merge(['common', 'auth', 'active']);

Route::prefix('ai')->name('ai-assistant.')->middleware($middlewares)->group(function () {

    // ── AI Conversation (chat) page ───────────────────────────────
    Route::get('ai-assistant', [AIAssistantController::class, 'index'])
        ->name('index');

    // ── AI Provider Settings (admin-only CRUD) ───────────────────
    Route::get('providers', [AIAssistantController::class, 'providers'])
        ->name('providers.index');

    Route::post('providers', [AIAssistantController::class, 'providerStore'])
        ->name('providers.store');

    Route::put('providers/{id}', [AIAssistantController::class, 'providerUpdate'])
        ->name('providers.update');

    Route::delete('providers/{id}', [AIAssistantController::class, 'providerDestroy'])
        ->name('providers.destroy');

    Route::post('providers/{id}/toggle', [AIAssistantController::class, 'providerToggle'])
        ->name('providers.toggle');

    // ── Structured prompt endpoint (invokable) ───────────────────
    Route::post('ai-assistant/prompt', StructuredPromptController::class)
        ->name('prompt');

    // ── Conversation persistence endpoints (AJAX API) ─────────────
    Route::prefix('ai-assistant/api/conversations')->group(function () {

        Route::get('/', [AIConversationController::class, 'index'])
            ->name('conversations.index');

        Route::post('/', [AIConversationController::class, 'store'])
            ->name('conversations.store');

        Route::get('{id}', [AIConversationController::class, 'show'])
            ->name('conversations.show');

        Route::post('{id}/prompt', [AIConversationController::class, 'appendPrompt'])
            ->name('conversations.prompt');

        Route::delete('{id}', [AIConversationController::class, 'destroy'])
            ->name('conversations.destroy');
    });
});

    // INSIDE the ['auth', 'common', 'active'] middleware group, keep only:
    Route::post('payment/{gateway}/push', [PaymentGatewayController::class, 'push'])->name('payment.push');

    Route::controller(SaleExchangeController::class)->prefix('exchange')->group(function () {
        Route::post('exchange-data', 'exchangeData')->name('exchange.data');
        Route::get('getcustomergroup/{id}', 'getCustomerGroup')->name('exchange.getcustomergroup');
        Route::post('sendmail', 'sendMail')->name('exchange.sendmail');
        Route::get('getproduct/{id}', 'getProduct')->name('exchange.getproduct');
        Route::get('lims_product_search', 'limsProductSearch')->name('exchange.lims_product_search');
        // FIXED: Changed from exchangeData to productExchange
        Route::get('product_exchange/{id}', 'productExchange')->name('exchange.product_exchange');
        Route::post('deletebyselection', 'deleteBySelection')->name('exchange.deletebyselection');
    });

    // Put this BEFORE the resource route
    Route::get('exchange/product-search', [SaleExchangeController::class, 'productSearch'])
        ->name('exchange.product-search');

    // Move this up too, just in case
    Route::get('/sale-exchange/search', [SaleExchangeController::class, 'searchByReference'])->name('sale.exchange.search');

    Route::resource('exchange', SaleExchangeController::class);

    Route::get('social-media',                [SocialMediaController::class, 'index'])->name('social-media.index');
    Route::post('social-media/store',         [SocialMediaController::class, 'store'])->name('social-media.store');
    Route::post('social-media/update/{id}',   [SocialMediaController::class, 'update'])->name('social-media.update');
    Route::post('social-media/toggle/{id}',   [SocialMediaController::class, 'toggle'])->name('social-media.toggle');
    Route::delete('social-media/{id}',        [SocialMediaController::class, 'destroy'])->name('social-media.destroy');

    Route::resource('currency', CurrencyController::class);

    Route::resource('custom-fields', CustomFieldController::class);

    Route::post('woocommerce-install', [AddonInstallController::class,'woocommerceInstall'])->name('woocommerce.install');

});
