<?php

namespace App\Http\Controllers;

use App\Models\Ad;
use App\Models\Ads;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\Customer;
use App\Models\CustomerGroup;
use App\Models\Warehouse;
use App\Models\Biller;
use App\Models\Brand;
use App\Models\Category;
use App\Models\Product;
use App\Models\Unit;
use App\Models\Tax;
use App\Models\Sale;
use App\Models\Delivery;
use App\Models\PosSetting;
use App\Models\Product_Sale;
use App\Models\Product_Warehouse;
use App\Models\Payment;
use App\Models\Account;
use App\Models\Coupon;
use App\Models\GiftCard;
use App\Models\PaymentWithCheque;
use App\Models\PaymentWithGiftCard;
use App\Models\PaymentWithCreditCard;
use App\Models\PaymentWithPaypal;
use App\Models\User;
use App\Models\Variant;
use App\Models\ProductVariant;
use App\Models\CashRegister;
use App\Models\Returns;
use App\Models\ProductReturn;
use App\Models\Expense;
use App\Models\ProductPurchase;
use App\Models\ProductBatch;
use App\Models\Purchase;
use App\Models\RewardPointSetting;
use App\Models\CustomField;
use App\Models\Table;
use App\Models\Courier;
use illuminate\Support\Facades\DB;
//cache from illuminate\Support\Facades\Cache;
use illuminate\Support\Facades\Cache;
use App\Models\GeneralSetting;
use App\Models\MailSetting;
use Stripe\Stripe;
use NumberToWords\NumberToWords;
use Auth;
use App\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Mail\SaleDetails;
use App\Mail\PaymentDetails;
use Mail;
use Srmklive\PayPal\Services\ExpressCheckout;
use Srmklive\PayPal\Services\AdaptivePayments;
use GeniusTS\HijriDate\Date;
use Illuminate\Support\Facades\Validator;
use App\Models\Currency;
use App\Models\SaleAdditionalCost;
use Salla\ZATCA\GenerateQrCode;
use Salla\ZATCA\Tags\InvoiceDate;
use Salla\ZATCA\Tags\InvoiceTaxAmount;
use Salla\ZATCA\Tags\InvoiceTotalAmount;
use Salla\ZATCA\Tags\Seller;
use Salla\ZATCA\Tags\TaxNumber;

use function Psy\info;

class SaleController extends Controller
{
    use \App\Traits\TenantInfo;
    use \App\Traits\MailInfo;


    private function isStaff(){
        return Auth::user()->roles->contains(function ($role) {
            return $role->id > 2;
        });
    }

    public function location_update(Request $request,$location_id){
    
      DB::connection('sitesql')->table('locations')->where('id',$location_id)->update([
            'name'=>$request->name,
            'updated_at'=>now()
          ]);
       return back()->with('message', 'Location Updated successfully'); 
    }
    
    
     public function shipping_update(Request $request,$shipping_id){
        $result = implode(',', $request->locations);
         DB::connection('sitesql')->table('shippings')->where('id',$shipping_id)->update([
            'name'=>$request->name,
            'price'=>$request->price,
            'location_id'=>$result,
            'store_id'=>2,
            'updated_at'=>now()
          ]);
       return back()->with('message', 'Shipping Updated successfully'); 
    }
    
      
    public function shipping_post(Request $request){
        $result = implode(',', $request->locations);
         DB::connection('sitesql')->table('shippings')->insertGetId([
            'name'=>$request->name,
            'created_at'=>now(),
            'price'=>$request->price,
            'location_id'=>$result,
            'created_by'=>Auth::user()->id,
            'store_id'=>2,
            'updated_at'=>now()
          ]);
       return back()->with('message', 'Location Updated successfully'); 
    }
    
    public function location_delete($location_id){
    
      DB::connection('sitesql')->table('locations')->where('id',$location_id)->delete();
       return back()->with('message', 'Location Deleted successfully'); 
    }
    
    public function shipping_delete($shipping_id){ 
      DB::connection('sitesql')->table('shippings')->where('id',$shipping_id)->delete();
       return back()->with('message', 'Shipping Deleted successfully'); 
    }
    
    public function location_add(Request $request){
       DB::connection('sitesql')->table('locations')->insertGetId([
            'name'=>$request->name,
            'created_at'=>now(),
            'created_by'=>1,
            'store_id'=>2,
            'updated_at'=>now()
          ]);
       return back()->with('message', 'Location Updated successfully'); 
    
    }

    public function shippings2(){
         $shippings = DB::connection('sitesql')->table('shippings')->get();
            $locations = DB::connection('sitesql')->table('locations')->get();

            return view('backend.sale.shipping', compact('shippings', 'locations'));
    }

    public function salesorder(){
        $orders=DB::connection('sitesql')->table('orders')->orderBy('id','DESC')->get();
        return view('backend.sale.orders',compact('orders'));
    }


    public function index(Request $request)
    {
 
        if(Auth::user()->hasPermissionTo('sales-index')) {
            $all_permission = Auth::user()->getAllPermissions();

            if (empty($all_permission)) {
                $all_permission[] = 'dummy text';
            }

            if($request->input('warehouse_id'))
                $warehouse_id = $request->input('warehouse_id');
            else
                $warehouse_id = 0;

            if($request->input('sale_status'))
                $sale_status = $request->input('sale_status');
            else
                $sale_status = 0;

            if($request->input('payment_status'))
                $payment_status = $request->input('payment_status');
            else
                $payment_status = 0;

            $req_start = $request->input('starting_date');
            $req_end   = $request->input('ending_date');
            if ($req_start && $req_end) {
                $starting_date = $req_start;
                $ending_date = $req_end;
                session([
                    'sale_filter_starting_date' => $starting_date,
                    'sale_filter_ending_date'   => $ending_date,
                ]);
            } elseif ($request->has('starting_date') && $request->has('ending_date')) {
                // Reset was clicked (form submitted with empty dates)
                session()->forget(['sale_filter_starting_date', 'sale_filter_ending_date']);
                $starting_date = date("Y-m-d", strtotime(date('Y-m-d', strtotime('-1 year', strtotime(date('Y-m-d') )))));
                $ending_date = date("Y-m-d");
            } else {
                $starting_date = session('sale_filter_starting_date') ?? date("Y-m-d", strtotime(date('Y-m-d', strtotime('-1 year', strtotime(date('Y-m-d') )))));
                $ending_date   = session('sale_filter_ending_date') ?? date("Y-m-d");
            }

            // Handle percentage filter (show only top X% of sales by value)
            // Priority: User input > Session > Admin default settings
     

            // Only users with sale-percentage-filter permission may use the filter


            $lims_gift_card_list = GiftCard::where("is_active", true)->get();
            $lims_pos_setting_data = PosSetting::latest()->first();
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_account_list = Account::where('is_active', true)->get();
            $lims_courier_list = Courier::where('is_active', true)->get();
            if($lims_pos_setting_data)
                $options = explode(',', $lims_pos_setting_data->payment_options);
            else
                $options = [];
            $numberOfInvoice = Sale::count();
            $custom_fields = CustomField::where([
                                ['belongs_to', 'sale'],
                                ['is_table', true]
                            ])->pluck('name');
            $field_name = [];
            foreach($custom_fields as $fieldName) {
                $field_name[] = str_replace(" ", "_", strtolower($fieldName));
            }

            
            return view('backend.sale.index', compact('starting_date', 'ending_date', 'warehouse_id', 'sale_status', 'payment_status', 'lims_gift_card_list', 'lims_pos_setting_data', 'lims_reward_point_setting_data', 'lims_account_list', 'lims_warehouse_list', 'all_permission','options', 'numberOfInvoice', 'custom_fields', 'field_name', 'lims_courier_list'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }


    public function create()
    {
        if (!Auth::user()->hasPermissionTo('sales-add')) {
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
        }

        $lims_customer_list = Customer::where('is_active', true)->get();

        // Decide whether to show all warehouses/billers or only those assigned to the user.
        // Admins (roles with ID <= 2) see everything; staff with higher roles see only their own.
        $isAdmin = Auth::user()->roles->contains(function ($role) {
            return $role->id <= 2;
        });

        if ($isAdmin) {
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_biller_list = Biller::where('is_active', true)->get();
        } else {
            // Staff (or any non‑admin) – restrict to their own assigned warehouse and biller
            $lims_warehouse_list = Warehouse::where([
                ['is_active', true],
                ['id', Auth::user()->warehouse_id]
            ])->get();
            $lims_biller_list = Biller::where([
                ['is_active', true],
                ['id', Auth::user()->biller_id]
            ])->get();
        }

        $lims_tax_list = Tax::where('is_active', true)->get();
        $lims_pos_setting_data = PosSetting::latest()->first();
        $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
        $options = $lims_pos_setting_data ? explode(',', $lims_pos_setting_data->payment_options) : [];

        $currency_list = Currency::where('is_active', true)->get();
        $numberOfInvoice = Sale::count();
        $custom_fields = CustomField::where('belongs_to', 'sale')->get();
        $lims_customer_group_all = CustomerGroup::where('is_active', true)->get();

        return view('backend.sale.create', compact(
            'currency_list', 'lims_customer_list', 'lims_warehouse_list',
            'lims_biller_list', 'lims_pos_setting_data', 'lims_tax_list',
            'lims_reward_point_setting_data', 'options', 'numberOfInvoice',
            'custom_fields', 'lims_customer_group_all'
        ));
    }


    public function store(Request $request)
    {
        
        $data = $request->all();
        logger()->info('Sale Store Request Data: ' . json_encode($data) );

        if(isset($request->reference_no)) {
            $this->validate($request, [
            'reference_no' => [
                'max:191', 'required', 'unique:sales'
            ],
            ]);
        }

        $data['user_id'] = Auth::id();
        
        $cash_register_data = CashRegister::where([
            ['user_id', $data['user_id']],
            ['warehouse_id', $data['warehouse_id']],
            ['status', true]
            ])->first();

        if($cash_register_data){
            $data['cash_register_id'] = $cash_register_data->id;
        }

        if(isset($data['created_at'])){
            $data['created_at'] = date("Y-m-d H:i:s", strtotime($data['created_at']));
        }
        else{
            $data['created_at'] = date("Y-m-d H:i:s");
        }
           
        if($data['pos']) {
            if(!isset($data['reference_no'])){
                $data['reference_no'] = 'posr-' . date("Ymd") . '-'. date("his");
            }
                
            $balance = $data['grand_total'] - $data['paid_amount'];
            if($balance > 0 || $balance < 0){
                $data['payment_status'] = 2;
            }
            else{                
                $data['payment_status'] = 4;   
            }
            if ($data['draft']) {
                if (!empty($data['sale_id']) && Sale::where('id', $data['sale_id'])->exists()) {

                    Product_Sale::where('sale_id', $data['sale_id'])->delete();
                    Sale::where('id', $data['sale_id'])->delete();

                }
            }
 
            
        }
        else {
            
            if(!isset($data['reference_no'])){
                $data['reference_no'] = 'sr-' . date("Ymd") . '-'. date("his");
            }             
        }

        $document = $request->document;
        if ($document) {
            $v = Validator::make(
                [
                    'extension' => strtolower($request->document->getClientOriginalExtension()),
                ],
                [
                    'extension' => 'in:jpg,jpeg,png,gif,pdf,csv,docx,xlsx,txt',
                ]
            );
            if ($v->fails()){
                return redirect()->back()->withErrors($v->errors());
            }
               

            $ext = pathinfo($document->getClientOriginalName(), PATHINFO_EXTENSION);
            $documentName = date("Ymdhis");
            if(!config('database.connections.saleprosaas_landlord')) {
                $documentName = $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            else {
                $documentName = $this->getTenantId() . '_' . $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            $data['document'] = $documentName;
        }

        if($data['coupon_active']) {
            $lims_coupon_data = Coupon::find($data['coupon_id']);
            $lims_coupon_data->used += 1;
            $lims_coupon_data->save();
        }

        if(isset($data['table_id'])) {
            $latest_sale = Sale::whereNotNull('table_id')->whereDate('created_at', date('Y-m-d'))->where('warehouse_id', $data['warehouse_id'])->select('queue')->orderBy('id', 'desc')->first();
            if($latest_sale){
                $data['queue'] = $latest_sale->queue + 1;
            }
            else{
                $data['queue'] = 1;
            }
                
        }
        
        //inserting data to sales table
        if (empty($data['customer_id']) && !empty($data['customer_id_hidden'])) {
            // dd('Customer ID is missing');
            $data['customer_id'] = $data['customer_id_hidden'];
        }

        $lims_sale_data = Sale::create($data);
        //inserting data for custom fields
        $custom_field_data = [];
        $custom_fields = CustomField::where('belongs_to', 'sale')->select('name', 'type')->get();
        foreach ($custom_fields as $type => $custom_field) {
            $field_name = str_replace(' ', '_', strtolower($custom_field->name));
            if(isset($data[$field_name])) {
                if($custom_field->type == 'checkbox' || $custom_field->type == 'multi_select')
                    $custom_field_data[$field_name] = implode(",", $data[$field_name]);
                else
                    $custom_field_data[$field_name] = $data[$field_name];
            }
        }
        if(count($custom_field_data)){
            DB::table('sales')->where('id', $lims_sale_data->id)->update($custom_field_data);
        }
            
        $lims_customer_data = Customer::find($data['customer_id']);
        $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
        
        //checking if customer gets some points or not
        if($lims_reward_point_setting_data && $lims_reward_point_setting_data->is_active &&  $data['grand_total'] >= $lims_reward_point_setting_data->minimum_amount) {
            $point = (int)($data['grand_total'] / $lims_reward_point_setting_data->per_point_amount);
            $lims_customer_data->points += $point;
            $lims_customer_data->save();
        }

        //collecting mail data
        $mail_data['email'] = $lims_customer_data->email;
        $mail_data['reference_no'] = $lims_sale_data->reference_no;
        $mail_data['sale_status'] = $lims_sale_data->sale_status;
        $mail_data['payment_status'] = $lims_sale_data->payment_status;
        $mail_data['total_qty'] = $lims_sale_data->total_qty;
        $mail_data['total_price'] = $lims_sale_data->total_price;
        $mail_data['order_tax'] = $lims_sale_data->order_tax;
        $mail_data['order_tax_rate'] = $lims_sale_data->order_tax_rate;
        $mail_data['order_discount'] = $lims_sale_data->order_discount;
        $mail_data['shipping_cost'] = $lims_sale_data->shipping_cost;
        $mail_data['grand_total'] = $lims_sale_data->grand_total;
        $mail_data['paid_amount'] = $lims_sale_data->paid_amount;

        $product_id = $data['product_id'];
        $product_batch_id = $data['product_batch_id'];
        $imei_number = $data['imei_number'];
        $product_code = $data['product_code'];
        $qty = $data['qty'];
        $sale_unit = $data['sale_unit'];
        $net_unit_price = $data['net_unit_price'];
        $discount = $data['discount'];
        $tax_rate = $data['tax_rate'];
        $tax = $data['tax'];
        $total = $data['subtotal'];
        $product_sale = [];

        foreach ($product_id as $i => $id) {
            $lims_product_data = Product::where('id', $id)->first();
            $product_sale['variant_id'] = null;
            $product_sale['product_batch_id'] = null;
            if($lims_product_data->type == 'combo' && $data['sale_status'] == 1){
                $product_list = explode(",", $lims_product_data->product_list);
                $variant_list = explode(",", $lims_product_data->variant_list);
                if($lims_product_data->variant_list)
                    $variant_list = explode(",", $lims_product_data->variant_list);
                else
                    $variant_list = [];
                $qty_list = explode(",", $lims_product_data->qty_list);
                $price_list = explode(",", $lims_product_data->price_list);

                foreach ($product_list as $key=>$child_id) {
                    $child_data = Product::find($child_id);
                    if(count($variant_list) && $variant_list[$key]) {
                        $child_product_variant_data = ProductVariant::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$key]]
                        ])->first();

                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$key]],
                            ['warehouse_id', $data['warehouse_id'] ],
                        ])->first();

                        $child_product_variant_data->qty -= $qty[$i] * $qty_list[$key];
                        $child_product_variant_data->save();
                    }
                    else {
                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['warehouse_id', $data['warehouse_id'] ],
                        ])->first();
                    }

                    $child_data->qty -= $qty[$i] * $qty_list[$key];
                    $child_warehouse_data->qty -= $qty[$i] * $qty_list[$key];

                    $child_data->save();
                    $child_warehouse_data->save();
                }
            }

            if($sale_unit[$i] != 'n/a') {
                $lims_sale_unit_data  = Unit::where('unit_name', $sale_unit[$i])->first();
                $sale_unit_id = $lims_sale_unit_data->id;
                if($lims_product_data->is_variant) {
                    $lims_product_variant_data = ProductVariant::select('id', 'variant_id', 'qty')->FindExactProductWithCode($id, $product_code[$i])->first();
                    $product_sale['variant_id'] = $lims_product_variant_data->variant_id;
                }
                if($lims_product_data->is_batch && $product_batch_id[$i]) {
                    $product_sale['product_batch_id'] = $product_batch_id[$i];
                }

                if($data['sale_status'] == 1) {
                    if($lims_sale_unit_data->operator == '*')
                        $quantity = $qty[$i] * $lims_sale_unit_data->operation_value;
                    elseif($lims_sale_unit_data->operator == '/')
                        $quantity = $qty[$i] / $lims_sale_unit_data->operation_value;
                    //deduct quantity
                    $lims_product_data->qty = $lims_product_data->qty - $quantity;
                    $lims_product_data->save();
                    //deduct product variant quantity if exist
                    if($lims_product_data->is_variant) {
                        $lims_product_variant_data->qty -= $quantity;
                        $lims_product_variant_data->save();
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithVariant($id, $lims_product_variant_data->variant_id, $data['warehouse_id'])->first();
                    }
                    elseif($product_batch_id[$i]) {
                        $lims_product_warehouse_data = Product_Warehouse::where([
                            ['product_batch_id', $product_batch_id[$i] ],
                            ['warehouse_id', $data['warehouse_id'] ]
                        ])->first();
                        $lims_product_batch_data = ProductBatch::find($product_batch_id[$i]);
                        //deduct product batch quantity
                        $lims_product_batch_data->qty -= $quantity;
                        $lims_product_batch_data->save();
                    }
                    else {
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithoutVariant($id, $data['warehouse_id'])->first();
                    }
                    //deduct quantity from warehouse
                    $lims_product_warehouse_data->qty -= $quantity;
                    $lims_product_warehouse_data->save();
                }
            }
            else
                $sale_unit_id = 0;

            if($product_sale['variant_id']) {
                $variant_data = Variant::select('name')->find($product_sale['variant_id']);
                $mail_data['products'][$i] = $lims_product_data->name . ' ['. $variant_data->name .']';
            }
            else
                $mail_data['products'][$i] = $lims_product_data->name;
            
            //deduct imei number if available
            if($imei_number[$i]) {
                $imei_numbers = explode(",", $imei_number[$i]);
                $all_imei_numbers = explode(",", $lims_product_warehouse_data->imei_number);
                foreach ($imei_numbers as $number) {
                    if (($j = array_search($number, $all_imei_numbers)) !== false) {
                        unset($all_imei_numbers[$j]);
                    }
                }
                $lims_product_warehouse_data->imei_number = implode(",", $all_imei_numbers);
                $lims_product_warehouse_data->save();
            }

            if($lims_product_data->type == 'digital')
                $mail_data['file'][$i] = url('/public/product/files').'/'.$lims_product_data->file;
            else
                $mail_data['file'][$i] = '';
            if($sale_unit_id)
                $mail_data['unit'][$i] = $lims_sale_unit_data->unit_code;
            else
                $mail_data['unit'][$i] = '';

            $product_sale['sale_id'] = $lims_sale_data->id ;
            $product_sale['product_id'] = $id;
            $product_sale['imei_number'] = $imei_number[$i];
            $product_sale['qty'] = $mail_data['qty'][$i] = $qty[$i];
            $product_sale['sale_unit_id'] = $sale_unit_id;
            $product_sale['net_unit_price'] = $net_unit_price[$i];
            $product_sale['discount'] = $discount[$i];
            $product_sale['tax_rate'] = $tax_rate[$i];
            $product_sale['tax'] = $tax[$i];
            $product_sale['total'] = $mail_data['total'][$i] = $total[$i];
            logger()->info('Product Sale Data: ' . json_encode($product_sale) );
            Product_Sale::create($product_sale);
            
        }

        //Error checer
        if($data['sale_status'] == 3)
            $message = 'Sale successfully added to Hold';
        else
            $message = ' Sale created successfully';

        // $mail_setting = MailSetting::latest()->first();
        // if($mail_data['email'] && $data['sale_status'] == 1 && $mail_setting) {
        //     $this->setMailInfo($mail_setting);
        //     try {
        //         Mail::to($mail_data['email'])->send(new SaleDetails($mail_data));
        //     }
        //     catch(\Exception $e){
        //         $message = ' Sale created successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
        //     }
        // }
        logger()->info('nessage is: ' . $message );

         //inserting data to payments table why is the 
        if($data['payment_status'] == 3 || $data['payment_status'] == 4 || ($data['payment_status'] == 2 && $data['pos'] && $data['paid_amount'] > 0)) {
            // ðŸ”¹ Step 1: Combine main and additional payments
            logger()->info('Preparing to process payments...' );
            $payment_methods = [];

            // ---- MAIN PAYMENT ----
            $payment_methods[] = [
                'paid_by_id' => $data['paid_by_id'],
                'amount' => $data['paying_amount'], // main amount
                'mobile_op' => $data['paid_by_id'] == 8 ? ($request->selected_mobile_op ?? null) : null,
                'mobile_number' => $data['paid_by_id'] == 8 ? ($request->mobile_number ?? null) : null,
            ];

            if (!empty($data['paid_by_id_select'])) {

                $paidByIds = is_array($data['paid_by_id_select']) ? $data['paid_by_id_select'] : [$data['paid_by_id_select']];
                $splitAmounts = is_array($data['split_amount'] ?? null) ? $data['split_amount'] : [];
                $mobileOps = is_array($data['selected_mobile_op'] ?? null) ? $data['selected_mobile_op'] : [];
                $mobileNumbers = is_array($data['mobile_number'] ?? null) ? $data['mobile_number'] : [];

                foreach ($paidByIds as $index => $method) {

                    // Skip this payment if split_amount for this index is missing
                    if (!isset($splitAmounts[$index])) {
                        continue;
                    }

                    $payment_methods[] = [
                        'paid_by_id' => $method,
                        'amount' => (float) $splitAmounts[$index],
                        'mobile_op' => ($method == 8) ? ($mobileOps[$index] ?? $request->selected_mobile_op ?? null) : null,
                        'mobile_number' => ($method == 8) ? ($mobileNumbers[$index] ?? $request->mobile_number ?? null) : null,
                    ];
                }
            }

            // ðŸ”¹ Step 2: Compute total paid and change
            $total_paid = array_sum(array_column($payment_methods, 'amount'));

            $total_change = ($data['total_price'] ?? 0) - $total_paid;
            // info('Total Change to Give: ' . $total_change);

            // Initialize a manual index counter
            $paymentIndex = 0;
            
            // ðŸ”¹ Process all payment methods
            foreach ($payment_methods as $payment) {
                $lims_payment_data = new Payment();
                $lims_payment_data->user_id = Auth::id();
                    
                // Map payment method names
                switch ($payment['paid_by_id']) {
                    case 1: $paying_method = 'Cash'; break;
                    case 2: $paying_method = 'Gift Card'; break;
                    case 3: $paying_method = 'Credit Card'; break;
                    case 4: $paying_method = 'Cheque'; break;
                    case 5: $paying_method = 'Paypal'; break;
                    case 6: $paying_method = 'Deposit'; break;
                    case 7:
                        $paying_method = 'Points';
                        $lims_payment_data->used_points = $data['used_points'] ?? 0;
                        break;
                    case 8: $paying_method = 'Mobile Money'; break;
                    default: $paying_method = 'Other'; break;
                }
                $lims_payment_data->paying_method = $paying_method;
                $lims_payment_data->amount =$payment['amount'];
                if($cash_register_data){
                    $lims_payment_data->cash_register_id = $cash_register_data->id;
                    $lims_account_data = Account::where('is_default', true)->first();
                    $lims_payment_data->account_id = $lims_account_data->id;
        
                    $lims_payment_data->sale_id = $lims_sale_data->id;
                    $data['payment_reference'] = 'spr-'.date("Ymd").'-'.date("his");
                    $lims_payment_data->payment_reference = $data['payment_reference'];
                    
                    // âœ… Set change only for the first payment (safe for both single/multiple)
                    $lims_payment_data->change = ($paymentIndex === 0) ? $total_change : 0;

                    if ($payment['paid_by_id'] == 8) {
                        $lims_payment_data->mobile_money_operator = $payment['mobile_op'];
                        $lims_payment_data->mobile_money_operator = $payment['mobile_number'];
                    }

                    $lims_payment_data->payment_note = $data['payment_note'];
                    $lims_payment_data->save();

                    $lims_payment_data = Payment::latest()->first();
                    $data['payment_id'] = $lims_payment_data->id;
                    $lims_pos_setting_data = PosSetting::latest()->first();

                    if($paying_method == 'Credit Card' && (strlen($lims_pos_setting_data->stripe_public_key)>0) 
                        && (strlen($lims_pos_setting_data->stripe_secret_key )>0)){

                        Stripe::setApiKey($lims_pos_setting_data->stripe_secret_key);
                        $token = $data['stripeToken'];
                        $grand_total = $data['grand_total'];

                        $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('customer_id', $data['customer_id'])->first();

                        if(!$lims_payment_with_credit_card_data) {
                            // Create a Customer:
                            $customer = \Stripe\Customer::create([
                                'source' => $token
                            ]);

                            // Charge the Customer instead of the card:
                            $charge = \Stripe\Charge::create([
                                'amount' => $grand_total * 100,
                                'currency' => 'usd',
                                'customer' => $customer->id
                            ]);
                            $data['customer_stripe_id'] = $customer->id;
                        }
                        else {
                            $customer_id =
                            $lims_payment_with_credit_card_data->customer_stripe_id;

                            $charge = \Stripe\Charge::create([
                                'amount' => $grand_total * 100,
                                'currency' => 'usd',
                                'customer' => $customer_id, // Previously stored, then retrieved
                            ]);
                            $data['customer_stripe_id'] = $customer_id;
                        }
                        $data['charge_id'] = $charge->id;
                        PaymentWithCreditCard::create($data);
                    }
                    elseif ($paying_method == 'Gift Card') {
                        $lims_gift_card_data = GiftCard::find($data['gift_card_id']);
                        $lims_gift_card_data->expense += $data['paid_amount'];
                        $lims_gift_card_data->save();
                        PaymentWithGiftCard::create($data);
                    }
                    elseif ($paying_method == 'Cheque') {
                        if($request->has('split_cheque_no')) {
                            $cheque_no = $request->split_cheque_no[0] ?? null;
                        } else {
                            $cheque_no = $data['cheque_no'] ?? null;
                        }
                        $data['cheque_no'] = $cheque_no;
                        PaymentWithCheque::create($data);
                    }
                    elseif ($paying_method == 'Paypal') {
                        $provider = new ExpressCheckout;
                        $paypal_data = [];
                        $paypal_data['items'] = [];
                        foreach ($data['product_id'] as $key => $product_id) {
                            $lims_product_data = Product::find($product_id);
                            $paypal_data['items'][] = [
                                'name' => $lims_product_data->name,
                                'price' => ($data['subtotal'][$key]/$data['qty'][$key]),
                                'qty' => $data['qty'][$key]
                            ];
                        }
                        $paypal_data['items'][] = [
                            'name' => 'Order Tax',
                            'price' => $data['order_tax'],
                            'qty' => 1
                        ];
                        $paypal_data['items'][] = [
                            'name' => 'Order Discount',
                            'price' => $data['order_discount'] * (-1),
                            'qty' => 1
                        ];
                        $paypal_data['items'][] = [
                            'name' => 'Shipping Cost',
                            'price' => $data['shipping_cost'],
                            'qty' => 1
                        ];
                        if($data['grand_total'] != $data['paid_amount']){
                            $paypal_data['items'][] = [
                                'name' => 'Due',
                                'price' => ($data['grand_total'] - $data['paid_amount']) * (-1),
                                'qty' => 1
                            ];
                        }
                        //return $paypal_data;
                        $paypal_data['invoice_id'] = $lims_sale_data->reference_no;
                        $paypal_data['invoice_description'] = "Reference # {$paypal_data['invoice_id']} Invoice";
                        $paypal_data['return_url'] = url('/sale/paypalSuccess');
                        $paypal_data['cancel_url'] = url('/sale/create');

                        $total = 0;
                        foreach($paypal_data['items'] as $item) {
                            $total += $item['price']*$item['qty'];
                        }

                        $paypal_data['total'] = $total;
                        $response = $provider->setExpressCheckout($paypal_data);
                        // This will redirect user to PayPal
                        return redirect($response['paypal_link']);
                    }
                    elseif($paying_method == 'Deposit'){
                        $lims_customer_data->expense += $data['paid_amount'];
                        $lims_customer_data->save();
                    }
                    elseif($paying_method == 'Points'){
                        $lims_customer_data->points -= $data['used_points'];
                        $lims_customer_data->save();
                    }
                    

                }
            }            
            $lims_sale_data->paid_amount = $total_paid;
            $lims_sale_data->save(); 
        }

        

                 
  

            // âœ… Loop through and save each additional cost
        if ($request->has('cost_name') && $request->has('cost_amount')) {
            // âœ… Initialize total tracker
            $totalAdditionalCost = 0;
            foreach ($request->cost_name as $index => $name) {
                $amount = (float) ($request->cost_amount[$index] ?? 0);

                if (!empty($name) && $amount > 0) {
                    // Save to SaleAdditionalCost table
                    SaleAdditionalCost::create([
                        'cost_name' => $name,
                        'cost_amount' => $amount,
                    ]);

                    // Keep running total
                    $totalAdditionalCost += $amount;
                }
            }
            $lims_sale_data->additional_cost_total = $totalAdditionalCost;
            $lims_sale_data->save();
        }

            // âœ… Optional: store the total in the sale
            

        
       
        logger()->info('Payments processed successfully.' );
        // Handle hire purchase if enabled
        if(($data['is_hire_purchase'] ?? 0) == 1) {
            logger()->info('Hire Purchase Enabled - Processing Hire Purchase Setup');
            $hirePurchaseService = new \App\Services\HirePurchaseService();
           //info('Hire Purchase Service dump: ' . print_r($hirePurchaseService, true));
          logger()->info('Service Dump', ['data' => $hirePurchaseService]);


            // Validate hire purchase data
            $validation = $hirePurchaseService->validateHirePurchase($data);
            if(!$validation['valid']) {
                $lims_sale_data->delete();
                return redirect()->back()->withErrors($validation['errors']);
            }
            
            try {
                // Create installment records
                $hirePurchaseService->createInstallments($lims_sale_data, $data['hire_purchase_start_date'] ?? null);
            } catch(\Exception $e) {
                //info('Hire Purchase Error: ');
                $message = 'Sale created but hire purchase setup failed. ' . $e->getMessage();
            }
        }
        else{
            logger()->info('Hire Purchase Not Enabled');
        }

        
        //info('Sale Stored Successfully' .json_encode($lims_sale_data));
        //DB::commit();
        if($lims_sale_data->sale_status == '1'){
            return redirect('sales/gen_invoice/' . $lims_sale_data->id)->with('message', $message);
        }
        elseif($data['pos']){
            return redirect('pos')->with('message', $message);
        }
        else{
            return redirect('sales')->with('message', $message);
        }
            
    }

    //create a show empty function 
    public function show()
    {
        
    }


    public function sendMail(Request $request)
    {
        $data = $request->all();
        $lims_sale_data = Sale::find($data['sale_id']);
        $lims_product_sale_data = Product_Sale::where('sale_id', $data['sale_id'])->get();
        $lims_customer_data = Customer::find($lims_sale_data->customer_id);
        $mail_setting = MailSetting::latest()->first();

        if(!$mail_setting) {
            return $this->setErrorMessage('Please Setup Your Mail Credentials First.');
        }
        else if($lims_customer_data->email) {
            //collecting male data
            $mail_data['email'] = $lims_customer_data->email;
            $mail_data['reference_no'] = $lims_sale_data->reference_no;
            $mail_data['sale_status'] = $lims_sale_data->sale_status;
            $mail_data['payment_status'] = $lims_sale_data->payment_status;
            $mail_data['total_qty'] = $lims_sale_data->total_qty;
            $mail_data['total_price'] = $lims_sale_data->total_price;
            $mail_data['order_tax'] = $lims_sale_data->order_tax;
            $mail_data['order_tax_rate'] = $lims_sale_data->order_tax_rate;
            $mail_data['order_discount'] = $lims_sale_data->order_discount;
            $mail_data['shipping_cost'] = $lims_sale_data->shipping_cost;
            $mail_data['grand_total'] = $lims_sale_data->grand_total;
            $mail_data['paid_amount'] = $lims_sale_data->paid_amount;

            foreach ($lims_product_sale_data as $key => $product_sale_data) {
                $lims_product_data = Product::find($product_sale_data->product_id);
                if($product_sale_data->variant_id) {
                    $variant_data = Variant::select('name')->find($product_sale_data->variant_id);
                    $mail_data['products'][$key] = $lims_product_data->name . ' [' . $variant_data->name . ']';
                }
                else
                    $mail_data['products'][$key] = $lims_product_data->name;
                if($lims_product_data->type == 'digital')
                    $mail_data['file'][$key] = url('/public/product/files').'/'.$lims_product_data->file;
                else
                    $mail_data['file'][$key] = '';
                if($product_sale_data->sale_unit_id){
                    $lims_unit_data = Unit::find($product_sale_data->sale_unit_id);
                    $mail_data['unit'][$key] = $lims_unit_data->unit_code;
                }
                else
                    $mail_data['unit'][$key] = '';

                $mail_data['qty'][$key] = $product_sale_data->qty;
                $mail_data['total'][$key] = $product_sale_data->qty;
            }
            $this->setMailInfo($mail_setting);
            try{
                Mail::to($mail_data['email'])->send(new SaleDetails($mail_data));
                return $this->setSuccessMessage('Mail sent successfully');
            }
            catch(\Exception $e){
                return $this->setErrorMessage('Please Setup Your Mail Credentials First.');
            }
        }
        else
            return $this->setErrorMessage('Customer doesnt have email!');
    }

    public function paypalSuccess(Request $request)
    {
        $lims_sale_data = Sale::latest()->first();
        $lims_payment_data = Payment::latest()->first();
        $lims_product_sale_data = Product_Sale::where('sale_id', $lims_sale_data->id)->get();
        $provider = new ExpressCheckout;
        $token = $request->token;
        $payerID = $request->PayerID;
        $paypal_data['items'] = [];
        foreach ($lims_product_sale_data as $key => $product_sale_data) {
            $lims_product_data = Product::find($product_sale_data->product_id);
            $paypal_data['items'][] = [
                'name' => $lims_product_data->name,
                'price' => ($product_sale_data->total/$product_sale_data->qty),
                'qty' => $product_sale_data->qty
            ];
        }
        $paypal_data['items'][] = [
            'name' => 'order tax',
            'price' => $lims_sale_data->order_tax,
            'qty' => 1
        ];
        $paypal_data['items'][] = [
            'name' => 'order discount',
            'price' => $lims_sale_data->order_discount * (-1),
            'qty' => 1
        ];
        $paypal_data['items'][] = [
            'name' => 'shipping cost',
            'price' => $lims_sale_data->shipping_cost,
            'qty' => 1
        ];
        if($lims_sale_data->grand_total != $lims_sale_data->paid_amount){
            $paypal_data['items'][] = [
                'name' => 'Due',
                'price' => ($lims_sale_data->grand_total - $lims_sale_data->paid_amount) * (-1),
                'qty' => 1
            ];
        }

        $paypal_data['invoice_id'] = $lims_payment_data->payment_reference;
        $paypal_data['invoice_description'] = "Reference: {$paypal_data['invoice_id']}";
        $paypal_data['return_url'] = url('/sale/paypalSuccess');
        $paypal_data['cancel_url'] = url('/sale/create');

        $total = 0;
        foreach($paypal_data['items'] as $item) {
            $total += $item['price']*$item['qty'];
        }

        $paypal_data['total'] = $lims_sale_data->paid_amount;
        $response = $provider->getExpressCheckoutDetails($token);
        $response = $provider->doExpressCheckoutPayment($paypal_data, $token, $payerID);
        $data['payment_id'] = $lims_payment_data->id;
        $data['transaction_id'] = $response['PAYMENTINFO_0_TRANSACTIONID'];
        PaymentWithPaypal::create($data);
        return redirect('sales')->with('message', 'Sales created successfully');
    }

    public function paypalPaymentSuccess(Request $request, $id)
    {
        $lims_payment_data = Payment::find($id);
        $provider = new ExpressCheckout;
        $token = $request->token;
        $payerID = $request->PayerID;
        $paypal_data['items'] = [];
        $paypal_data['items'][] = [
            'name' => 'Paid Amount',
            'price' => $lims_payment_data->amount,
            'qty' => 1
        ];
        $paypal_data['invoice_id'] = $lims_payment_data->payment_reference;
        $paypal_data['invoice_description'] = "Reference: {$paypal_data['invoice_id']}";
        $paypal_data['return_url'] = url('/sale/paypalPaymentSuccess');
        $paypal_data['cancel_url'] = url('/sale');

        $total = 0;
        foreach($paypal_data['items'] as $item) {
            $total += $item['price']*$item['qty'];
        }

        $paypal_data['total'] = $total;
        $response = $provider->getExpressCheckoutDetails($token);
        $response = $provider->doExpressCheckoutPayment($paypal_data, $token, $payerID);
        $data['payment_id'] = $lims_payment_data->id;
        $data['transaction_id'] = $response['PAYMENTINFO_0_TRANSACTIONID'];
        PaymentWithPaypal::create($data);
        return redirect('sales')->with('message', 'Payment created successfully');
    }

    public function getProduct($id)
    {
        $query = Product::join('product_warehouse', 'products.id', '=', 'product_warehouse.product_id');
        if(config('without_stock') == 'no') {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id],
                ['product_warehouse.qty', '>', 0]
            ]);
        }
        else {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id]
            ]);
        }
        $lims_product_warehouse_data = $query->whereNull('product_warehouse.variant_id')
                                        ->whereNull('product_warehouse.product_batch_id')
                                        ->select('product_warehouse.*',  'products.is_embeded')
                                        ->get();

        config()->set('database.connections.mysql.strict', false);
        \DB::reconnect(); //important as the existing connection if any would be in strict mode

        $query = Product::join('product_warehouse', 'products.id', '=', 'product_warehouse.product_id');

        if(config('without_stock') == 'no') {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id],
                ['product_warehouse.qty', '>', 0]
            ]);
        }
        else {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id]
            ]);
        }

        $lims_product_with_batch_warehouse_data = $query->whereNull('product_warehouse.variant_id')
        ->whereNotNull('product_warehouse.product_batch_id')
        ->select('product_warehouse.*', 'products.is_embeded')
        ->groupBy('product_warehouse.product_id')
        ->get();

        //now changing back the strict ON
        config()->set('database.connections.mysql.strict', true);
        \DB::reconnect();

        $query = Product::join('product_warehouse', 'products.id', '=', 'product_warehouse.product_id');
        if(config('without_stock') == 'no') {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id],
                ['product_warehouse.qty', '>', 0]
            ]);
        }
        else {
            $query = $query->where([
                ['products.is_active', true],
                ['product_warehouse.warehouse_id', $id],
            ]);
        }
        $lims_product_with_variant_warehouse_data = $query->whereNotNull('product_warehouse.variant_id')
        ->select('product_warehouse.*', 'products.is_embeded')
        ->get();

        $product_code = [];
        $product_name = [];
        $product_qty = [];
        $product_type = [];
        $product_id = [];
        $product_list = [];
        $qty_list = [];
        $product_price = [];
        $batch_no = [];
        $product_batch_id = [];
        $expired_date = [];
        $is_embeded = [];
        //additional
        $product_shelf = [];
        //product without variant
        foreach ($lims_product_warehouse_data as $product_warehouse)
        {
            $product_qty[] = $product_warehouse->qty;
            $lims_product_data = Product::find($product_warehouse->product_id);
            $product_code[] =  $lims_product_data->code;
            $product_name[] = htmlspecialchars($lims_product_data->name);
            $product_type[] = $lims_product_data->type;
            $product_id[] = $lims_product_data->id;
            $product_list[] = $lims_product_data->product_list;
            $product_shelf[] = $lims_product_data->shelf ?? 'NA';
            $product_price[] = $lims_product_data->price;
            $qty_list[] = $lims_product_data->qty_list;
            $batch_no[] = null;
            $product_batch_id[] = null;
            $expired_date[] = null;
            if($product_warehouse->is_embeded)
                $is_embeded[] = $product_warehouse->is_embeded;
            else
                $is_embeded[] = 0;
        }
        //product with batches
        foreach ($lims_product_with_batch_warehouse_data as $product_warehouse)
        {
            $product_qty[] = $product_warehouse->qty;
            $lims_product_data = Product::find($product_warehouse->product_id);
            $product_code[] =  $lims_product_data->code;
            $product_name[] = htmlspecialchars($lims_product_data->name);
            $product_type[] = $lims_product_data->type;
            $product_id[] = $lims_product_data->id;
            $product_list[] = $lims_product_data->product_list;
            $product_shelf[] = $lims_product_data->product_shelf ?? 'NA';
            $product_price[] = $lims_product_data->price;
            $qty_list[] = $lims_product_data->qty_list;
            $product_batch_data = ProductBatch::select('id', 'batch_no', 'expired_date')->find($product_warehouse->product_batch_id);
            $batch_no[] = $product_batch_data->batch_no;
            $product_batch_id[] = $product_batch_data->id;
            $expired_date[] = date(config('date_format'), strtotime($product_batch_data->expired_date));
            if($product_warehouse->is_embeded)
                $is_embeded[] = $product_warehouse->is_embeded;
            else
                $is_embeded[] = 0;
        }
        //product with variant
        foreach ($lims_product_with_variant_warehouse_data as $product_warehouse)
        {
            $product_qty[] = $product_warehouse->qty;
           
            $lims_product_data = Product::find($product_warehouse->product_id);
            $lims_product_variant_data = ProductVariant::select('item_code')->FindExactProduct($product_warehouse->product_id, $product_warehouse->variant_id)->first();
            
            if($lims_product_variant_data) {
                $product_code[] =  $lims_product_variant_data->item_code;
                $product_name[] = htmlspecialchars($lims_product_data->name);
                $product_type[] = $lims_product_data->type;
                $product_id[] = $lims_product_data->id;
                $product_list[] = $lims_product_data->product_list;
                $product_shelf[] = $lims_product_data->shelf ?? 'NA';
                $product_price[] = $lims_product_data->price;
                $qty_list[] = $lims_product_data->qty_list;
                $batch_no[] = null;
                $product_batch_id[] = null;
                $expired_date[] = null;
                if($product_warehouse->is_embeded)
                    $is_embeded[] = $product_warehouse->is_embeded;
                else
                    $is_embeded[] = 0;
            }
        }
        //retrieve product with type of digital, combo and service
        $lims_product_data = Product::whereNotIn('type', ['standard'])->where('is_active', true)->get();
        foreach ($lims_product_data as $product)
        {
            $product_qty[] = $product->qty;
            $product_price[] = $product->price ?? 'NA';
            $product_code[] =  $product->code;
            $product_name[] = $product->name;
            $product_type[] = $product->type;
            $product_id[] = $product->id;
            $product_list[] = $product->product_list;
            $product_shelf[] = $product->shelf ?? 'NA';
            $qty_list[] = $product->qty_list;
            $batch_no[] = null;
            $product_batch_id[] = null;
            $expired_date[] = null;
            $is_embeded[] = 0;
        }
        $product_data = [
            $product_code, 
            $product_name, 
            $product_qty, 
            $product_type, 
            $product_id, 
            $product_list, 
            $qty_list, 
            $product_price,  
            $batch_no, 
            $product_batch_id, 
            $expired_date, 
            $is_embeded,
            $product_shelf,
        ];
        return $product_data;
    }

    /**
     * Get user permissions with caching
     * @return array
     */
    private function getUserPermissions()
    {
        $user = Auth::user();
        $cacheKey = 'user_permissions_' . $user->id;

        return Cache::remember($cacheKey, 60 * 60 * 24, function () use ($user) {
            // Fetch all permission names from all roles of the user
            $permissions = $user->roles()
                ->with('permissions')
                ->get()
                ->pluck('permissions.*.name')
                ->flatten()
                ->unique()
                ->values()
                ->toArray();

            // Return as an associative array with true values (like before)
            return array_combine($permissions, array_fill(0, count($permissions), true));
        });
    }

    /**
     * Get POS dashboard data with caching
     * @return array
     */
    private function getPosDashboardData()
    {
        // Get customer list
        $lims_customer_list = Cache::remember('customer_list', 60*60*24, function () {
            return Customer::select('id', 'name', 'phone_number')->where('is_active', true)->get();
        });

        // Get customer groups
        $lims_customer_group_all = Cache::remember('customer_group_list', 60*60*24, function () {
            return CustomerGroup::select('id', 'name')->where('is_active', true)->get();
        });

        // Get warehouses
        $lims_warehouse_list = Cache::remember('warehouse_list', 60*60*24*365, function () {
            return Warehouse::select('id', 'name')->where('is_active', true)->get();
        });

        // Get billers
        $lims_biller_list = Cache::remember('biller_list', 60*60*24*30, function () {
            return Biller::select('id', 'name', 'company_name')->where('is_active', true)->get();
        });

        // Get taxes
        $lims_tax_list = Cache::remember('tax_list', 60*60*24*30, function () {
            return Tax::where('is_active', true)->get();
        });

        // Get brands
        $lims_brand_list = Cache::remember('brand_list', 60*60*24*30, function () {
            return Brand::select('id', 'image', 'title')->where('is_active', true)->get();
        });

        // Get categories
        $lims_category_list = Cache::remember('category_list', 60*60*24*30, function () {
            return Category::select('id', 'image')->where('is_active', true)->get();
        });

        // Get tables
        $lims_table_list = Cache::remember('table_list', 60*60*24*30, function () {
            return Table::select('id', 'name')->where('is_active', true)->get();
        });

        // Get coupons
        $lims_coupon_list = Cache::remember('coupon_list', 60*60*24*30, function () {
            return Coupon::where('is_active', true)->get();
        });

        // Get featured products (standard)
        $lims_product_list = Cache::remember('product_list', 60*60*24, function () {
            return Product::ActiveFeatured()->whereNull('is_variant')->get();
        });

        // Process product images
        foreach ($lims_product_list as $key => $product) {
            $images = explode(",", $product->image);
            $product->base_image = ($images[0] ?? null) ?: 'zummXD2dvAtI.png';
        }

        // Get featured products with variants
        $lims_product_list_with_variant = Cache::remember('product_list_with_variant', 60*60*24, function () {
            return Product::ActiveFeatured()->whereNotNull('is_variant')->get();
        });

        // Process variant products
        foreach ($lims_product_list_with_variant as $product) {
            $images = explode(",", $product->image);
            $product->base_image = ($images[0] ?? null) ?: 'zummXD2dvAtI.png';
            
            $lims_product_variant_data = $product->variant()->orderBy('position')->get();
            $main_name = $product->name;
            
            foreach ($lims_product_variant_data as $variant) {
                $product->name = $main_name . ' [' . $variant->name . ']';
                $product->code = $variant->pivot['item_code'];
                $lims_product_list[] = clone($product);
            }
        }

        // POS settings
        $lims_pos_setting_data = Cache::remember('pos_setting', 60*60*24*30, function () {
            return PosSetting::latest()->select('stripe_public_key','product_number','payment_options','customer_id','warehouse_id','biller_id')->first();
        });
        
        logger()->info('POS Setting Data: ' . json_encode($lims_pos_setting_data));

        $options = [];
        if($lims_pos_setting_data && !empty($lims_pos_setting_data->payment_options)) {
            $options = array_filter(explode(',', $lims_pos_setting_data->payment_options));
        }

        // Reward points settings
        $lims_reward_point_setting_data = RewardPointSetting::latest()->first();

        // Recent sales and drafts with eager loaded customer data
        if ($this->isStaff() && config('staff_access') == 'own') {
            $recent_sale = Sale::select('id','reference_no','customer_id','grand_total','created_at')
                ->with('customer:id,name')
                ->where([['sale_status', 1], ['user_id', Auth::id()]])
                ->orderBy('id', 'desc')
                ->take(10)
                ->get();
            
            $recent_draft = Sale::select('id','reference_no','customer_id','grand_total','created_at')
                ->with('customer:id,name')
                ->where([['sale_status', 3], ['user_id', Auth::id()]])
                ->orderBy('id', 'desc')
                ->take(10)
                ->get();
        } else {
            $recent_sale = Sale::select('id','reference_no','customer_id','grand_total','created_at')
                ->with('customer:id,name')
                ->where('sale_status', 1)
                ->orderBy('id', 'desc')
                ->take(10)
                ->get();
            
            $recent_draft = Sale::select('id','reference_no','customer_id','grand_total','created_at')
                ->with('customer:id,name')
                ->where('sale_status', 3)
                ->orderBy('id', 'desc')
                ->take(10)
                ->get();
        }

        // Currencies
        $currency_list = Currency::where('is_active', true)->get();

        // Custom fields
        $custom_fields = CustomField::where('belongs_to', 'sale')->get();

        return [
            'lims_customer_list' => $lims_customer_list,
            'lims_customer_group_all' => $lims_customer_group_all,
            'lims_warehouse_list' => $lims_warehouse_list,
            'lims_biller_list' => $lims_biller_list,
            'lims_tax_list' => $lims_tax_list,
            'lims_brand_list' => $lims_brand_list,
            'lims_category_list' => $lims_category_list,
            'lims_table_list' => $lims_table_list,
            'lims_coupon_list' => $lims_coupon_list,
            'lims_product_list' => $lims_product_list,
            'lims_pos_setting_data' => $lims_pos_setting_data,
            'options' => $options,
            'lims_reward_point_setting_data' => $lims_reward_point_setting_data,
            'recent_sale' => $recent_sale,
            'recent_draft' => $recent_draft,
            'currency_list' => $currency_list,
            'custom_fields' => $custom_fields,
            'general_setting' => GeneralSetting::latest()->first(),
            'deposit' => [],
            'points' => [],
            // 'alert_product' => Product::where('is_active', true)
            //     ->whereRaw('qty <= low_stock_quantity')
            //     ->count(),
            'alert_product' => 0,
            'currency' => Currency::where('is_active', true)->latest()->first(),
            'product_number' => count($lims_product_list),
            'numberOfInvoice' => Sale::count(),
        ];
    }

public function posSale()
{
    // Multi-role permission check – aggregates all roles
    if (!Auth::user()->hasPermissionTo('sales-add')) {
        return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    // Get cached permissions (already multi-role aware)
    $permissions = $this->getUserPermissions();
    
    // Get all dashboard data (cached)
    $dashboardData = $this->getPosDashboardData();

    // Pre-compute permission checks
    $permissionChecks = [
        'category'             => isset($permissions['category']),
        'products-add'         => isset($permissions['products-add']),
        'purchases-add'        => isset($permissions['purchases-add']),
        'sales-add'            => isset($permissions['sales-add']),
        'sales-edit'           => isset($permissions['sales-edit']),
        'sales-delete'         => isset($permissions['sales-delete']),
        'expenses-add'         => isset($permissions['expenses-add']),
        'quotes-add'           => isset($permissions['quotes-add']),
        'transfers-add'        => isset($permissions['transfers-add']),
        'returns-add'          => isset($permissions['returns-add']),
        'purchase-return-add'  => isset($permissions['purchase-return-add']),
        'users-add'            => isset($permissions['users-add']),
        'customers-add'        => isset($permissions['customers-add']),
        'billers-add'          => isset($permissions['billers-add']),
        'suppliers-add'        => isset($permissions['suppliers-add']),
        'general_setting'      => isset($permissions['general_setting']),
        'pos_setting'          => isset($permissions['pos_setting']),
        'today_sale'           => isset($permissions['today_sale']),
        'today_profit'         => isset($permissions['today_profit']),
    ];

    // Combine for view – no more $role; the view will use shared $isAdmin/$userRoles
    $viewData = array_merge(
        compact('permissions', 'permissionChecks'),
        $dashboardData,
        ['flag' => 0]
    );

    return view('backend.sale.pos', $viewData);
}

    /**
     * Invalidate permission cache for a specific user
     * Call this when user permissions change
     * @param int $roleId
     */
    public function invalidatePermissionCache($roleId = null)
    {
        if ($roleId) {
            // A specific role ID was provided – clear its cached permissions
            Cache::forget('role_has_permissions_list' . $roleId);
        } else {
            // No role ID given – clear all roles of the authenticated user
            $user = Auth::user();
            if ($user) {
                foreach ($user->roles as $role) {
                    Cache::forget('role_has_permissions_list' . $role->id);
                }
                // Also clear any aggregated user‑level permission cache
                Cache::forget('user_permissions_' . $user->id);
            }
        }
    }

    /**
     * Invalidate customer-related caches
     * Call this when customers or customer groups are created/updated/deleted
     */
    public function invalidateCustomerCache()
    {
        Cache::forget('customer_list');
        Cache::forget('customer_group_list');
    }

    /**
     * Invalidate product-related caches
     * Call this when products are created/updated/deleted
     */
    public function invalidateProductCache()
    {
        Cache::forget('product_list');
        Cache::forget('product_list_with_variant');
    }

    /**
     * Invalidate inventory-related caches
     * Call this when warehouse or stock data changes
     */
    public function invalidateInventoryCache()
    {
        Cache::forget('warehouse_list');
    }

    /**
     * Invalidate sales reference data caches
     * Call this when billers, taxes, brands, categories, coupons, or POS settings change
     */
    public function invalidateReferenceDataCache()
    {
        Cache::forget('biller_list');
        Cache::forget('tax_list');
        Cache::forget('brand_list');
        Cache::forget('category_list');
        Cache::forget('table_list');
        Cache::forget('coupon_list');
        Cache::forget('pos_setting');
    }

    /**
     * Invalidate all sales-related caches
     * Use this when you're not sure which specific cache to invalidate
     */
    public function invalidateAllSalesCache()
    {
        $this->invalidatePermissionCache();
        $this->invalidateCustomerCache();
        $this->invalidateProductCache();
        $this->invalidateInventoryCache();
        $this->invalidateReferenceDataCache();
    }

    public function createSale($id)
    {
        // dd($id);
        if(Auth::user()->hasPermissionTo('sales-edit')) {
            $permissions = Auth::user()->getAllPermissions();
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $lims_customer_list = Customer::where('is_active', true)->get();
            $lims_customer_group_all = CustomerGroup::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_tax_list = Tax::where('is_active', true)->get();
            $lims_sale_data = Sale::find($id);
            

            $lims_product_sale_data = Product_Sale::where('sale_id', $lims_sale_data->id)->get();
            // check the total_qty of sale is the same as the amount of  $lims_product_sale_data showcased as Illuminate\Database\Eloquent\Collection {#3273 â–¼ // app/Http/Controllers/SaleController.php:1264
  
          if($lims_sale_data->total_qty != $lims_product_sale_data->count()){
            //dd('not same');
              // if not the same, we need to recalculate the qty of each product in the sale calculate the 
              $product_sale_grouped = $lims_product_sale_data->groupBy('product_id');
              $new_lims_product_sale_data = collect();
              foreach($product_sale_grouped as $product_id => $product_sales){
                  $total_qty_for_product = 0;
                  foreach($product_sales as $product_sale){
                      $total_qty_for_product += $product_sale->qty;
                  }
                  $first_product_sale = $product_sales->first();
                  $first_product_sale->qty = $total_qty_for_product;
                  $new_lims_product_sale_data->push($first_product_sale);
              }
              $lims_product_sale_data = $new_lims_product_sale_data;
          }
               
            
           // dd($lims_sale_data);
          
            $lims_product_list = Product::where([
                                    ['featured', 1],
                                    ['is_active', true]
                                ])->get();
            foreach ($lims_product_list as $key => $product) {
                $images = explode(",", $product->image);
                if($images[0])
                    $product->base_image = $images[0];
                else
                    $product->base_image = 'zummXD2dvAtI.png';
            }
            $product_number = count($lims_product_list);
            $lims_pos_setting_data = PosSetting::latest()->first();
            $lims_brand_list = Brand::where('is_active',true)->get();
            $lims_category_list = Category::where('is_active',true)->get();
            $lims_coupon_list = Coupon::where('is_active',true)->get();
            $custom_fields = CustomField::where('belongs_to', 'sale')->get();

            $currency_list = Currency::where('is_active', true)->get();
            if($lims_pos_setting_data)
                    $options = explode(',', $lims_pos_setting_data->payment_options);
                else
                    $options = [];

            if($this->isStaff() && config('staff_access') == 'own') {
                $recent_sale = Sale::select('id','reference_no','customer_id','grand_total','created_at')->where([
                    ['sale_status', 1],
                    ['user_id', Auth::id()]
                ])->orderBy('id', 'desc')->take(10)->get();
                $recent_draft = Sale::select('id','reference_no','customer_id','grand_total','created_at')->where([
                    ['sale_status', 3],
                    ['user_id', Auth::id()]
                ])->orderBy('id', 'desc')->take(10)->get();
            }
            else {
                $recent_sale = Sale::select('id','reference_no','customer_id','grand_total','created_at')->where('sale_status', 1)->orderBy('id', 'desc')->take(10)->get();
                $recent_draft = Sale::select('id','reference_no','customer_id','grand_total','created_at')->where('sale_status', 3)->orderBy('id', 'desc')->take(10)->get();
            }
            
            // Build deposit and points arrays for all customers
            $deposit = [];
            $points = [];
            foreach($lims_customer_list as $customer) {
                $deposit[$customer->id] = $customer->deposit - $customer->expense;
                $points[$customer->id] = $customer->points;
            }
            
            //dd all values returned in compact
            //dd(compact('currency_list', 'lims_biller_list', 'lims_customer_list', 'lims_warehouse_list', 'lims_tax_list', 'lims_sale_data','lims_product_sale_data', 'lims_pos_setting_data', 'lims_brand_list', 'lims_category_list', 'lims_coupon_list', 'lims_product_list', 'product_number', 'lims_customer_group_all', 'lims_reward_point_setting_data', 'options', 'custom_fields', 'recent_sale', 'recent_draft', 'role', 'all_permission'));
            return view('backend.sale.create_sale',compact('currency_list', 'lims_biller_list', 'lims_customer_list', 'lims_warehouse_list', 'lims_tax_list', 'lims_sale_data','lims_product_sale_data', 'lims_pos_setting_data', 'lims_brand_list', 'lims_category_list', 'lims_coupon_list', 'lims_product_list', 'product_number', 'lims_customer_group_all', 'lims_reward_point_setting_data', 'options', 'custom_fields', 'recent_sale', 'recent_draft', 'role', 'all_permission', 'deposit', 'points'));
        }
        else
           
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function getProductByFilter($category_id, $brand_id)
    {
        $data = [];
        
        // Build base query with eager loading to avoid N+1 queries
        $query = Product::with('variant');
        
        if(($category_id != 0) && ($brand_id != 0)){
            $query = $query->join('categories', 'products.category_id', '=', 'categories.id')
                            ->where([
                                ['products.is_active', true],
                                ['products.category_id', $category_id],
                                ['brand_id', $brand_id]
                            ])->orWhere([
                                ['categories.parent_id', $category_id],
                                ['products.is_active', true],
                                ['brand_id', $brand_id]
                            ])->select('products.id', 'products.name', 'products.code', 'products.image', 'products.is_variant');
        }
        elseif(($category_id != 0) && ($brand_id == 0)){
            $query = $query->join('categories', 'products.category_id', '=', 'categories.id')
                            ->where([
                                ['products.is_active', true],
                                ['products.category_id', $category_id],
                            ])->orWhere([
                                ['categories.parent_id', $category_id],
                                ['products.is_active', true]
                            ])->select('products.id', 'products.name', 'products.code', 'products.image', 'products.is_variant');
        }
        elseif(($category_id == 0) && ($brand_id != 0)){
            $query = $query->where([
                                ['brand_id', $brand_id],
                                ['is_active', true]
                            ])->select('products.id', 'products.name', 'products.code', 'products.image', 'products.is_variant');
        }
        else {
            $query = $query->where('is_active', true)->select('products.id', 'products.name', 'products.code', 'products.image', 'products.is_variant');
        }
        
        $lims_product_list = $query->get();

        $index = 0;
        foreach ($lims_product_list as $product) {
            if($product->is_variant) {
                // Use eager loaded variants - no additional query needed
                $lims_product_variant_data = $product->variant()->orderBy('position')->get();
                foreach ($lims_product_variant_data as $key => $variant) {
                    $data['name'][$index] = $product->name.' ['.$variant->name.']';
                    $data['code'][$index] = $variant->pivot['item_code'];
                    $images = explode(",", $product->image);
                    $data['image'][$index] = $images[0];
                    $index++;
                }
            }
            else {
                $data['name'][$index] = $product->name;
                $data['code'][$index] = $product->code;
                $images = explode(",", $product->image);
                $data['image'][$index] = $images[0];
                $index++;
            }
        }
        return $data;
    }

    public function getFeatured()
    {
        $data = [];
        $lims_product_list = Product::where([
            ['is_active', true],
            ['featured', true]
        ])->select('products.id', 'products.name', 'products.code', 'products.image', 'products.is_variant')->get();

        $index = 0;
        foreach ($lims_product_list as $product) {
            if($product->is_variant) {
                $lims_product_data = Product::select('id')->find($product->id);
                $lims_product_variant_data = $lims_product_data->variant()->orderBy('position')->get();
                foreach ($lims_product_variant_data as $key => $variant) {
                    $data['name'][$index] = $product->name.' ['.$variant->name.']';
                    $data['code'][$index] = $variant->pivot['item_code'];
                    $images = explode(",", $product->image);
                    $data['image'][$index] = $images[0];
                    $index++;
                }
            }
            else {
                $data['name'][$index] = $product->name;
                $data['code'][$index] = $product->code;
                $images = explode(",", $product->image);
                $data['image'][$index] = $images[0];
                $index++;
            }
        }
        return $data;
    }

    public function getCustomerGroup($id)
    {
         $lims_customer_data = Customer::find($id);
         $lims_customer_group_data = CustomerGroup::find($lims_customer_data->customer_group_id);
         return $lims_customer_group_data->percentage;
    }

    
    public function limsProductSearch(Request $request)
    {
        $todayDate = date('Y-m-d');
        $data = $request->input('data');
        
        // Parse the incoming data: "productCode?customer_id?qty"
        $product_info = explode('?', $data);
        $product_code = isset($product_info[0]) ? trim($product_info[0]) : null;
        $customer_id = isset($product_info[1]) ? $product_info[1] : null;
        $qty = isset($product_info[2]) ? $product_info[2] : 1;

        // Validate required fields
        if (!$product_code) {
            return response()->json(['error' => 'Product code is required'], 400);
        }

        $product_variant_id = null;
        
        // Get all discounts for this customer
        $all_discount = DB::table('discount_plan_customers')
                        ->join('discount_plans', 'discount_plans.id', '=', 'discount_plan_customers.discount_plan_id')
                        ->join('discount_plan_discounts', 'discount_plans.id', '=', 'discount_plan_discounts.discount_plan_id')
                        ->join('discounts', 'discounts.id', '=', 'discount_plan_discounts.discount_id')
                        ->where([
                            ['discount_plans.is_active', true],
                            ['discounts.is_active', true],
                            ['discount_plan_customers.customer_id', $customer_id]
                        ])
                        ->select('discounts.*')
                        ->get();

        // Try to find product by exact code match first
        $lims_product_data = Product::where([
            ['code', $product_code],
            ['is_active', true]
        ])->first();

        // If not found, try to find by product name (for the new system)
        if (!$lims_product_data) {
            $lims_product_data = Product::where([
                ['name', 'LIKE', '%' . $product_code . '%'],
                ['is_active', true]
            ])->first();
        }

        // If still not found, try to find by variant item code
        if (!$lims_product_data) {
            $lims_product_data = Product::join('product_variants', 'products.id', '=', 'product_variants.product_id')
                ->select('products.*', 'product_variants.id as product_variant_id', 'product_variants.item_code', 'product_variants.additional_price')
                ->where([
                    ['product_variants.item_code', $product_code],
                    ['products.is_active', true]
                ])->first();
            
            if ($lims_product_data) {
                $product_variant_id = $lims_product_data->product_variant_id;
            }
        }

        // Product not found - return error
        if (!$lims_product_data) {
            return response()->json(['error' => 'Product not found. Please check the product name/code and try again.'], 404);
        }

        // Build product response array
        $product = [];
        $product[] = $lims_product_data->name;
        
        if ($lims_product_data->is_variant) {
            $product[] = $lims_product_data->item_code;
            $lims_product_data->price += $lims_product_data->additional_price;
        } else {
            $product[] = $lims_product_data->code;
        }

        // Apply discounts logic
        $no_discount = 1;
        foreach ($all_discount as $key => $discount) {
            $product_list = explode(",", $discount->product_list);
            $days = explode(",", $discount->days);

            if (($discount->applicable_for == 'All' || in_array($lims_product_data->id, $product_list)) && 
                ($todayDate >= $discount->valid_from && $todayDate <= $discount->valid_till && 
                in_array(date('D'), $days) && $qty >= $discount->minimum_qty && $qty <= $discount->maximum_qty)) {
                
                if ($discount->type == 'flat') {
                    $product[] = $lims_product_data->price - $discount->value;
                } elseif ($discount->type == 'percentage') {
                    $product[] = $lims_product_data->price - ($lims_product_data->price * ($discount->value / 100));
                }
                $no_discount = 0;
                break;
            }
        }

        if ($lims_product_data->promotion && $todayDate <= $lims_product_data->last_date && $no_discount) {
            $product[] = $lims_product_data->promotion_price;
        } elseif ($no_discount) {
            $product[] = $lims_product_data->price;
        }

        // Tax information
        if ($lims_product_data->tax_id) {
            $lims_tax_data = Tax::find($lims_product_data->tax_id);
            $product[] = $lims_tax_data->rate;
            $product[] = $lims_tax_data->name;
        } else {
            $product[] = 0;
            $product[] = 'No Tax';
        }
        
        $product[] = $lims_product_data->tax_method;

        // Unit information
        if ($lims_product_data->type == 'standard') {
            $units = Unit::where("base_unit", $lims_product_data->unit_id)
                    ->orWhere('id', $lims_product_data->unit_id)
                    ->get();
            $unit_name = array();
            $unit_operator = array();
            $unit_operation_value = array();
            foreach ($units as $unit) {
                if ($lims_product_data->sale_unit_id == $unit->id) {
                    array_unshift($unit_name, $unit->unit_name);
                    array_unshift($unit_operator, $unit->operator);
                    array_unshift($unit_operation_value, $unit->operation_value);
                } else {
                    $unit_name[] = $unit->unit_name;
                    $unit_operator[] = $unit->operator;
                    $unit_operation_value[] = $unit->operation_value;
                }
            }
            $product[] = implode(",", $unit_name) . ',';
            $product[] = implode(",", $unit_operator) . ',';
            $product[] = implode(",", $unit_operation_value) . ',';
        } else {
            $product[] = 'n/a,';
            $product[] = 'n/a,';
            $product[] = 'n/a,';
        }

        $product[] = $lims_product_data->id;
        $product[] = $product_variant_id;
        $product[] = $lims_product_data->promotion;
        $product[] = $lims_product_data->is_batch;
        $product[] = $lims_product_data->is_imei;
        $product[] = $lims_product_data->is_variant;
        $product[] = $qty;
        $product[] = $lims_product_data->wholesale_price;

        return $product;
    }
    
    public function checkDiscount(Request $request)
    {
        $qty = $request->input('qty');
        $customer_id = $request->input('customer_id');
        $lims_product_data = Product::select('id', 'price', 'promotion', 'promotion_price', 'last_date')->find($request->input('product_id'));
        $todayDate = date('Y-m-d');
        $all_discount = DB::table('discount_plan_customers')
                        ->join('discount_plans', 'discount_plans.id', '=', 'discount_plan_customers.discount_plan_id')
                        ->join('discount_plan_discounts', 'discount_plans.id', '=', 'discount_plan_discounts.discount_plan_id')
                        ->join('discounts', 'discounts.id', '=', 'discount_plan_discounts.discount_id')
                        ->where([
                            ['discount_plans.is_active', true],
                            ['discounts.is_active', true],
                            ['discount_plan_customers.customer_id', $customer_id]
                        ])
                        ->select('discounts.*')
                        ->get();
        $no_discount = 1;
        foreach ($all_discount as $key => $discount) {
            $product_list = explode(",", $discount->product_list);
            $days = explode(",", $discount->days);

            if( ( $discount->applicable_for == 'All' || in_array($lims_product_data->id, $product_list) ) && ( $todayDate >= $discount->valid_from && $todayDate <= $discount->valid_till && in_array(date('D'), $days) && $qty >= $discount->minimum_qty && $qty <= $discount->maximum_qty ) ) {
                if($discount->type == 'flat') {
                    $price = $lims_product_data->price - $discount->value;
                }
                elseif($discount->type == 'percentage') {
                    $price = $lims_product_data->price - ($lims_product_data->price * ($discount->value/100));
                }
                $no_discount = 0;
                break;
            }
            else {
                continue;
            }
        }

        if($lims_product_data->promotion && $todayDate <= $lims_product_data->last_date && $no_discount) {
            $price = $lims_product_data->promotion_price;
        }
        elseif($no_discount)
            $price = $lims_product_data->price;

        $data = [$price, $lims_product_data->promotion];
        return $data;
    }

    public function getGiftCard()
    {
        $gift_card = GiftCard::where("is_active", true)->whereDate('expired_date', '>=', date("Y-m-d"))->get(['id', 'card_no', 'amount', 'expense']);
        return json_encode($gift_card);
    }

    public function productSaleData($id)
    {
        $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
        foreach ($lims_product_sale_data as $key => $product_sale_data) {
            $product = Product::find($product_sale_data->product_id);
            if($product_sale_data->variant_id) {
                $lims_product_variant_data = ProductVariant::select('item_code')->FindExactProduct($product_sale_data->product_id, $product_sale_data->variant_id)->first();
                $product->code = $lims_product_variant_data->item_code;
            }
            $unit_data = Unit::find($product_sale_data->sale_unit_id);
            if($unit_data){
                $unit = $unit_data->unit_code;
            }
            else
                $unit = '';
            if($product_sale_data->product_batch_id) {
                $product_batch_data = ProductBatch::select('batch_no')->find($product_sale_data->product_batch_id);
                $product_sale[7][$key] = $product_batch_data->batch_no;
            }
            else
                $product_sale[7][$key] = 'N/A';
            $product_sale[0][$key] = $product->name . ' [' . $product->code . ']';
            if($product_sale_data->imei_number)
                $product_sale[0][$key] .= '<br>IMEI or Serial Number: '. $product_sale_data->imei_number;
            $product_sale[1][$key] = $product_sale_data->qty;
            $product_sale[2][$key] = $unit;
            $product_sale[3][$key] = $product_sale_data->tax;
            $product_sale[4][$key] = $product_sale_data->tax_rate;
            $product_sale[5][$key] = $product_sale_data->discount;
            $product_sale[6][$key] = $product_sale_data->total;
            $product_sale[8][$key] = $product_sale_data->return_qty;
        }
        return $product_sale;
    }

    public function saleByCsv()
    {
        
        if(Auth::user()->hasPermissionTo('sales-add')){
            $lims_customer_list = Customer::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_tax_list = Tax::where('is_active', true)->get();
            $numberOfInvoice = Sale::count();
            return view('backend.sale.import',compact('lims_customer_list', 'lims_warehouse_list', 'lims_biller_list', 'lims_tax_list', 'numberOfInvoice'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function importSale(Request $request)
    {
        //get the file
        $upload=$request->file('file');
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        //checking if this is a CSV file
        if($ext != 'csv')
            return redirect()->back()->with('message', 'Please upload a CSV file');

        $filePath=$upload->getRealPath();
        $file_handle = fopen($filePath, 'r');
        $i = 0;
        //validate the file
        while (!feof($file_handle) ) {
            $current_line = fgetcsv($file_handle);
            if($current_line && $i > 0){
                $product_data[] = Product::where('code', $current_line[0])->first();
                if(!$product_data[$i-1])
                    return redirect()->back()->with('message', 'Product does not exist!');
                $unit[] = Unit::where('unit_code', $current_line[2])->first();
                if(!$unit[$i-1] && $current_line[2] == 'n/a')
                    $unit[$i-1] = 'n/a';
                elseif(!$unit[$i-1]){
                    return redirect()->back()->with('message', 'Sale unit does not exist!');
                }
                if(strtolower($current_line[5]) != "no tax"){
                    $tax[] = Tax::where('name', $current_line[5])->first();
                    if(!$tax[$i-1])
                        return redirect()->back()->with('message', 'Tax name does not exist!');
                }
                else
                    $tax[$i-1]['rate'] = 0;

                $qty[] = $current_line[1];
                $price[] = $current_line[3];
                $discount[] = $current_line[4];
            }
            $i++;
        }
        //return $unit;
        $data = $request->except('document');
        $data['reference_no'] = 'sr-' . date("Ymd") . '-'. date("his");
        $data['user_id'] = Auth::user()->id;
        $document = $request->document;
        if ($document) {
            $v = Validator::make(
                [
                    'extension' => strtolower($request->document->getClientOriginalExtension()),
                ],
                [
                    'extension' => 'in:jpg,jpeg,png,gif,pdf,csv,docx,xlsx,txt',
                ]
            );
            if ($v->fails())
                return redirect()->back()->withErrors($v->errors());

            $ext = pathinfo($document->getClientOriginalName(), PATHINFO_EXTENSION);
            $documentName = date("Ymdhis");
            if(!config('database.connections.saleprosaas_landlord')) {
                $documentName = $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            else {
                $documentName = $this->getTenantId() . '_' . $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            $data['document'] = $documentName;
        }
        $item = 0;
        $grand_total = $data['shipping_cost'];
        Sale::create($data);
        $lims_sale_data = Sale::latest()->first();
        $lims_customer_data = Customer::find($lims_sale_data->customer_id);

        foreach ($product_data as $key => $product) {
            if($product['tax_method'] == 1){
                $net_unit_price = $price[$key] - $discount[$key];
                $product_tax = $net_unit_price * ($tax[$key]['rate'] / 100) * $qty[$key];
                $total = ($net_unit_price * $qty[$key]) + $product_tax;
            }
            elseif($product['tax_method'] == 2){
                $net_unit_price = (100 / (100 + $tax[$key]['rate'])) * ($price[$key] - $discount[$key]);
                $product_tax = ($price[$key] - $discount[$key] - $net_unit_price) * $qty[$key];
                $total = ($price[$key] - $discount[$key]) * $qty[$key];
            }
            if($data['sale_status'] == 1 && $unit[$key]!='n/a'){
                $sale_unit_id = $unit[$key]['id'];
                if($unit[$key]['operator'] == '*')
                    $quantity = $qty[$key] * $unit[$key]['operation_value'];
                elseif($unit[$key]['operator'] == '/')
                    $quantity = $qty[$key] / $unit[$key]['operation_value'];
                $product['qty'] -= $quantity;
                $product_warehouse = Product_Warehouse::where([
                    ['product_id', $product['id']],
                    ['warehouse_id', $data['warehouse_id']]
                ])->first();
                $product_warehouse->qty -= $quantity;
                $product->save();
                $product_warehouse->save();
            }
            else
                $sale_unit_id = 0;
            //collecting mail data
            $mail_data['products'][$key] = $product['name'];
            if($product['type'] == 'digital')
                $mail_data['file'][$key] = url('/public/product/files').'/'.$product['file'];
            else
                $mail_data['file'][$key] = '';
            if($sale_unit_id)
                $mail_data['unit'][$key] = $unit[$key]['unit_code'];
            else
                $mail_data['unit'][$key] = '';

            $product_sale = new Product_Sale();
            $product_sale->sale_id = $lims_sale_data->id;
            $product_sale->product_id = $product['id'];
            $product_sale->qty = $mail_data['qty'][$key] = $qty[$key];
            $product_sale->sale_unit_id = $sale_unit_id;
            $product_sale->net_unit_price = number_format((float)$net_unit_price, config('decimal'), '.', '');
            $product_sale->discount = $discount[$key] * $qty[$key];
            $product_sale->tax_rate = $tax[$key]['rate'];
            $product_sale->tax = number_format((float)$product_tax, config('decimal'), '.', '');
            $product_sale->total = $mail_data['total'][$key] = number_format((float)$total, config('decimal'), '.', '');
            $product_sale->save();
            $lims_sale_data->total_qty += $qty[$key];
            $lims_sale_data->total_discount += $discount[$key] * $qty[$key];
            $lims_sale_data->total_tax += number_format((float)$product_tax, config('decimal'), '.', '');
            $lims_sale_data->total_price += number_format((float)$total, config('decimal'), '.', '');
        }
        $lims_sale_data->item = $key + 1;
        $lims_sale_data->order_tax = ($lims_sale_data->total_price - $lims_sale_data->order_discount) * ($data['order_tax_rate'] / 100);
        $lims_sale_data->grand_total = ($lims_sale_data->total_price + $lims_sale_data->order_tax + $lims_sale_data->shipping_cost) - $lims_sale_data->order_discount;
        $lims_sale_data->save();
        $message = 'Sale imported successfully';
        $mail_setting = MailSetting::latest()->first();
        if($lims_customer_data->email && $mail_setting) {
            //collecting male data
            $mail_data['email'] = $lims_customer_data->email;
            $mail_data['reference_no'] = $lims_sale_data->reference_no;
            $mail_data['sale_status'] = $lims_sale_data->sale_status;
            $mail_data['payment_status'] = $lims_sale_data->payment_status;
            $mail_data['total_qty'] = $lims_sale_data->total_qty;
            $mail_data['total_price'] = $lims_sale_data->total_price;
            $mail_data['order_tax'] = $lims_sale_data->order_tax;
            $mail_data['order_tax_rate'] = $lims_sale_data->order_tax_rate;
            $mail_data['order_discount'] = $lims_sale_data->order_discount;
            $mail_data['shipping_cost'] = $lims_sale_data->shipping_cost;
            $mail_data['grand_total'] = $lims_sale_data->grand_total;
            $mail_data['paid_amount'] = $lims_sale_data->paid_amount;
            $this->setMailInfo($mail_setting);
            try {
                Mail::to($mail_data['email'])->send(new SaleDetails($mail_data));
            }

            catch(\Exception $e){
                $message = 'Sale imported successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
            }
        }
        return redirect('sales')->with('message', $message);
    }

    public function edit($id)
    {
        if(Auth::user()->hasPermissionTo('sales-edit')){
            $lims_customer_list = Customer::where('is_active', true)->get();
            $lims_warehouse_list = Warehouse::where('is_active', true)->get();
            $lims_biller_list = Biller::where('is_active', true)->get();
            $lims_tax_list = Tax::where('is_active', true)->get();
            $lims_sale_data = Sale::find($id);
            $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
            if($lims_sale_data->exchange_rate)
                $currency_exchange_rate = $lims_sale_data->exchange_rate;
            else
                $currency_exchange_rate = 1;
            $custom_fields = CustomField::where('belongs_to', 'sale')->get();
            return view('backend.sale.edit',compact('lims_customer_list', 'lims_warehouse_list', 'lims_biller_list', 'lims_tax_list', 'lims_sale_data','lims_product_sale_data', 'currency_exchange_rate', 'custom_fields'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function update(Request $request, $id)
    {
        $data = $request->except('document');
        //return dd($data);
        $document = $request->document;
        $lims_sale_data = Sale::find($id);

        if ($document) {
            $v = Validator::make(
                [
                    'extension' => strtolower($request->document->getClientOriginalExtension()),
                ],
                [
                    'extension' => 'in:jpg,jpeg,png,gif,pdf,csv,docx,xlsx,txt',
                ]
            );
            if ($v->fails())
                return redirect()->back()->withErrors($v->errors());

            $this->fileDelete('documents/sale/', $lims_sale_data->document);

            $ext = pathinfo($document->getClientOriginalName(), PATHINFO_EXTENSION);
            $documentName = date("Ymdhis");
            if(!config('database.connections.saleprosaas_landlord')) {
                $documentName = $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            else {
                $documentName = $this->getTenantId() . '_' . $documentName . '.' . $ext;
                $document->move('public/documents/sale', $documentName);
            }
            $data['document'] = $documentName;
        }
        $balance = $data['grand_total'] - $data['paid_amount'];
        if($balance < 0 || $balance > 0)
            $data['payment_status'] = 2;
        else
            $data['payment_status'] = 4;

        $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
        $data['created_at'] = date("Y-m-d", strtotime(str_replace("/", "-", $data['created_at'])));
        $product_id = $data['product_id'];
        $imei_number = $data['imei_number'];
        $product_batch_id = $data['product_batch_id'];
        $product_code = $data['product_code'];
        $product_variant_id = $data['product_variant_id'];
        $qty = $data['qty'];
        $sale_unit = $data['sale_unit'];
        $net_unit_price = $data['net_unit_price'];
        $discount = $data['discount'];
        $tax_rate = $data['tax_rate'];
        $tax = $data['tax'];
        $total = $data['subtotal'];
        $old_product_id = [];
        $product_sale = [];
        foreach ($lims_product_sale_data as  $key => $product_sale_data) {
            $old_product_id[] = $product_sale_data->product_id;
            $old_product_variant_id[] = null;
            $lims_product_data = Product::find($product_sale_data->product_id);

            if( ($lims_sale_data->sale_status == 1) && ($lims_product_data->type == 'combo') ) {
                $product_list = explode(",", $lims_product_data->product_list);
                $variant_list = explode(",", $lims_product_data->variant_list);
                if($lims_product_data->variant_list)
                    $variant_list = explode(",", $lims_product_data->variant_list);
                else
                    $variant_list = [];
                $qty_list = explode(",", $lims_product_data->qty_list);

                foreach ($product_list as $index=>$child_id) {
                    $child_data = Product::find($child_id);
                    if(count($variant_list) && $variant_list[$index]) {
                        $child_product_variant_data = ProductVariant::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index]]
                        ])->first();

                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index]],
                            ['warehouse_id', $lims_sale_data->warehouse_id ],
                        ])->first();

                        $child_product_variant_data->qty += $product_sale_data->qty * $qty_list[$index];
                        $child_product_variant_data->save();
                    }
                    else {
                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['warehouse_id', $lims_sale_data->warehouse_id ],
                        ])->first();
                    }

                    $child_data->qty += $product_sale_data->qty * $qty_list[$index];
                    $child_warehouse_data->qty += $product_sale_data->qty * $qty_list[$index];

                    $child_data->save();
                    $child_warehouse_data->save();
                }
            }
            elseif( ($lims_sale_data->sale_status == 1) && ($product_sale_data->sale_unit_id != 0)) {
                $old_product_qty = $product_sale_data->qty;
                $lims_sale_unit_data = Unit::find($product_sale_data->sale_unit_id);
                if ($lims_sale_unit_data->operator == '*')
                    $old_product_qty = $old_product_qty * $lims_sale_unit_data->operation_value;
                else
                    $old_product_qty = $old_product_qty / $lims_sale_unit_data->operation_value;
                if($product_sale_data->variant_id) {
                    $lims_product_variant_data = ProductVariant::select('id', 'qty')->FindExactProduct($product_sale_data->product_id, $product_sale_data->variant_id)->first();
                    $lims_product_warehouse_data = Product_Warehouse::FindProductWithVariant($product_sale_data->product_id, $product_sale_data->variant_id, $lims_sale_data->warehouse_id)
                    ->first();
                    $old_product_variant_id[$key] = $lims_product_variant_data->id;
                    $lims_product_variant_data->qty += $old_product_qty;
                    $lims_product_variant_data->save();
                }
                elseif($product_sale_data->product_batch_id) {
                    $lims_product_warehouse_data = Product_Warehouse::where([
                        ['product_id', $product_sale_data->product_id],
                        ['product_batch_id', $product_sale_data->product_batch_id],
                        ['warehouse_id', $lims_sale_data->warehouse_id]
                    ])->first();

                    $product_batch_data = ProductBatch::find($product_sale_data->product_batch_id);
                    $product_batch_data->qty += $old_product_qty;
                    $product_batch_data->save();
                }
                else
                    $lims_product_warehouse_data = Product_Warehouse::FindProductWithoutVariant($product_sale_data->product_id, $lims_sale_data->warehouse_id)
                    ->first();
                $lims_product_data->qty += $old_product_qty;
                $lims_product_warehouse_data->qty += $old_product_qty;
                $lims_product_data->save();
                $lims_product_warehouse_data->save();
            }

            if($product_sale_data->imei_number) {
                if($lims_product_warehouse_data->imei_number)
                    $lims_product_warehouse_data->imei_number .= ',' . $product_sale_data->imei_number;
                else
                    $lims_product_warehouse_data->imei_number = $product_sale_data->imei_number;
                $lims_product_warehouse_data->save();
            }

            if($product_sale_data->variant_id && !(in_array($old_product_variant_id[$key], $product_variant_id)) ){
                $product_sale_data->delete();
            }
            elseif( !(in_array($old_product_id[$key], $product_id)) )
                $product_sale_data->delete();
        }
        foreach ($product_id as $key => $pro_id) {
            $lims_product_data = Product::find($pro_id);
            $product_sale['variant_id'] = null;
            if($lims_product_data->type == 'combo' && $data['sale_status'] == 1) {
                $product_list = explode(",", $lims_product_data->product_list);
                $variant_list = explode(",", $lims_product_data->variant_list);
                if($lims_product_data->variant_list)
                    $variant_list = explode(",", $lims_product_data->variant_list);
                else
                    $variant_list = [];
                $qty_list = explode(",", $lims_product_data->qty_list);

                foreach ($product_list as $index => $child_id) {
                    $child_data = Product::find($child_id);
                    if(count($variant_list) && $variant_list[$index]) {
                        $child_product_variant_data = ProductVariant::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index] ],
                        ])->first();

                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index] ],
                            ['warehouse_id', $data['warehouse_id'] ],
                        ])->first();

                        $child_product_variant_data->qty -= $qty[$key] * $qty_list[$index];
                        $child_product_variant_data->save();
                    }
                    else {
                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['warehouse_id', $data['warehouse_id'] ],
                        ])->first();
                    }


                    $child_data->qty -= $qty[$key] * $qty_list[$index];
                    $child_warehouse_data->qty -= $qty[$key] * $qty_list[$index];

                    $child_data->save();
                    $child_warehouse_data->save();
                }
            }
            if($sale_unit[$key] != 'n/a') {
                $lims_sale_unit_data = Unit::where('unit_name', $sale_unit[$key])->first();
                $sale_unit_id = $lims_sale_unit_data->id;
                if($data['sale_status'] == 1) {
                    $new_product_qty = $qty[$key];
                    if ($lims_sale_unit_data->operator == '*') {
                        $new_product_qty = $new_product_qty * $lims_sale_unit_data->operation_value;
                    } else {
                        $new_product_qty = $new_product_qty / $lims_sale_unit_data->operation_value;
                    }
                    if($lims_product_data->is_variant) {
                        $lims_product_variant_data = ProductVariant::select('id', 'variant_id', 'qty')->FindExactProductWithCode($pro_id, $product_code[$key])->first();
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithVariant($pro_id, $lims_product_variant_data->variant_id, $data['warehouse_id'])
                        ->first();

                        $product_sale['variant_id'] = $lims_product_variant_data->variant_id;
                        $lims_product_variant_data->qty -= $new_product_qty;
                        $lims_product_variant_data->save();
                    }
                    elseif($product_batch_id[$key]) {
                        $lims_product_warehouse_data = Product_Warehouse::where([
                            ['product_id', $pro_id],
                            ['product_batch_id', $product_batch_id[$key] ],
                            ['warehouse_id', $data['warehouse_id'] ]
                        ])->first();

                        $product_batch_data = ProductBatch::find($product_batch_id[$key]);
                        $product_batch_data->qty -= $new_product_qty;
                        $product_batch_data->save();
                    }
                    else {
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithoutVariant($pro_id, $data['warehouse_id'])
                        ->first();
                    }
                    $lims_product_data->qty -= $new_product_qty;
                    $lims_product_warehouse_data->qty -= $new_product_qty;
                    $lims_product_data->save();
                    $lims_product_warehouse_data->save();
                }
            }
            else
                $sale_unit_id = 0;

            //deduct imei number if available
            if($imei_number[$key]) {
                $imei_numbers = explode(",", $imei_number[$key]);
                $all_imei_numbers = explode(",", $lims_product_warehouse_data->imei_number);
                foreach ($imei_numbers as $number) {
                    if (($j = array_search($number, $all_imei_numbers)) !== false) {
                        unset($all_imei_numbers[$j]);
                    }
                }
                $lims_product_warehouse_data->imei_number = implode(",", $all_imei_numbers);
                $lims_product_warehouse_data->save();
            }

            //collecting mail data
            if($product_sale['variant_id']) {
                $variant_data = Variant::select('name')->find($product_sale['variant_id']);
                $mail_data['products'][$key] = $lims_product_data->name . ' [' . $variant_data->name . ']';
            }
            else
                $mail_data['products'][$key] = $lims_product_data->name;

            if($lims_product_data->type == 'digital')
                $mail_data['file'][$key] = url('/public/product/files').'/'.$lims_product_data->file;
            else
                $mail_data['file'][$key] = '';
            if($sale_unit_id)
                $mail_data['unit'][$key] = $lims_sale_unit_data->unit_code;
            else
                $mail_data['unit'][$key] = '';

            $product_sale['sale_id'] = $id ;
            $product_sale['product_id'] = $pro_id;
            $product_sale['imei_number'] = $imei_number[$key];
            $product_sale['product_batch_id'] = $product_batch_id[$key];
            $product_sale['qty'] = $mail_data['qty'][$key] = $qty[$key];
            $product_sale['sale_unit_id'] = $sale_unit_id;
            $product_sale['net_unit_price'] = $net_unit_price[$key];
            $product_sale['discount'] = $discount[$key];
            $product_sale['tax_rate'] = $tax_rate[$key];
            $product_sale['tax'] = $tax[$key];
            $product_sale['total'] = $mail_data['total'][$key] = $total[$key];

            if($product_sale['variant_id'] && in_array($product_variant_id[$key], $old_product_variant_id)) {
                Product_Sale::where([
                    ['product_id', $pro_id],
                    ['variant_id', $product_sale['variant_id']],
                    ['sale_id', $id]
                ])->update($product_sale);
            }
            elseif( $product_sale['variant_id'] === null && (in_array($pro_id, $old_product_id)) ) {
                Product_Sale::where([
                    ['sale_id', $id],
                    ['product_id', $pro_id]
                ])->update($product_sale);
            }
            else
                Product_Sale::create($product_sale);
        }
        $lims_sale_data->update($data);
        //inserting data for custom fields
        $custom_field_data = [];
        $custom_fields = CustomField::where('belongs_to', 'sale')->select('name', 'type')->get();
        foreach ($custom_fields as $type => $custom_field) {
            $field_name = str_replace(' ', '_', strtolower($custom_field->name));
            if(isset($data[$field_name])) {
                if($custom_field->type == 'checkbox' || $custom_field->type == 'multi_select')
                    $custom_field_data[$field_name] = implode(",", $data[$field_name]);
                else
                    $custom_field_data[$field_name] = $data[$field_name];
            }
        }
        if(count($custom_field_data))
            DB::table('sales')->where('id', $lims_sale_data->id)->update($custom_field_data);
        $lims_customer_data = Customer::find($data['customer_id']);
        $message = 'Sale updated successfully';
        //collecting mail data
        $mail_setting = MailSetting::latest()->first();
        if($lims_customer_data->email && $mail_setting) {
            $mail_data['email'] = $lims_customer_data->email;
            $mail_data['reference_no'] = $lims_sale_data->reference_no;
            $mail_data['sale_status'] = $lims_sale_data->sale_status;
            $mail_data['payment_status'] = $lims_sale_data->payment_status;
            $mail_data['total_qty'] = $lims_sale_data->total_qty;
            $mail_data['total_price'] = $lims_sale_data->total_price;
            $mail_data['order_tax'] = $lims_sale_data->order_tax;
            $mail_data['order_tax_rate'] = $lims_sale_data->order_tax_rate;
            $mail_data['order_discount'] = $lims_sale_data->order_discount;
            $mail_data['shipping_cost'] = $lims_sale_data->shipping_cost;
            $mail_data['grand_total'] = $lims_sale_data->grand_total;
            $mail_data['paid_amount'] = $lims_sale_data->paid_amount;
            $this->setMailInfo($mail_setting);
            try{
                Mail::to($mail_data['email'])->send(new SaleDetails($mail_data));
            }
            catch(\Exception $e){
                $message = 'Sale updated successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
            }
        }

        return redirect('sales')->with('message', $message);
    }

    public function printLastReciept()
    {
        $sale = Sale::where('sale_status', 1)->latest()->first();
        return redirect()->route('sale.invoice', $sale->id);
    }

    public function genInvoice($id)
    {
        $lims_sale_data = Sale::find($id);
      
        $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
        
     
        // dd($lims_product_sale_data);
        if(cache()->has('biller_list'))
        {
            $lims_biller_data = cache()->get('biller_list')->find($lims_sale_data->biller_id);
        }
        else{
            $lims_biller_data = Biller::find($lims_sale_data->biller_id);
        }
        if(cache()->has('warehouse_list'))
        {
            $lims_warehouse_data = cache()->get('warehouse_list')->find($lims_sale_data->warehouse_id);
        }
        else{
            $lims_warehouse_data = Warehouse::find($lims_sale_data->warehouse_id);
        }

        if(cache()->has('customer_list'))
        {
            $lims_customer_data = cache()->get('customer_list')->find($lims_sale_data->customer_id);
        }
        else{
            $lims_customer_data = Customer::find($lims_sale_data->customer_id);
        }

        $lims_payment_data = Payment::where('sale_id', $id)->get();
        //dd($lims_payment_data);
        if(cache()->has('pos_setting'))
        {
            $lims_pos_setting_data = cache()->get('pos_setting');
        }
        else{
            $lims_pos_setting_data = PosSetting::select('invoice_option')->latest()->first();
        }

        $supportedIdentifiers = [
            'al', 'fr_BE', 'pt_BR', 'bg', 'cs', 'dk', 'nl', 'et', 'ka', 'de', 'fr', 'hu', 'id', 'it', 'lt', 'lv',
            'ms', 'fa', 'pl', 'ro', 'sk', 'es', 'ru', 'sv', 'tr', 'tk', 'ua', 'yo'
        ]; //ar, az, ku, mk - not supported

        $defaultLocale = \App::getLocale();
        $numberToWords = new NumberToWords();

        if(in_array($defaultLocale, $supportedIdentifiers))
            $numberTransformer = $numberToWords->getNumberTransformer($defaultLocale);
        else
            $numberTransformer = $numberToWords->getNumberTransformer('en');




        if(config('is_zatca')) {
            //generating base64 TLV format qrtext for qrcode
            $qrText = GenerateQrCode::fromArray([
                new Seller(config('company_name')), // seller name
                new TaxNumber(config('vat_registration_number')), // seller tax number
                new InvoiceDate($lims_sale_data->created_at->toDateString()."T".$lims_sale_data->created_at->toTimeString()), // invoice date as Zulu ISO8601 @see https://en.wikipedia.org/wiki/ISO_8601
                new InvoiceTotalAmount(number_format((float)$lims_sale_data->grand_total, 4, '.', '')), // invoice total amount
                new InvoiceTaxAmount(number_format((float)($lims_sale_data->total_tax+$lims_sale_data->order_tax), 4, '.', '')) // invoice tax amount
                // TODO :: Support others tags
            ])->toBase64();
        }
        else {
            $qrText = $lims_sale_data->reference_no;
        }
        if(is_null($lims_sale_data->exchange_rate))
        {
            $numberInWords = $numberTransformer->toWords($lims_sale_data->grand_total);
            $currency_code = cache()->get('currency')->code;
        } else {
            $numberInWords = $numberTransformer->toWords($lims_sale_data->grand_total);
            $sale_currency = DB::table('currencies')->select('code')->where('id',$lims_sale_data->currency_id)->first();
            $currency_code = $sale_currency->code;
        }
        $paying_methods = Payment::where('sale_id', $id)->pluck('paying_method')->toArray();
        $paid_by_info = '';
        foreach ($paying_methods as $key => $paying_method) {
            if($key)
                $paid_by_info .= ', '.$paying_method;
            else
                $paid_by_info = $paying_method;
        }
        $sale_custom_fields = CustomField::where([
                                ['belongs_to', 'sale'],
                                ['is_invoice', true]
                            ])->pluck('name');
        $customer_custom_fields = CustomField::where([
                                ['belongs_to', 'customer'],
                                ['is_invoice', true]
                            ])->pluck('name');
        $product_custom_fields = CustomField::where([
                                ['belongs_to', 'product'],
                                ['is_invoice', true]
                            ])->pluck('name');
        if($lims_pos_setting_data->invoice_option == 'A4') {
            return view('backend.sale.a4_invoice', compact('lims_sale_data', 'currency_code', 'lims_product_sale_data', 'lims_biller_data', 'lims_warehouse_data', 'lims_customer_data', 'lims_payment_data', 'numberInWords', 'paid_by_info', 'sale_custom_fields', 'customer_custom_fields', 'product_custom_fields', 'qrText'));
        }
        else{
            return view('backend.sale.invoice', compact('lims_sale_data', 'currency_code', 'lims_product_sale_data', 'lims_biller_data', 'lims_warehouse_data', 'lims_customer_data', 'lims_payment_data', 'numberInWords', 'sale_custom_fields', 'customer_custom_fields', 'product_custom_fields', 'qrText'));
        }
    }


    public function addPayment(Request $request)
    {
        $data = $request->all();
        if(!$data['amount'])
            $data['amount'] = 0.00;

        $lims_sale_data = Sale::find($data['sale_id']);
        $lims_customer_data = Customer::find($lims_sale_data->customer_id);

        // ===== MAIN PAYMENT ===== th
        $lims_sale_data->paid_amount += $data['amount'];
        $balance = $lims_sale_data->grand_total - $lims_sale_data->paid_amount;

        if($balance > 0 || $balance < 0)
            $lims_sale_data->payment_status = 2; // Partial
        elseif ($balance == 0)
            $lims_sale_data->payment_status = 4; // Paid

        $paying_method = $this->getPayingMethod($data['paid_by_id']);

        $cash_register_data = CashRegister::where([
            ['user_id', Auth::id()],
            ['warehouse_id', $lims_sale_data->warehouse_id],
            ['status', true]
        ])->first();

        $lims_payment_data = new Payment();
        $lims_payment_data->user_id = Auth::id();
        $lims_payment_data->sale_id = $lims_sale_data->id;
        if($cash_register_data)
            $lims_payment_data->cash_register_id = $cash_register_data->id;
        $lims_payment_data->account_id = $data['account_id'];
        $data['payment_reference'] = 'spr-' . date("Ymd") . '-'. date("his");
        $lims_payment_data->payment_reference = $data['payment_reference'];
        $lims_payment_data->amount = $data['amount'];
        $lims_payment_data->change = $data['paying_amount'] - $data['amount'];
        $lims_payment_data->paying_method = $paying_method;
        $lims_payment_data->payment_note = $data['payment_note'];

        // if mobile money data exists
        if(!empty($request->selected_mobile_op)) {
            $lims_payment_data->mobile_money_operator = $request->selected_mobile_op ?? '';
            $lims_payment_data->mobile_number = $request->mobile_number ?? '';
        }

        $lims_payment_data->save();
        $lims_sale_data->save();

        // ===== HANDLE SPLIT PAYMENTS =====
        if ($request->has('split_amount')) {
            foreach ($request->split_amount as $key => $split_amount) {
                if(!$split_amount || $split_amount <= 0) continue;

                $split_paid_by_id = $request->split_paid_by_id[$key] ?? null;
                $split_method = $this->getPayingMethod($split_paid_by_id);

                $split_payment = new Payment();
                $split_payment->user_id = Auth::id();
                $split_payment->sale_id = $lims_sale_data->id;
                if($cash_register_data)
                    $split_payment->cash_register_id = $cash_register_data->id;
                $split_payment->account_id = $data['account_id'];
                $split_payment->payment_reference = 'spr-' . date("Ymd") . '-' . date("his") . '-' . $key;
                $split_payment->amount = $split_amount;
                $split_payment->change = 0; // handled in main payment only
                $split_payment->paying_method = $split_method;
                $split_payment->payment_note = $data['payment_note'] ?? null;
                $split_payment->save();

                // update sale paid_amount + status
                $lims_sale_data->paid_amount += $split_amount;
                $balance = $lims_sale_data->grand_total - $lims_sale_data->paid_amount;
                if($balance > 0 || $balance < 0)
                    $lims_sale_data->payment_status = 2;
                elseif ($balance == 0)
                    $lims_sale_data->payment_status = 4;
                $lims_sale_data->save();
            }
        }

        // === Continue with GiftCard, CreditCard, Paypal, etc. like you already have ===

        return redirect('sales')->with('message', 'Payment created successfully');
    }

    /**
     * Helper to get payment method string
     */
    private function getPayingMethod($id)
    {
        switch($id) {
            case 1: return 'Cash';
            case 2: return 'Gift Card';
            case 3: return 'Credit Card';
            case 4: return 'Cheque';
            case 5: return 'Paypal';
            case 6: return 'Deposit';
            case 7: return 'Points';
            case 8: return 'MobileMoney';
            default: return 'Unknown';
        }
    }


    public function getPayment($id)
    {
        $lims_payment_list = Payment::where('sale_id', $id)->get();
        $date = [];
        $payment_reference = [];
        $paid_amount = [];
        $paying_method = [];
        $payment_id = [];
        $payment_note = [];
        $gift_card_id = [];
        $cheque_no = [];
        $change = [];
        $paying_amount = [];
        $account_name = [];
        $account_id = [];

        foreach ($lims_payment_list as $payment) {
            $date[] = date(config('date_format'), strtotime($payment->created_at->toDateString())) . ' '. $payment->created_at->toTimeString();
            $payment_reference[] = $payment->payment_reference;
            $paid_amount[] = $payment->amount;
            $change[] = $payment->change;
            $paying_method[] = $payment->paying_method;
            $paying_amount[] = $payment->amount + $payment->change;
            if($payment->paying_method == 'Gift Card'){
                $lims_payment_gift_card_data = PaymentWithGiftCard::where('payment_id',$payment->id)->first();
                $gift_card_id[] = $lims_payment_gift_card_data->gift_card_id;
            }
            elseif($payment->paying_method == 'Cheque'){
                $lims_payment_cheque_data = PaymentWithCheque::where('payment_id',$payment->id)->first();
                $cheque_no[] = $lims_payment_cheque_data->cheque_no;
            }
            else{
                $cheque_no[] = $gift_card_id[] = null;
            }
            $payment_id[] = $payment->id;
            $payment_note[] = $payment->payment_note;
            $lims_account_data = Account::find($payment->account_id);
            $account_name[] = $lims_account_data->name;
            $account_id[] = $lims_account_data->id;
        }
        $payments[] = $date;
        $payments[] = $payment_reference;
        $payments[] = $paid_amount;
        $payments[] = $paying_method;
        $payments[] = $payment_id;
        $payments[] = $payment_note;
        $payments[] = $cheque_no;
        $payments[] = $gift_card_id;
        $payments[] = $change;
        $payments[] = $paying_amount;
        $payments[] = $account_name;
        $payments[] = $account_id;

        return $payments;
    }

    public function updatePayment(Request $request)
    {
        $data = $request->all();
        //return $data;
        $lims_payment_data = Payment::find($data['payment_id']);
        $lims_sale_data = Sale::find($lims_payment_data->sale_id);
        $lims_customer_data = Customer::find($lims_sale_data->customer_id);
        //updating sale table
        $amount_dif = $lims_payment_data->amount - $data['edit_amount'];
        $lims_sale_data->paid_amount = $lims_sale_data->paid_amount - $amount_dif;
        $balance = $lims_sale_data->grand_total - $lims_sale_data->paid_amount;
        if($balance > 0 || $balance < 0)
            $lims_sale_data->payment_status = 2;
        elseif ($balance == 0)
            $lims_sale_data->payment_status = 4;
        $lims_sale_data->save();

        if($lims_payment_data->paying_method == 'Deposit') {
            $lims_customer_data->expense -= $lims_payment_data->amount;
            $lims_customer_data->save();
        }
        elseif($lims_payment_data->paying_method == 'Points') {
            $lims_customer_data->points += $lims_payment_data->used_points;
            $lims_customer_data->save();
            $lims_payment_data->used_points = 0;
        }
        if($data['edit_paid_by_id'] == 1)
            $lims_payment_data->paying_method = 'Cash';
        elseif ($data['edit_paid_by_id'] == 2){
            if($lims_payment_data->paying_method == 'Gift Card'){
                $lims_payment_gift_card_data = PaymentWithGiftCard::where('payment_id', $data['payment_id'])->first();

                $lims_gift_card_data = GiftCard::find($lims_payment_gift_card_data->gift_card_id);
                $lims_gift_card_data->expense -= $lims_payment_data->amount;
                $lims_gift_card_data->save();

                $lims_gift_card_data = GiftCard::find($data['gift_card_id']);
                $lims_gift_card_data->expense += $data['edit_amount'];
                $lims_gift_card_data->save();

                $lims_payment_gift_card_data->gift_card_id = $data['gift_card_id'];
                $lims_payment_gift_card_data->save();
            }
            else{
                $lims_payment_data->paying_method = 'Gift Card';
                $lims_gift_card_data = GiftCard::find($data['gift_card_id']);
                $lims_gift_card_data->expense += $data['edit_amount'];
                $lims_gift_card_data->save();
                PaymentWithGiftCard::create($data);
            }
        }
        elseif ($data['edit_paid_by_id'] == 3){
            $lims_pos_setting_data = PosSetting::latest()->first();
            Stripe::setApiKey($lims_pos_setting_data->stripe_secret_key);
            if($lims_payment_data->paying_method == 'Credit Card'){
                $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('payment_id', $lims_payment_data->id)->first();

                \Stripe\Refund::create(array(
                  "charge" => $lims_payment_with_credit_card_data->charge_id,
                ));

                $customer_id =
                $lims_payment_with_credit_card_data->customer_stripe_id;

                $charge = \Stripe\Charge::create([
                    'amount' => $data['edit_amount'] * 100,
                    'currency' => 'usd',
                    'customer' => $customer_id
                ]);
                $lims_payment_with_credit_card_data->charge_id = $charge->id;
                $lims_payment_with_credit_card_data->save();
            }
            else{
                $token = $data['stripeToken'];
                $amount = $data['edit_amount'];
                $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('customer_id', $lims_sale_data->customer_id)->first();

                if(!$lims_payment_with_credit_card_data) {
                    $customer = \Stripe\Customer::create([
                        'source' => $token
                    ]);

                    $charge = \Stripe\Charge::create([
                        'amount' => $amount * 100,
                        'currency' => 'usd',
                        'customer' => $customer->id,
                    ]);
                    $data['customer_stripe_id'] = $customer->id;
                }
                else {
                    $customer_id =
                    $lims_payment_with_credit_card_data->customer_stripe_id;

                    $charge = \Stripe\Charge::create([
                        'amount' => $amount * 100,
                        'currency' => 'usd',
                        'customer' => $customer_id
                    ]);
                    $data['customer_stripe_id'] = $customer_id;
                }
                $data['customer_id'] = $lims_sale_data->customer_id;
                $data['charge_id'] = $charge->id;
                PaymentWithCreditCard::create($data);
            }
            $lims_payment_data->paying_method = 'Credit Card';
        }
        elseif($data['edit_paid_by_id'] == 4){
            if($lims_payment_data->paying_method == 'Cheque'){
                $lims_payment_cheque_data = PaymentWithCheque::where('payment_id', $data['payment_id'])->first();
                $lims_payment_cheque_data->cheque_no = $data['edit_cheque_no'];
                $lims_payment_cheque_data->save();
            }
            else{
                $lims_payment_data->paying_method = 'Cheque';
                $data['cheque_no'] = $data['edit_cheque_no'];
                PaymentWithCheque::create($data);
            }
        }
        elseif($data['edit_paid_by_id'] == 5){
            //updating payment data
            $lims_payment_data->amount = $data['edit_amount'];
            $lims_payment_data->paying_method = 'Paypal';
            $lims_payment_data->payment_note = $data['edit_payment_note'];
            $lims_payment_data->save();

            $provider = new ExpressCheckout;
            $paypal_data['items'] = [];
            $paypal_data['items'][] = [
                'name' => 'Paid Amount',
                'price' => $data['edit_amount'],
                'qty' => 1
            ];
            $paypal_data['invoice_id'] = $lims_payment_data->payment_reference;
            $paypal_data['invoice_description'] = "Reference: {$paypal_data['invoice_id']}";
            $paypal_data['return_url'] = url('/sale/paypalPaymentSuccess/'.$lims_payment_data->id);
            $paypal_data['cancel_url'] = url('/sale');

            $total = 0;
            foreach($paypal_data['items'] as $item) {
                $total += $item['price']*$item['qty'];
            }

            $paypal_data['total'] = $total;
            $response = $provider->setExpressCheckout($paypal_data);
            return redirect($response['paypal_link']);
        }
        elseif($data['edit_paid_by_id'] == 6){
            $lims_payment_data->paying_method = 'Deposit';
            $lims_customer_data->expense += $data['edit_amount'];
            $lims_customer_data->save();
        }
        elseif($data['edit_paid_by_id'] == 7) {
            $lims_payment_data->paying_method = 'Points';
            $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
            $used_points = ceil($data['edit_amount'] / $lims_reward_point_setting_data->per_point_amount);
            $lims_payment_data->used_points = $used_points;
            $lims_customer_data->points -= $used_points;
            $lims_customer_data->save();
        }
        //updating payment data
        $lims_payment_data->account_id = $data['account_id'];
        $lims_payment_data->amount = $data['edit_amount'];
        $lims_payment_data->change = $data['edit_paying_amount'] - $data['edit_amount'];
        $lims_payment_data->payment_note = $data['edit_payment_note'];
        $lims_payment_data->save();
        $message = 'Payment updated successfully';


        //collecting male data
        $mail_setting = MailSetting::latest()->first();
        if($lims_customer_data->email && $mail_setting) {
            $mail_data['email'] = $lims_customer_data->email;
            $mail_data['sale_reference'] = $lims_sale_data->reference_no;
            $mail_data['payment_reference'] = $lims_payment_data->payment_reference;
            $mail_data['payment_method'] = $lims_payment_data->paying_method;
            $mail_data['grand_total'] = $lims_sale_data->grand_total;
            $mail_data['paid_amount'] = $lims_payment_data->amount;
            $mail_data['currency'] = config('currency');
            $mail_data['due'] = $balance;
            $this->setMailInfo($mail_setting);
            try{
                Mail::to($mail_data['email'])->send(new PaymentDetails($mail_data));
            }
            catch(\Exception $e){
                $message = 'Payment updated successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
            }
        }
        return redirect('sales')->with('message', $message);
    }

    public function deletePayment(Request $request)
    {
        $lims_payment_data = Payment::find($request['id']);
        $lims_sale_data = Sale::where('id', $lims_payment_data->sale_id)->first();
        $lims_sale_data->paid_amount -= $lims_payment_data->amount;
        $balance = $lims_sale_data->grand_total - $lims_sale_data->paid_amount;
        if($balance > 0 || $balance < 0)
            $lims_sale_data->payment_status = 2;
        elseif ($balance == 0)
            $lims_sale_data->payment_status = 4;
        $lims_sale_data->save();

        if ($lims_payment_data->paying_method == 'Gift Card') {
            $lims_payment_gift_card_data = PaymentWithGiftCard::where('payment_id', $request['id'])->first();
            $lims_gift_card_data = GiftCard::find($lims_payment_gift_card_data->gift_card_id);
            $lims_gift_card_data->expense -= $lims_payment_data->amount;
            $lims_gift_card_data->save();
            $lims_payment_gift_card_data->delete();
        }
        elseif($lims_payment_data->paying_method == 'Credit Card'){
            $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('payment_id', $request['id'])->first();
            $lims_pos_setting_data = PosSetting::latest()->first();
            Stripe::setApiKey($lims_pos_setting_data->stripe_secret_key);
            \Stripe\Refund::create(array(
              "charge" => $lims_payment_with_credit_card_data->charge_id,
            ));

            $lims_payment_with_credit_card_data->delete();
        }
        elseif ($lims_payment_data->paying_method == 'Cheque') {
            $lims_payment_cheque_data = PaymentWithCheque::where('payment_id', $request['id'])->first();
            $lims_payment_cheque_data->delete();
        }
        elseif ($lims_payment_data->paying_method == 'Paypal') {
            $lims_payment_paypal_data = PaymentWithPaypal::where('payment_id', $request['id'])->first();
            if($lims_payment_paypal_data){
                $provider = new ExpressCheckout;
                $response = $provider->refundTransaction($lims_payment_paypal_data->transaction_id);
                $lims_payment_paypal_data->delete();
            }
        }
        elseif ($lims_payment_data->paying_method == 'Deposit'){
            $lims_customer_data = Customer::find($lims_sale_data->customer_id);
            $lims_customer_data->expense -= $lims_payment_data->amount;
            $lims_customer_data->save();
        }
        elseif ($lims_payment_data->paying_method == 'Points'){
            $lims_customer_data = Customer::find($lims_sale_data->customer_id);
            $lims_customer_data->points += $lims_payment_data->used_points;
            $lims_customer_data->save();
        }
        $lims_payment_data->delete();
        return redirect('sales')->with('not_permitted', 'Payment deleted successfully');
    }

    public function todaySale()
    {
        $data['total_sale_amount'] = Sale::whereDate('created_at', date("Y-m-d"))->sum('grand_total');
        $data['total_payment'] = Payment::whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['cash_payment'] = Payment::where([
                                    ['paying_method', 'Cash']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['credit_card_payment'] = Payment::where([
                                    ['paying_method', 'Credit Card']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['gift_card_payment'] = Payment::where([
                                    ['paying_method', 'Gift Card']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['deposit_payment'] = Payment::where([
                                    ['paying_method', 'Deposit']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['cheque_payment'] = Payment::where([
                                    ['paying_method', 'Cheque']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['paypal_payment'] = Payment::where([
                                    ['paying_method', 'Paypal']
                                ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        // changes by yogesh
        $data['mobile_payment'] = Payment::where([
            ['paying_method', 'MobileMoney']
        ])->whereDate('created_at', date("Y-m-d"))->sum('amount');
        //changes end by yogesh
        $data['total_sale_return'] = Returns::whereDate('created_at', date("Y-m-d"))->sum('grand_total');
        $data['total_expense'] = Expense::whereDate('created_at', date("Y-m-d"))->sum('amount');
        $data['total_cash'] = $data['total_payment'] - ($data['total_sale_return'] + $data['total_expense']);
        return $data;
    }

    public function todayProfit($warehouse_id)
    {
        if($warehouse_id == 0)
            $product_sale_data = Product_Sale::select(DB::raw('product_id, product_batch_id, sum(qty) as sold_qty, sum(total) as sold_amount'))->whereDate('created_at', date("Y-m-d"))->groupBy('product_id', 'product_batch_id')->get();
        else
            $product_sale_data = Sale::join('product_sales', 'sales.id', '=', 'product_sales.sale_id')
            ->select(DB::raw('product_sales.product_id, product_sales.product_batch_id, sum(product_sales.qty) as sold_qty, sum(product_sales.total) as sold_amount'))
            ->where('sales.warehouse_id', $warehouse_id)->whereDate('sales.created_at', date("Y-m-d"))
            ->groupBy('product_sales.product_id', 'product_sales.product_batch_id')->get();

        $product_revenue = 0;
        $product_cost = 0;
        $profit = 0;
        foreach ($product_sale_data as $key => $product_sale) {
            if($warehouse_id == 0) {
                if($product_sale->product_batch_id)
                    $product_purchase_data = ProductPurchase::where([
                        ['product_id', $product_sale->product_id],
                        ['product_batch_id', $product_sale->product_batch_id]
                    ])->get();
                else
                    $product_purchase_data = ProductPurchase::where('product_id', $product_sale->product_id)->get();
            }
            else {
                if($product_sale->product_batch_id) {
                    $product_purchase_data = Purchase::join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')
                    ->where([
                        ['product_purchases.product_id', $product_sale->product_id],
                        ['product_purchases.product_batch_id', $product_sale->product_batch_id],
                        ['purchases.warehouse_id', $warehouse_id]
                    ])->select('product_purchases.*')->get();
                }
                else
                    $product_purchase_data = Purchase::join('product_purchases', 'purchases.id', '=', 'product_purchases.purchase_id')
                    ->where([
                        ['product_purchases.product_id', $product_sale->product_id],
                        ['purchases.warehouse_id', $warehouse_id]
                    ])->select('product_purchases.*')->get();
            }

            $purchased_qty = 0;
            $purchased_amount = 0;
            $sold_qty = $product_sale->sold_qty;
            $product_revenue += $product_sale->sold_amount;
            foreach ($product_purchase_data as $key => $product_purchase) {
                $purchased_qty += $product_purchase->qty;
                $purchased_amount += $product_purchase->total;
                if($purchased_qty >= $sold_qty) {
                    $qty_diff = $purchased_qty - $sold_qty;
                    $unit_cost = $product_purchase->total / $product_purchase->qty;
                    $purchased_amount -= ($qty_diff * $unit_cost);
                    break;
                }
            }

            $product_cost += $purchased_amount;
            $profit += $product_sale->sold_amount - $purchased_amount;
        }

        $data['product_revenue'] = $product_revenue;
        $data['product_cost'] = $product_cost;
        if($warehouse_id == 0)
            $data['expense_amount'] = Expense::whereDate('created_at', date("Y-m-d"))->sum('amount');
        else
            $data['expense_amount'] = Expense::where('warehouse_id', $warehouse_id)->whereDate('created_at', date("Y-m-d"))->sum('amount');

        $data['profit'] = $profit - $data['expense_amount'];
        return $data;
    }

    public function deleteBySelection(Request $request)
    {
        $sale_id = $request['saleIdArray'];
        foreach ($sale_id as $id) {
            $lims_sale_data = Sale::find($id);
            $return_ids = Returns::where('sale_id', $id)->pluck('id')->toArray();
            if(count($return_ids)) {
                ProductReturn::whereIn('return_id', $return_ids)->delete();
                Returns::whereIn('id', $return_ids)->delete();
            }
            $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
            $lims_delivery_data = Delivery::where('sale_id',$id)->first();
            if($lims_sale_data->sale_status == 3)
                $message = 'Draft deleted successfully';
            else
                $message = 'Sale deleted successfully';
            foreach ($lims_product_sale_data as $product_sale) {
                $lims_product_data = Product::find($product_sale->product_id);
                //adjust product quantity
                if( ($lims_sale_data->sale_status == 1) && ($lims_product_data->type == 'combo') ){
                    $product_list = explode(",", $lims_product_data->product_list);
                    if($lims_product_data->variant_list)
                        $variant_list = explode(",", $lims_product_data->variant_list);
                    else
                        $variant_list = [];
                    $qty_list = explode(",", $lims_product_data->qty_list);

                    foreach ($product_list as $index=>$child_id) {
                        $child_data = Product::find($child_id);
                        if(count($variant_list) && $variant_list[$index]) {
                            $child_product_variant_data = ProductVariant::where([
                                ['product_id', $child_id],
                                ['variant_id', $variant_list[$index] ]
                            ])->first();

                            $child_warehouse_data = Product_Warehouse::where([
                                ['product_id', $child_id],
                                ['variant_id', $variant_list[$index] ],
                                ['warehouse_id', $lims_sale_data->warehouse_id ],
                            ])->first();

                             $child_product_variant_data->qty += $product_sale->qty * $qty_list[$index];
                             $child_product_variant_data->save();
                        }
                        else {
                            $child_warehouse_data = Product_Warehouse::where([
                                ['product_id', $child_id],
                                ['warehouse_id', $lims_sale_data->warehouse_id ],
                            ])->first();
                        }

                        $child_data->qty += $product_sale->qty * $qty_list[$index];
                        $child_warehouse_data->qty += $product_sale->qty * $qty_list[$index];

                        $child_data->save();
                        $child_warehouse_data->save();
                    }
                }
                elseif(($lims_sale_data->sale_status == 1) && ($product_sale->sale_unit_id != 0)){
                    $lims_sale_unit_data = Unit::find($product_sale->sale_unit_id);
                    if ($lims_sale_unit_data->operator == '*')
                        $product_sale->qty = $product_sale->qty * $lims_sale_unit_data->operation_value;
                    else
                        $product_sale->qty = $product_sale->qty / $lims_sale_unit_data->operation_value;
                    if($product_sale->variant_id) {
                        $lims_product_variant_data = ProductVariant::select('id', 'qty')->FindExactProduct($lims_product_data->id, $product_sale->variant_id)->first();
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithVariant($lims_product_data->id, $product_sale->variant_id, $lims_sale_data->warehouse_id)->first();
                        $lims_product_variant_data->qty += $product_sale->qty;
                        $lims_product_variant_data->save();
                    }
                    elseif($product_sale->product_batch_id) {
                        $lims_product_batch_data = ProductBatch::find($product_sale->product_batch_id);
                        $lims_product_warehouse_data = Product_Warehouse::where([
                            ['product_batch_id', $product_sale->product_batch_id],
                            ['warehouse_id', $lims_sale_data->warehouse_id]
                        ])->first();

                        $lims_product_batch_data->qty -= $product_sale->qty;
                        $lims_product_batch_data->save();
                    }
                    else {
                        $lims_product_warehouse_data = Product_Warehouse::FindProductWithoutVariant($lims_product_data->id, $lims_sale_data->warehouse_id)->first();
                    }

                    $lims_product_data->qty += $product_sale->qty;
                    $lims_product_warehouse_data->qty += $product_sale->qty;
                    $lims_product_data->save();
                    $lims_product_warehouse_data->save();
                }
                $product_sale->delete();
            }
            $lims_payment_data = Payment::where('sale_id', $id)->get();
            foreach ($lims_payment_data as $payment) {
                if($payment->paying_method == 'Gift Card'){
                    $lims_payment_with_gift_card_data = PaymentWithGiftCard::where('payment_id', $payment->id)->first();
                    $lims_gift_card_data = GiftCard::find($lims_payment_with_gift_card_data->gift_card_id);
                    $lims_gift_card_data->expense -= $payment->amount;
                    $lims_gift_card_data->save();
                    $lims_payment_with_gift_card_data->delete();
                }
                elseif($payment->paying_method == 'Cheque'){
                    $lims_payment_cheque_data = PaymentWithCheque::where('payment_id', $payment->id)->first();
                    $lims_payment_cheque_data->delete();
                }
                elseif($payment->paying_method == 'Credit Card'){
                    $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('payment_id', $payment->id)->first();
                    $lims_payment_with_credit_card_data->delete();
                }
                elseif($payment->paying_method == 'Paypal'){
                    $lims_payment_paypal_data = PaymentWithPaypal::where('payment_id', $payment->id)->first();
                    if($lims_payment_paypal_data)
                        $lims_payment_paypal_data->delete();
                }
                elseif($payment->paying_method == 'Deposit'){
                    $lims_customer_data = Customer::find($lims_sale_data->customer_id);
                    $lims_customer_data->expense -= $payment->amount;
                    $lims_customer_data->save();
                }
                $payment->delete();
            }
            if($lims_delivery_data)
                $lims_delivery_data->delete();
            if($lims_sale_data->coupon_id) {
                $lims_coupon_data = Coupon::find($lims_sale_data->coupon_id);
                $lims_coupon_data->used -= 1;
                $lims_coupon_data->save();
            }
            $lims_sale_data->delete();
            $this->fileDelete('documents/sale/', $lims_sale_data->document);

        }
        return 'Sale deleted successfully!';
    }

    public function destroy($id)
    {
        $url = url()->previous();
        $lims_sale_data = Sale::find($id);
        $return_ids = Returns::where('sale_id', $id)->pluck('id')->toArray();
        if(count($return_ids)) {
            ProductReturn::whereIn('return_id', $return_ids)->delete();
            Returns::whereIn('id', $return_ids)->delete();
        }
        $lims_product_sale_data = Product_Sale::where('sale_id', $id)->get();
        $lims_delivery_data = Delivery::where('sale_id',$id)->first();
        if($lims_sale_data->sale_status == 3)
            $message = 'Draft deleted successfully';
        else
            $message = 'Sale deleted successfully';

        foreach ($lims_product_sale_data as $product_sale) {
            $lims_product_data = Product::find($product_sale->product_id);
            //adjust product quantity
            if( ($lims_sale_data->sale_status == 1) && ($lims_product_data->type == 'combo') ) {
                $product_list = explode(",", $lims_product_data->product_list);
                $variant_list = explode(",", $lims_product_data->variant_list);
                $qty_list = explode(",", $lims_product_data->qty_list);
                if($lims_product_data->variant_list)
                    $variant_list = explode(",", $lims_product_data->variant_list);
                else
                    $variant_list = [];
                foreach ($product_list as $index=>$child_id) {
                    $child_data = Product::find($child_id);
                    if(count($variant_list) && $variant_list[$index]) {
                        $child_product_variant_data = ProductVariant::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index] ]
                        ])->first();

                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['variant_id', $variant_list[$index] ],
                            ['warehouse_id', $lims_sale_data->warehouse_id ],
                        ])->first();

                         $child_product_variant_data->qty += $product_sale->qty * $qty_list[$index];
                         $child_product_variant_data->save();
                    }
                    else {
                        $child_warehouse_data = Product_Warehouse::where([
                            ['product_id', $child_id],
                            ['warehouse_id', $lims_sale_data->warehouse_id ],
                        ])->first();
                    }

                    $child_data->qty += $product_sale->qty * $qty_list[$index];
                    $child_warehouse_data->qty += $product_sale->qty * $qty_list[$index];

                    $child_data->save();
                    $child_warehouse_data->save();
                }
            }
            elseif(($lims_sale_data->sale_status == 1) && ($product_sale->sale_unit_id != 0)) {
                $lims_sale_unit_data = Unit::find($product_sale->sale_unit_id);
                if ($lims_sale_unit_data->operator == '*')
                    $product_sale->qty = $product_sale->qty * $lims_sale_unit_data->operation_value;
                else
                    $product_sale->qty = $product_sale->qty / $lims_sale_unit_data->operation_value;
                if($product_sale->variant_id) {
                    $lims_product_variant_data = ProductVariant::select('id', 'qty')->FindExactProduct($lims_product_data->id, $product_sale->variant_id)->first();
                    $lims_product_warehouse_data = Product_Warehouse::FindProductWithVariant($lims_product_data->id, $product_sale->variant_id, $lims_sale_data->warehouse_id)->first();
                    $lims_product_variant_data->qty += $product_sale->qty;
                    $lims_product_variant_data->save();
                }
                elseif($product_sale->product_batch_id) {
                    $lims_product_batch_data = ProductBatch::find($product_sale->product_batch_id);
                    $lims_product_warehouse_data = Product_Warehouse::where([
                        ['product_batch_id', $product_sale->product_batch_id],
                        ['warehouse_id', $lims_sale_data->warehouse_id]
                    ])->first();

                    $lims_product_batch_data->qty -= $product_sale->qty;
                    $lims_product_batch_data->save();
                }
                else {
                    $lims_product_warehouse_data = Product_Warehouse::FindProductWithoutVariant($lims_product_data->id, $lims_sale_data->warehouse_id)->first();
                }

                $lims_product_data->qty += $product_sale->qty;
                $lims_product_warehouse_data->qty += $product_sale->qty;
                $lims_product_data->save();
                $lims_product_warehouse_data->save();
            }
            if($product_sale->imei_number) {
                if($lims_product_warehouse_data->imei_number)
                    $lims_product_warehouse_data->imei_number .= ',' . $product_sale->imei_number;
                else
                    $lims_product_warehouse_data->imei_number = $product_sale->imei_number;
                $lims_product_warehouse_data->save();
            }
            $product_sale->delete();
        }

        $lims_payment_data = Payment::where('sale_id', $id)->get();
        foreach ($lims_payment_data as $payment) {
            if($payment->paying_method == 'Gift Card'){
                $lims_payment_with_gift_card_data = PaymentWithGiftCard::where('payment_id', $payment->id)->first();
                $lims_gift_card_data = GiftCard::find($lims_payment_with_gift_card_data->gift_card_id);
                $lims_gift_card_data->expense -= $payment->amount;
                $lims_gift_card_data->save();
                $lims_payment_with_gift_card_data->delete();
            }
            elseif($payment->paying_method == 'Cheque'){
                $lims_payment_cheque_data = PaymentWithCheque::where('payment_id', $payment->id)->first();
                if($lims_payment_cheque_data)
                    $lims_payment_cheque_data->delete();
            }
            elseif($payment->paying_method == 'Credit Card'){
                $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('payment_id', $payment->id)->first();
                if($lims_payment_with_credit_card_data)
                    $lims_payment_with_credit_card_data->delete();
            }
            elseif($payment->paying_method == 'Paypal'){
                $lims_payment_paypal_data = PaymentWithPaypal::where('payment_id', $payment->id)->first();
                if($lims_payment_paypal_data)
                    $lims_payment_paypal_data->delete();
            }
            elseif($payment->paying_method == 'Deposit'){
                $lims_customer_data = Customer::find($lims_sale_data->customer_id);
                $lims_customer_data->expense -= $payment->amount;
                $lims_customer_data->save();
            }
            $payment->delete();
        }
        if($lims_delivery_data)
            $lims_delivery_data->delete();
        if($lims_sale_data->coupon_id) {
            $lims_coupon_data = Coupon::find($lims_sale_data->coupon_id);
            $lims_coupon_data->used -= 1;
            $lims_coupon_data->save();
        }
        $lims_sale_data->delete();
        $this->fileDelete('documents/sale/', $lims_sale_data->document);

        return Redirect::to($url)->with('not_permitted', $message);
    }

  

    // public function saleData(Request $request)
    // {
    //     $columns = array(
    //         1 => 'created_at', 
    //         2 => 'reference_no',
    //         7 => 'grand_total',
    //         8 => 'paid_amount',
    //     );

    //     $warehouse_id = $request->input('warehouse_id');
    //     $sale_status = $request->input('sale_status');
    //     $payment_status = $request->input('payment_status');

    //     // Date range: use request (from form/DataTable) or session or default (same as index)
    //     $starting_date = $request->input('starting_date');
    //     $ending_date = $request->input('ending_date');
    //     if (empty($starting_date) || empty($ending_date)) {
    //         $starting_date = session('sale_filter_starting_date');
    //         $ending_date = session('sale_filter_ending_date');
    //     }
    //     if (empty($starting_date) || empty($ending_date)) {
    //         $ending_date = date('Y-m-d');
    //         $starting_date = date('Y-m-d', strtotime('-1 year', strtotime($ending_date)));
    //     }

    //     $sale_percentage = GeneralSetting::first()->percentage_filter ?? null;
    //     if ($sale_percentage === null || $sale_percentage === '') {
    //         if (session('percentage_filter') !== null) {
    //             $sale_percentage = (int) session('percentage_filter');
    //         } else {
    //             $settings = GeneralSetting::first();
    //             $sale_percentage = $settings && $settings->percentage_filter !== null ? (int) $settings->percentage_filter : null;
    //         }
    //     } else {
    //         $sale_percentage = (int) $sale_percentage;
    //     }
    //     if ($sale_percentage !== null && ($sale_percentage < 0 || $sale_percentage > 100)) {
    //         $sale_percentage = null;
    //     }

    //     // Only apply percentage filter if user has permission
    //     if (!Auth::user()->hasPermissionTo('sale-percentage-filter')) {
    //         $sale_percentage = null;
    //     }
    //     $filter_by_percentage = $sale_percentage !== null && $sale_percentage < 100;
    //     $filtered_sale_ids = [];
    //     $filtered_total_sales = 0;

    //     // Base query for all sales in the date range
    //     $baseQuery = Sale::whereDate('created_at', '>=', $starting_date)
    //                     ->whereDate('created_at', '<=', $ending_date);

    //     if($this->isStaff() && config('staff_access') == 'own')
    //         $baseQuery = $baseQuery->where('user_id', Auth::id());
    //     if($warehouse_id)
    //         $baseQuery = $baseQuery->where('warehouse_id', $warehouse_id);
    //     if($sale_status)
    //         $baseQuery = $baseQuery->where('sale_status', $sale_status);
    //     if($payment_status)
    //         $baseQuery = $baseQuery->where('payment_status', $payment_status);

    //     // Percentage filter: show only the top X% of sales by value (largest sales first until we reach X% of total)
    //     if ($filter_by_percentage) {
    //         $all_sales = (clone $baseQuery)->orderBy('grand_total', 'desc')->get(['id', 'grand_total']);
    //         $total_value = $all_sales->sum('grand_total');
    //         $target_value = $total_value * ($sale_percentage / 100);
    //         $running_sum = 0;
    //         foreach ($all_sales as $sale) {
    //             $filtered_sale_ids[] = $sale->id;
    //             $running_sum += $sale->grand_total;
    //             $filtered_total_sales = $running_sum;
    //             if ($running_sum >= $target_value) {
    //                 break;
    //             }
    //         }
    //         $baseQuery = $baseQuery->whereIn('id', $filtered_sale_ids);
    //     }

    //     $totalData = $baseQuery->count();
    //     $totalFiltered = $totalData;
    //     // Total sales amount for the filtered set (for the summary card)
    //     if ($filter_by_percentage) {
    //         $total_sales_amount = $filtered_total_sales;
    //     } else {
    //         $total_sales_amount = (clone $baseQuery)->sum('grand_total');
    //     }

    //     if($request->input('length') != -1)
    //         $limit = $request->input('length');
    //     else
    //         $limit = $totalData;
    //     $start = $request->input('start');
    //     $order = 'sales.'.$columns[$request->input('order.0.column')];
    //     $dir = $request->input('order.0.dir');
        
    //     //fetching custom fields data
    //     $custom_fields = CustomField::where([
    //                     ['belongs_to', 'sale'],
    //                     ['is_table', true]
    //                 ])->pluck('name');
    //     $field_names = [];
    //     foreach($custom_fields as $fieldName) {
    //         $field_names[] = str_replace(" ", "_", strtolower($fieldName));
    //     }
        
    //     if(empty($request->input('search.value'))) {
    //         // Get paginated results
    //         $q = Sale::with('biller', 'customer', 'warehouse', 'user')
    //             ->whereDate('created_at', '>=', $starting_date)
    //             ->whereDate('created_at', '<=', $ending_date)
    //             ->offset($start)
    //             ->limit($limit)
    //             ->orderBy($order, $dir);
                
    //         if($this->isStaff() && config('staff_access') == 'own')
    //             $q = $q->where('user_id', Auth::id());
    //         if($warehouse_id)
    //             $q = $q->where('warehouse_id', $warehouse_id);
    //         if($sale_status)
    //             $q = $q->where('sale_status', $sale_status);
    //         if($payment_status)
    //             $q = $q->where('payment_status', $payment_status);
            
    //         // Apply filtered sale IDs from percentage filter
    //         if ($filter_by_percentage && count($filtered_sale_ids) > 0) {
    //             $q = $q->whereIn('id', $filtered_sale_ids);
    //         } elseif ($filter_by_percentage && count($filtered_sale_ids) == 0) {
    //             $q = $q->whereIn('id', []);
    //         }
                
    //         $sales = $q->get();
    //     }
    //     else
    //     {
    //         $search = $request->input('search.value');
    //         $q = Sale::join('customers', 'sales.customer_id', '=', 'customers.id')
    //             ->join('billers', 'sales.biller_id', '=', 'billers.id')
    //             ->whereDate('sales.created_at', '>=', $starting_date)
    //             ->whereDate('sales.created_at', '<=', $ending_date)
    //             ->where(function($query) use ($search, $field_names) {
    //                 $query->where('sales.reference_no', 'LIKE', "%{$search}%")
    //                     ->orWhere('customers.name', 'LIKE', "%{$search}%")
    //                     ->orWhere('customers.phone_number', 'LIKE', "%{$search}%")
    //                     ->orWhere('billers.name', 'LIKE', "%{$search}%");
                    
    //                 foreach ($field_names as $field_name) {
    //                     $query->orWhere('sales.' . $field_name, 'LIKE', "%{$search}%");
    //                 }
    //             })
    //             ->select('sales.*')
    //             ->with('biller', 'customer', 'warehouse', 'user')
    //             ->offset($start)
    //             ->limit($limit)
    //             ->orderBy($order, $dir);
                
    //         if($this->isStaff() && config('staff_access') == 'own') {
    //             $q = $q->where('sales.user_id', Auth::id());
    //         }
    //         if($warehouse_id)
    //             $q = $q->where('sales.warehouse_id', $warehouse_id);
    //         if($sale_status)
    //             $q = $q->where('sales.sale_status', $sale_status);
    //         if($payment_status)
    //             $q = $q->where('sales.payment_status', $payment_status);
            
    //         // Apply filtered sale IDs from percentage filter
    //         if ($filter_by_percentage && count($filtered_sale_ids) > 0) {
    //             $q = $q->whereIn('sales.id', $filtered_sale_ids);
    //         } elseif ($filter_by_percentage && count($filtered_sale_ids) == 0) {
    //             $q = $q->whereIn('sales.id', []);
    //         }
                
    //         $sales = $q->get();
    //         $totalFiltered = $q->count();
    //     }
        
    //     $data = array();
    //     if(!empty($sales))
    //     {
    //         foreach ($sales as $key=>$sale)
    //         {
    //             $nestedData['id'] = $sale->id;
    //             $nestedData['key'] = $key;
    //             $nestedData['date'] = date(config('date_format'), strtotime($sale->created_at->toDateString()));
    //             $nestedData['reference_no'] = $sale->reference_no;
    //             $nestedData['biller'] = $sale->biller->name;
    //             $nestedData['customer'] = $sale->customer->name.'<br>'.$sale->customer->phone_number.'<input type="hidden" class="deposit" value="'.($sale->customer->deposit - $sale->customer->expense).'" />'.'<input type="hidden" class="points" value="'.$sale->customer->points.'" />';

    //             if($sale->sale_status == 1){
    //                 $nestedData['sale_status'] = '<div class="badge badge-success">'.trans('file.Completed').'</div>';
    //                 $sale_status_text = trans('file.Completed');
    //             }
    //             elseif($sale->sale_status == 2){
    //                 $nestedData['sale_status'] = '<div class="badge badge-danger">'.trans('file.Pending').'</div>';
    //                 $sale_status_text = trans('file.Pending');
    //             }
    //             elseif($sale->sale_status == 3){
    //                 $nestedData['sale_status'] = '<div class="badge badge-warning">'.trans('file.Draft').'</div>';
    //                 $sale_status_text = trans('file.Draft');
    //             }
    //             elseif($sale->sale_status == 4){
    //                 $nestedData['sale_status'] = '<div class="badge badge-danger">'.trans('file.Returned').'</div>';
    //                 $sale_status_text = trans('file.Returned');
    //             }

    //             if($sale->payment_status == 1)
    //                 $nestedData['payment_status'] = '<div class="badge badge-danger">'.trans('file.Pending').'</div>';
    //             elseif($sale->payment_status == 2)
    //                 $nestedData['payment_status'] = '<div class="badge badge-danger">'.trans('file.Due').'</div>';
    //             elseif($sale->payment_status == 3)
    //                 $nestedData['payment_status'] = '<div class="badge badge-warning">'.trans('file.Partial').'</div>';
    //             else
    //                 $nestedData['payment_status'] = '<div class="badge badge-success">'.trans('file.Paid').'</div>';
                
    //             $delivery_data = DB::table('deliveries')->select('status')->where('sale_id', $sale->id)->first();
    //             if($delivery_data) {
    //                 if($delivery_data->status == 1)
    //                     $nestedData['delivery_status'] = '<div class="badge badge-info">'.trans('file.Packing').'</div>';
    //                 elseif($delivery_data->status == 2)
    //                     $nestedData['delivery_status'] = '<div class="badge badge-info">'.trans('file.Delivering').'</div>';
    //                 elseif($delivery_data->status == 3)
    //                     $nestedData['delivery_status'] = '<div class="badge badge-info">'.trans('file.Delivered').'</div>';
    //                 elseif($delivery_data->status == 0)
    //                     $nestedData['delivery_status'] = '<div class="badge badge-danger">Customer Unavailable</div>';
    //             }
    //             else
    //                 $nestedData['delivery_status'] = 'N/A';

    //             $nestedData['grand_total'] = number_format($sale->grand_total, config('decimal'));
                
    //             $returned_amount = DB::table('returns')->where('sale_id', $sale->id)->sum('grand_total');
    //             $nestedData['returned_amount'] = number_format($returned_amount, config('decimal'));
    //             $nestedData['paid_amount'] = number_format($sale->paid_amount, config('decimal'));
    //             $nestedData['due'] = number_format($sale->grand_total - $returned_amount - $sale->paid_amount, config('decimal'));
                
    //             //fetching custom fields data
    //             foreach($field_names as $field_name) {
    //                 $nestedData[$field_name] = $sale->$field_name;
    //             }
                
    //             $nestedData['options'] = '<div class="btn-group">
    //                         <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">'.trans("file.action").'
    //                         <span class="caret"></span>
    //                         <span class="sr-only">Toggle Dropdown</span>
    //                         </button>
    //                         <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default" user="menu">
    //                             <li><a href="'.route('sale.invoice', $sale->id).'" class="btn btn-link"><i class="fa fa-copy"></i> '.trans('file.Generate Invoice').'</a></li>
    //                             <li>
    //                                 <button type="button" class="btn btn-link view"><i class="fa fa-eye"></i> '.trans('file.View').'</button>
    //                             </li>';
    //             if(in_array("sales-edit", $request['all_permission'])){
    //                 if($sale->sale_status != 3)
    //                     $nestedData['options'] .= '<li>
    //                         <a href="'.route('sales.edit', $sale->id).'" class="btn btn-link"><i class="dripicons-document-edit"></i> '.trans('file.edit').'</a>
    //                         </li>';
    //                 else
    //                     $nestedData['options'] .= '<li>
    //                         <a href="'.url('sales/'.$sale->id.'/create').'" class="btn btn-link"><i class="dripicons-document-edit"></i> '.trans('file.edit').'</a>
    //                     </li>';
    //             }
    //             if(in_array("sale-payment-index", $request['all_permission']))
    //                 $nestedData['options'] .=
    //                     '<li>
    //                         <button type="button" class="get-payment btn btn-link" data-id = "'.$sale->id.'"><i class="fa fa-money"></i> '.trans('file.View Payment').'</button>
    //                     </li>';
    //             if(in_array("sale-payment-add", $request['all_permission']))
    //                 $nestedData['options'] .=
    //                     '<li>
    //                         <button type="button" class="add-payment btn btn-link" data-id = "'.$sale->id.'" data-toggle="modal" data-target="#add-payment"><i class="fa fa-plus"></i> '.trans('file.Add Payment').'</button>
    //                     </li>';

    //             $nestedData['options'] .=
    //                 '<li>
    //                     <button type="button" class="add-delivery btn btn-link" data-id = "'.$sale->id.'"><i class="fa fa-truck"></i> '.trans('file.Add Delivery').'</button>
    //                 </li>';
    //             if(in_array("sales-delete", $request['all_permission']))
    //                 $nestedData['options'] .= \Form::open(["route" => ["sales.destroy", $sale->id], "method" => "DELETE"] ).'
    //                         <li>
    //                         <button type="submit" class="btn btn-link" onclick="return confirmDelete()"><i class="dripicons-trash"></i> '.trans("file.delete").'</button>
    //                         </li>'.\Form::close().'
    //                     </ul>
    //                 </div>';
                
    //             // data for sale details by one click
    //             $coupon = Coupon::find($sale->coupon_id);
    //             if($coupon)
    //                 $coupon_code = $coupon->code;
    //             else
    //                 $coupon_code = null;

    //             if($sale->currency_id)
    //                 $currency_code = Currency::select('code')->find($sale->currency_id)->code;
    //             else
    //                 $currency_code = 'N/A';

    //             $nestedData['sale'] = array( '[ "'.date(config('date_format'), strtotime($sale->created_at->toDateString())).'"', ' "'.$sale->reference_no.'"', ' "'.$sale_status_text.'"', ' "'.$sale->biller->name.'"', ' "'.$sale->biller->company_name.'"', ' "'.$sale->biller->email.'"', ' "'.$sale->biller->phone_number.'"', ' "'.$sale->biller->address.'"', ' "'.$sale->biller->city.'"', ' "'.$sale->customer->name.'"', ' "'.$sale->customer->phone_number.'"', ' "'.$sale->customer->address.'"', ' "'.$sale->customer->city.'"', ' "'.$sale->id.'"', ' "'.$sale->total_tax.'"', ' "'.$sale->total_discount.'"', ' "'.$sale->total_price.'"', ' "'.$sale->order_tax.'"', ' "'.$sale->order_tax_rate.'"', ' "'.$sale->order_discount.'"', ' "'.$sale->shipping_cost.'"', ' "'.$sale->grand_total.'"', ' "'.$sale->paid_amount.'"', ' "'.preg_replace('/[\n\r]/', "<br>", $sale->sale_note).'"', ' "'.preg_replace('/[\n\r]/', "<br>", $sale->staff_note).'"', ' "'.$sale->user->name.'"', ' "'.$sale->user->email.'"', ' "'.$sale->warehouse->name.'"', ' "'.$coupon_code.'"', ' "'.$sale->coupon_discount.'"', ' "'.$sale->document.'"', ' "'.$currency_code.'"', ' "'.$sale->exchange_rate.'"]'
    //             );
                
    //             $data[] = $nestedData;
    //         }
    //     }
        
    //     $json_data = array(
    //         "draw"            => intval($request->input('draw')),
    //         "recordsTotal"    => intval($totalData),
    //         "recordsFiltered" => intval($totalFiltered),
    //         "data"            => $data,
    //         "total_sales_amount" => $total_sales_amount
    //     );
        
    //     echo json_encode($json_data);
    // }

public function saleData(Request $request)
{
    $columns = array(
        1 => 'created_at',
        2 => 'reference_no',
        7 => 'grand_total',
        8 => 'paid_amount',
    );

    $warehouse_id   = $request->input('warehouse_id');
    $sale_status    = $request->input('sale_status');
    $payment_status = $request->input('payment_status');

    /* ------------------------------------------------------------------
     * 1.  Date range – default to CURRENT CALENDAR YEAR (yearly basis)
     * ------------------------------------------------------------------ */
    $starting_date = $request->input('starting_date');
    $ending_date   = $request->input('ending_date');

    if (empty($starting_date) || empty($ending_date)) {
        $starting_date = session('sale_filter_starting_date');
        $ending_date   = session('sale_filter_ending_date');
    }
    if (empty($starting_date) || empty($ending_date)) {
        $starting_date = date('Y-01-01');
        $ending_date   = date('Y-12-31');
    }

    /* ------------------------------------------------------------------
     * 2.  Percentage filter value
     * ------------------------------------------------------------------ */
    $sale_percentage = GeneralSetting::first()->percentage_filter ?? null;

    if ($sale_percentage === null || $sale_percentage === '') {
        if (session('percentage_filter') !== null) {
            $sale_percentage = (int) session('percentage_filter');
        } else {
            $settings = GeneralSetting::first();
            $sale_percentage = $settings && $settings->percentage_filter !== null
                ? (int) $settings->percentage_filter
                : null;
        }
    } else {
        $sale_percentage = (int) $sale_percentage;
    }

    if ($sale_percentage !== null && ($sale_percentage < 0 || $sale_percentage > 100)) {
        $sale_percentage = null;
    }

    if (!Auth::user()->hasPermissionTo('sale-percentage-filter')) {
        $sale_percentage = null;
    }

    $filter_by_percentage = $sale_percentage !== null && $sale_percentage < 100 && $sale_percentage > 0;
    $filtered_sale_ids    = [];

    /* ------------------------------------------------------------------
     * 3.  Base query (all filters except search & pagination)
     * ------------------------------------------------------------------ */
    $baseQuery = Sale::whereDate('created_at', '>=', $starting_date)
                     ->whereDate('created_at', '<=', $ending_date);

    if ($this->isStaff() && config('staff_access') == 'own') {
        $baseQuery = $baseQuery->where('user_id', Auth::id());
    }
    if ($warehouse_id) {
        $baseQuery = $baseQuery->where('warehouse_id', $warehouse_id);
    }
    if ($sale_status) {
        $baseQuery = $baseQuery->where('sale_status', $sale_status);
    }
    if ($payment_status) {
        $baseQuery = $baseQuery->where('payment_status', $payment_status);
    }

    /* ------------------------------------------------------------------
     * 4.  100 % total (this is the baseline for the percentage math)
     * ------------------------------------------------------------------ */
    $total_100 = (clone $baseQuery)->sum('grand_total');

    /* ------------------------------------------------------------------
     * 5.  Percentage filter – accumulate chronologically to decide
     *     WHICH rows appear in the table, but the CARD will show the
     *     exact mathematical percentage of $total_100.
     * ------------------------------------------------------------------ */
    if ($filter_by_percentage) {
        $all_sales = (clone $baseQuery)
            ->orderBy('created_at', 'asc')
            ->get(['id', 'grand_total']);

        $target_value = $total_100 * ($sale_percentage / 100);
        $running_sum  = 0;

        foreach ($all_sales as $sale) {
            $filtered_sale_ids[] = $sale->id;
            $running_sum += $sale->grand_total;
            if ($running_sum >= $target_value) {
                break;
            }
        }

        if (count($filtered_sale_ids) > 0) {
            $baseQuery = $baseQuery->whereIn('id', $filtered_sale_ids);
        } else {
            $baseQuery = $baseQuery->whereIn('id', []);
        }
    }

    /* ------------------------------------------------------------------
     * 6.  DataTables counts
     * ------------------------------------------------------------------ */
    $totalData     = $baseQuery->count();
    $totalFiltered = $totalData;

    $limit = $request->input('length') != -1 ? $request->input('length') : $totalData;
    $start = $request->input('start');
    $order = 'sales.' . $columns[$request->input('order.0.column')];
    $dir   = $request->input('order.0.dir');

    /* ------------------------------------------------------------------
     * 7.  Custom fields
     * ------------------------------------------------------------------ */
    $custom_fields = CustomField::where([
        ['belongs_to', 'sale'],
        ['is_table', true]
    ])->pluck('name');

    $field_names = [];
    foreach ($custom_fields as $fieldName) {
        $field_names[] = str_replace(" ", "_", strtolower($fieldName));
    }

    /* ------------------------------------------------------------------
     * 8.  Fetch results
     * ------------------------------------------------------------------ */
    if (empty($request->input('search.value'))) {
        // ----- No search -----
        $sales = $baseQuery->with('biller', 'customer', 'warehouse', 'user')
            ->offset($start)
            ->limit($limit)
            ->orderBy($order, $dir)
            ->get();

        // Exact percentage of the 100 % total (filterable by warehouse/status/date)
        if ($filter_by_percentage) {
            $total_sales_amount = $total_100 * ($sale_percentage / 100);
        } else {
            $total_sales_amount = $total_100;
        }

    } else {
        // ----- Search active -----
        $search = $request->input('search.value');

        $q = Sale::join('customers', 'sales.customer_id', '=', 'customers.id')
            ->join('billers', 'sales.biller_id', '=', 'billers.id')
            ->whereDate('sales.created_at', '>=', $starting_date)
            ->whereDate('sales.created_at', '<=', $ending_date)
            ->where(function ($query) use ($search, $field_names) {
                $query->where('sales.reference_no', 'LIKE', "%{$search}%")
                      ->orWhere('customers.name', 'LIKE', "%{$search}%")
                      ->orWhere('customers.phone_number', 'LIKE', "%{$search}%")
                      ->orWhere('billers.name', 'LIKE', "%{$search}%");

                foreach ($field_names as $field_name) {
                    $query->orWhere('sales.' . $field_name, 'LIKE', "%{$search}%");
                }
            })
            ->select('sales.*')
            ->with('biller', 'customer', 'warehouse', 'user');

        if ($this->isStaff() && config('staff_access') == 'own') {
            $q = $q->where('sales.user_id', Auth::id());
        }
        if ($warehouse_id) {
            $q = $q->where('sales.warehouse_id', $warehouse_id);
        }
        if ($sale_status) {
            $q = $q->where('sales.sale_status', $sale_status);
        }
        if ($payment_status) {
            $q = $q->where('sales.payment_status', $payment_status);
        }

        // Apply the same percentage IDs so the table stays consistent
        if ($filter_by_percentage && count($filtered_sale_ids) > 0) {
            $q = $q->whereIn('sales.id', $filtered_sale_ids);
        } elseif ($filter_by_percentage) {
            $q = $q->whereIn('sales.id', []);
        }

        // 100 % total of the SEARCH results (so the card updates when typing)
        $total_100_search = (clone $q)->sum('sales.grand_total');

        $totalFiltered = $q->count();

        $sales = $q->offset($start)
                   ->limit($limit)
                   ->orderBy($order, $dir)
                   ->get();

        // Exact percentage of the searched 100 % total
        if ($filter_by_percentage) {
            $total_sales_amount = $total_100_search * ($sale_percentage / 100);
        } else {
            $total_sales_amount = $total_100_search;
        }
    }

    /* ------------------------------------------------------------------
     * 9.  Build DataTables response
     * ------------------------------------------------------------------ */
    $data = array();

    if (!empty($sales)) {
        foreach ($sales as $key => $sale) {
            $nestedData['id']           = $sale->id;
            $nestedData['key']          = $key;
            $nestedData['date']         = date(config('date_format'), strtotime($sale->created_at->toDateString()));
            $nestedData['reference_no'] = $sale->reference_no;
            $nestedData['biller']       = $sale->biller->name;
            $nestedData['customer']     = $sale->customer->name . '<br>' . $sale->customer->phone_number
                . '<input type="hidden" class="deposit" value="' . ($sale->customer->deposit - $sale->customer->expense) . '" />'
                . '<input type="hidden" class="points" value="' . $sale->customer->points . '" />';

            if ($sale->sale_status == 1) {
                $nestedData['sale_status'] = '<div class="badge badge-success">' . trans('file.Completed') . '</div>';
                $sale_status_text = trans('file.Completed');
            } elseif ($sale->sale_status == 2) {
                $nestedData['sale_status'] = '<div class="badge badge-danger">' . trans('file.Pending') . '</div>';
                $sale_status_text = trans('file.Pending');
            } elseif ($sale->sale_status == 3) {
                $nestedData['sale_status'] = '<div class="badge badge-warning">' . trans('file.Draft') . '</div>';
                $sale_status_text = trans('file.Draft');
            } else {
                $nestedData['sale_status'] = '<div class="badge badge-danger">' . trans('file.Returned') . '</div>';
                $sale_status_text = trans('file.Returned');
            }

            if ($sale->payment_status == 1) {
                $nestedData['payment_status'] = '<div class="badge badge-danger">' . trans('file.Pending') . '</div>';
            } elseif ($sale->payment_status == 2) {
                $nestedData['payment_status'] = '<div class="badge badge-danger">' . trans('file.Due') . '</div>';
            } elseif ($sale->payment_status == 3) {
                $nestedData['payment_status'] = '<div class="badge badge-warning">' . trans('file.Partial') . '</div>';
            } else {
                $nestedData['payment_status'] = '<div class="badge badge-success">' . trans('file.Paid') . '</div>';
            }

            $delivery_data = DB::table('deliveries')->select('status')->where('sale_id', $sale->id)->first();
            if ($delivery_data) {
                if ($delivery_data->status == 1) {
                    $nestedData['delivery_status'] = '<div class="badge badge-info">' . trans('file.Packing') . '</div>';
                } elseif ($delivery_data->status == 2) {
                    $nestedData['delivery_status'] = '<div class="badge badge-info">' . trans('file.Delivering') . '</div>';
                } elseif ($delivery_data->status == 3) {
                    $nestedData['delivery_status'] = '<div class="badge badge-info">' . trans('file.Delivered') . '</div>';
                } else {
                    $nestedData['delivery_status'] = '<div class="badge badge-danger">Customer Unavailable</div>';
                }
            } else {
                $nestedData['delivery_status'] = 'N/A';
            }

            $nestedData['grand_total'] = number_format($sale->grand_total, config('decimal'));

            $returned_amount = DB::table('returns')->where('sale_id', $sale->id)->sum('grand_total');
            $nestedData['returned_amount'] = number_format($returned_amount, config('decimal'));
            $nestedData['paid_amount']     = number_format($sale->paid_amount, config('decimal'));
            $nestedData['due']             = number_format($sale->grand_total - $returned_amount - $sale->paid_amount, config('decimal'));

            foreach ($field_names as $field_name) {
                $nestedData[$field_name] = $sale->$field_name;
            }

            // ----- Action buttons -----
            $nestedData['options'] = '<div class="btn-group">
                <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">' . trans("file.action") . '
                <span class="caret"></span>
                <span class="sr-only">Toggle Dropdown</span>
                </button>
                <ul class="dropdown-menu edit-options dropdown-menu-right dropdown-default" user="menu">
                    <li><a href="' . route('sale.invoice', $sale->id) . '" class="btn btn-link"><i class="fa fa-copy"></i> ' . trans('file.Generate Invoice') . '</a></li>
                    <li><button type="button" class="btn btn-link view"><i class="fa fa-eye"></i> ' . trans('file.View') . '</button></li>';

            if (in_array("sales-edit", $request['all_permission'])) {
                if ($sale->sale_status != 3) {
                    $nestedData['options'] .= '<li><a href="' . route('sales.edit', $sale->id) . '" class="btn btn-link"><i class="dripicons-document-edit"></i> ' . trans('file.edit') . '</a></li>';
                } else {
                    $nestedData['options'] .= '<li><a href="' . url('sales/' . $sale->id . '/create') . '" class="btn btn-link"><i class="dripicons-document-edit"></i> ' . trans('file.edit') . '</a></li>';
                }
            }

            if (in_array("sale-payment-index", $request['all_permission'])) {
                $nestedData['options'] .= '<li><button type="button" class="get-payment btn btn-link" data-id="' . $sale->id . '"><i class="fa fa-money"></i> ' . trans('file.View Payment') . '</button></li>';
            }

            if (in_array("sale-payment-add", $request['all_permission'])) {
                $nestedData['options'] .= '<li><button type="button" class="add-payment btn btn-link" data-id="' . $sale->id . '" data-toggle="modal" data-target="#add-payment"><i class="fa fa-plus"></i> ' . trans('file.Add Payment') . '</button></li>';
            }

            $nestedData['options'] .= '<li><button type="button" class="add-delivery btn btn-link" data-id="' . $sale->id . '"><i class="fa fa-truck"></i> ' . trans('file.Add Delivery') . '</button></li>';

            if (in_array("sales-delete", $request['all_permission'])) {
                $nestedData['options'] .= \Form::open(["route" => ["sales.destroy", $sale->id], "method" => "DELETE"]) . '
                    <li><button type="submit" class="btn btn-link" onclick="return confirmDelete()"><i class="dripicons-trash"></i> ' . trans("file.delete") . '</button></li>' . \Form::close();
            }

            $nestedData['options'] .= '</ul></div>';

            // ----- One-click sale details -----
            $coupon = Coupon::find($sale->coupon_id);
            $coupon_code = $coupon ? $coupon->code : null;

            $currency_code = $sale->currency_id
                ? Currency::select('code')->find($sale->currency_id)->code
                : 'N/A';

            $nestedData['sale'] = array(
                '[ "' . date(config('date_format'), strtotime($sale->created_at->toDateString())) . '"',
                ' "' . $sale->reference_no . '"',
                ' "' . $sale_status_text . '"',
                ' "' . $sale->biller->name . '"',
                ' "' . $sale->biller->company_name . '"',
                ' "' . $sale->biller->email . '"',
                ' "' . $sale->biller->phone_number . '"',
                ' "' . $sale->biller->address . '"',
                ' "' . $sale->biller->city . '"',
                ' "' . $sale->customer->name . '"',
                ' "' . $sale->customer->phone_number . '"',
                ' "' . $sale->customer->address . '"',
                ' "' . $sale->customer->city . '"',
                ' "' . $sale->id . '"',
                ' "' . $sale->total_tax . '"',
                ' "' . $sale->total_discount . '"',
                ' "' . $sale->total_price . '"',
                ' "' . $sale->order_tax . '"',
                ' "' . $sale->order_tax_rate . '"',
                ' "' . $sale->order_discount . '"',
                ' "' . $sale->shipping_cost . '"',
                ' "' . $sale->grand_total . '"',
                ' "' . $sale->paid_amount . '"',
                ' "' . preg_replace('/[\n\r]/', "<br>", $sale->sale_note) . '"',
                ' "' . preg_replace('/[\n\r]/', "<br>", $sale->staff_note) . '"',
                ' "' . $sale->user->name . '"',
                ' "' . $sale->user->email . '"',
                ' "' . $sale->warehouse->name . '"',
                ' "' . $coupon_code . '"',
                ' "' . $sale->coupon_discount . '"',
                ' "' . $sale->document . '"',
                ' "' . $currency_code . '"',
                ' "' . $sale->exchange_rate . '"]'
            );

            $data[] = $nestedData;
        }
    }

    $json_data = array(
        "draw"               => intval($request->input('draw')),
        "recordsTotal"       => intval($totalData),
        "recordsFiltered"    => intval($totalFiltered),
        "data"               => $data,
        "total_sales_amount" => $total_sales_amount
    );

    echo json_encode($json_data);
}

   
    private function processGiftCardPayment($payment_data, $amount)
    {
        $gift_card_id = request('gift_card_id');
        if ($gift_card_id) {
            $lims_gift_card_data = GiftCard::find($gift_card_id);
            $lims_gift_card_data->expense += $amount;
            $lims_gift_card_data->save();
            PaymentWithGiftCard::create([
                'payment_id' => $payment_data->id,
                'gift_card_id' => $gift_card_id
            ]);
        }
    }

    private function processCreditCardPayment($payment_data, $sale_data, $amount)
    {
        $lims_pos_setting_data = PosSetting::latest()->first();
        Stripe::setApiKey($lims_pos_setting_data->stripe_secret_key);

        try {
            $lims_payment_with_credit_card_data = PaymentWithCreditCard::where('customer_id', $sale_data->customer_id)->first();

            if (!$lims_payment_with_credit_card_data) {
                $customer = \Stripe\Customer::create([
                    'source' => request('stripeToken')
                ]);
                $customer_stripe_id = $customer->id;
            } else {
                $customer_stripe_id = $lims_payment_with_credit_card_data->customer_stripe_id;
            }

            $charge = \Stripe\Charge::create([
                'amount' => $amount * 100,
                'currency' => 'usd',
                'customer' => $customer_stripe_id
            ]);

            PaymentWithCreditCard::create([
                'payment_id' => $payment_data->id,
                'customer_id' => $sale_data->customer_id,
                'customer_stripe_id' => $customer_stripe_id,
                'charge_id' => $charge->id
            ]);
        } catch (\Exception $e) {
            throw new \Exception('Error processing credit card payment: ' . $e->getMessage());
        }
    }

    private function processPointsPayment($payment_data, $customer_data, $amount)
    {
        $lims_reward_point_setting_data = RewardPointSetting::latest()->first();
        $used_points = ceil($amount / $lims_reward_point_setting_data->per_point_amount);
        $payment_data->used_points = $used_points;
        $customer_data->points -= $used_points;
        $customer_data->save();
    }

    private function sendPaymentEmail($customer, $sale, $paid_amount, $balance)
    {
        $mail_setting = MailSetting::latest()->first();
        
        if ($customer->email && $mail_setting) {
            try {
                $mail_data = [
                    'email' => $customer->email,
                    'sale_reference' => $sale->reference_no,
                    'payment_reference' => 'Multiple Payments',
                    'payment_method' => 'Multiple Methods',
                    'grand_total' => $sale->grand_total,
                    'paid_amount' => $paid_amount,
                    'due' => $balance,
                    'currency' => config('currency')
                ];

                $this->setMailInfo($mail_setting);
                Mail::to($mail_data['email'])->send(new PaymentDetails($mail_data));
            } catch (\Exception $e) {
                // Email sending failed, but payment process should continue
                // Log the error or handle it as needed
            }
        }
    }

    function ads() {
        $ads = Ads::all();
        return view('backend.sale.ads',compact('ads'));
    }

    function createAd() {
        $staffs = User::whereIn('role_id', array(1, 2, 4, 6))->get();
        return view('backend.sale.createAd',compact('staffs'));
    }

    function storeAd(Request $request) {
        $this->validate($request, [
            'staff_id' => [
                'required'
            ],
            'input' => [
                'required'
            ],
            'channel' => [
                'required'
            ],
            'start' => [
                'required'
            ],
            'end' => [
                'required'
            ],
        ]);

        Ads::create([
            'staff_id' => $request->input('staff_id'),
            'input' => $request->input('input'),
            'channel' => $request->input('channel'),
            'start' => $request->input('start'),
            'end' => $request->input('end'),
            'remarks' => $request->input('remarks')
        ]);

        $message = 'Ad Created successfully';
        return Redirect::to('ads')->with('message', $message);
    }

    function editAd($id) {
        $staffs = User::whereIn('role_id', array(1, 2, 4, 6))->get();
        $ad = Ads::find($id);
        return view('backend.sale.editAd', compact('ad', 'staffs'));
    }

    function deleteAd($id) {
        Ads::where('id', $id)->delete();

        $message = 'Ad Deleted successfully';
        return Redirect::to('ads')->with('message', $message);
    }

    function updateAd(Request $request) {
        $this->validate($request, [
            'id' => [
                'required'
            ],
            'staff_id' => [
                'required'
            ],
            'input' => [
                'required'
            ],
            'channel' => [
                'required'
            ],
            'start' => [
                'required'
            ],
            'end' => [
                'required'
            ],
        ]);

        Ads::where('id', $request->input('id'))->update([
            'staff_id' => $request->input('staff_id'),
            'input' => $request->input('input'),
            'channel' => $request->input('channel'),
            'start' => $request->input('start'),
            'end' => $request->input('end'),
            'remarks' => $request->input('remarks')
        ]);

        $message = 'Ad Updated successfully';
        return Redirect::to('ads')->with('message', $message);
    }

    /**
     * Save sale percentage filter as default for all users
     */
    public function saveDefaultFilter(Request $request)
    {
        if ($this->isStaff() || !Auth::user()->hasPermissionTo('sale-percentage-filter')) {
            return response()->json([
                'success' => false,
                'message' => 'Only administrators with Sale Filter permission can set default filters.'
            ], 403);
        }

        $request->validate([
            'percentage_filter' => 'required|integer|min:0|max:100'
        ]);

        try {
            $settings = GeneralSetting::first();
            if (!$settings) {
                $settings = new GeneralSetting();
            }

            $settings->percentage_filter = (int) $request->input('percentage_filter');
            $settings->save();

            return response()->json([
                'success' => true,
                'message' => 'Default percentage filter saved successfully'
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Error saving filter: ' . $e->getMessage()
            ], 500);
        }
    }
}
