<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Supplier;
use App\Models\Customer;
use App\Models\CustomerGroup;
use App\Models\Purchase;
use App\Models\CashRegister;
use App\Models\Account;
use App\Models\Payment;
use App\Models\MailSetting;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Mail\SupplierCreate;
use App\Mail\CustomerCreate;
use App\Models\Product;
use Mail;

class SupplierController extends Controller
{
    use \App\Traits\MailInfo;

    public function index()
    {

        if(Auth::user()->hasPermissionTo('suppliers-index')){
            $all_permission = Auth::user()->getAllPermissions();

            if (empty($all_permission)) {
                $all_permission[] = 'dummy text';
            }
            $lims_supplier_all = Supplier::where('is_active', true)->get();
            return view('backend.supplier.index',compact('lims_supplier_all', 'all_permission'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function clearDue(Request $request)
    {
        $lims_due_purchase_data = Purchase::select('id', 'warehouse_id', 'grand_total', 'paid_amount', 'payment_status')
                            ->where([
                                ['payment_status', 1],
                                ['supplier_id', $request->supplier_id]
                            ])->get();
        $total_paid_amount = $request->amount;
        foreach ($lims_due_purchase_data as $key => $purchase_data) {
            if($total_paid_amount == 0)
                break;
            $due_amount = $purchase_data->grand_total - $purchase_data->paid_amount;
            $lims_cash_register_data =  CashRegister::select('id')
                                        ->where([
                                            ['user_id', Auth::id()],
                                            ['warehouse_id', $purchase_data->warehouse_id],
                                            ['status', 1]
                                        ])->first();
            if($lims_cash_register_data)
                $cash_register_id = $lims_cash_register_data->id;
            else
                $cash_register_id = null;
            $account_data = Account::select('id')->where('is_default', 1)->first();
            if($total_paid_amount >= $due_amount) {
                $paid_amount = $due_amount;
                $payment_status = 2;
            }
            else {
                $paid_amount = $total_paid_amount;
                $payment_status = 1;
            }
            Payment::create([
                'payment_reference' => 'ppr-'.date("Ymd").'-'.date("his"),
                'purchase_id' => $purchase_data->id,
                'user_id' => Auth::id(),
                'cash_register_id' => $cash_register_id,
                'account_id' => $account_data->id,
                'amount' => $paid_amount,
                'change' => 0,
                'paying_method' => 'Cash',
                'payment_note' => $request->note
            ]);
            $purchase_data->paid_amount += $paid_amount;
            $purchase_data->payment_status = $payment_status;
            $purchase_data->save();
            $total_paid_amount -= $paid_amount;
        }
        return redirect()->back()->with('message', 'Due cleared successfully');
    }

    public function create()
    {
        if(Auth::user()->hasPermissionTo('suppliers-add')){
            $lims_customer_group_all = CustomerGroup::where('is_active',true)->get();
            return view('backend.supplier.create', compact('lims_customer_group_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'company_name' => [
                'max:255',
                    Rule::unique('suppliers')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'email' => [
                'max:255',
                    Rule::unique('suppliers')->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'image' => 'image|mimes:jpg,jpeg,png,gif|max:100000',
        ]);

        //validation for customer if create both user and supplier
        if(isset($request->both)) {
            $this->validate($request, [
                'phone_number' => [
                    'max:255',
                    Rule::unique('customers')->where(function ($query) {
                        return $query->where('is_active', 1);
                    }),
                ],
            ]);
        }

        $lims_supplier_data = $request->except('image');
        $lims_supplier_data['is_active'] = true;
        $image = $request->image;
        if ($image) {
            $ext = pathinfo($image->getClientOriginalName(), PATHINFO_EXTENSION);
            $imageName = preg_replace('/[^a-zA-Z0-9]/', '', $request['company_name']);
            $imageName = $imageName . '.' . $ext;
            $image->move('public/images/supplier', $imageName);
            $lims_supplier_data['image'] = $imageName;
        }


        //if there is pay_term_no save it
        if (empty($lims_supplier_data['pay_term_no'])) {
            $lims_supplier_data['pay_term_no'] = $request->pay_term_no;
            $lims_supplier_data['pay_term_period'] = $request->pay_term_period;
        }
        Supplier::create($lims_supplier_data);
        $message = 'Supplier';
        if(isset($request->both)) {
            Customer::create($lims_supplier_data);
            $message .= ' and Customer';
        }
        $mail_setting = MailSetting::latest()->first();
        if($lims_supplier_data['email'] && $mail_setting) {
            $this->setMailInfo($mail_setting);
            try {
                Mail::to($lims_supplier_data['email'])->send(new SupplierCreate($lims_supplier_data));
                if(isset($request->both))
                    Mail::to($lims_supplier_data['email'])->send(new CustomerCreate($lims_supplier_data));
                $message .= ' created successfully!';
            }
            catch(\Exception $e) {
                $message .= ' created successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
            }
        }
        return redirect('supplier')->with('message', $message);
    }

    public function edit($id)
    {
        if(Auth::user()->hasPermissionTo('suppliers-edit')){
            $lims_supplier_data = Supplier::where('id',$id)->first();
            return view('backend.supplier.edit',compact('lims_supplier_data'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'company_name' => [
                'max:255',
                    Rule::unique('suppliers')->ignore($id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],

            'email' => [
                'max:255',
                    Rule::unique('suppliers')->ignore($id)->where(function ($query) {
                    return $query->where('is_active', 1);
                }),
            ],
            'image' => 'image|mimes:jpg,jpeg,png,gif|max:100000',
        ]);

        $lims_supplier_data = Supplier::findOrFail($id);

        $input = $request->except('image');
        $image = $request->image;
        if ($image) {
            $this->fileDelete('images/supplier/', $lims_supplier_data->image);

            $ext = pathinfo($image->getClientOriginalName(), PATHINFO_EXTENSION);
            $imageName = preg_replace('/[^a-zA-Z0-9]/', '', $request['company_name']);
            $imageName = $imageName . '.' . $ext;
            $image->move('public/images/supplier', $imageName);
            $input['image'] = $imageName;
        }

        $lims_supplier_data->update($input);
        return redirect('supplier')->with('message','Data updated successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $supplier_id = $request['supplierIdArray'];
        foreach ($supplier_id as $id) {
            $lims_supplier_data = Supplier::findOrFail($id);
            $lims_supplier_data->is_active = false;
            $lims_supplier_data->save();
            $this->fileDelete('images/supplier/', $lims_supplier_data->image);
        }
        return 'Supplier deleted successfully!';
    }

    public function destroy($id)
    {
        $lims_supplier_data = Supplier::findOrFail($id);
        $lims_supplier_data->is_active = false;
        $lims_supplier_data->save();
        $this->fileDelete('images/supplier/', $lims_supplier_data->image);

        return redirect('supplier')->with('not_permitted','Data deleted successfully');
    }

    public function productSearchByWarehouse(Request $request)
{
    $warehouse_id = $request->input('warehouse_id');

    if (!$warehouse_id) {
        return response()->json([]);
    }

    // Get product IDs that exist in the selected warehouse
    $product_ids = \DB::table('product_warehouse')
        ->where('warehouse_id', $warehouse_id)
        ->pluck('product_id')
        ->unique()
        ->toArray();

    if (empty($product_ids)) {
        return response()->json([]);
    }

    $productArray = [];

    // Non-variant products
    $products = Product::whereIn('id', $product_ids)
        ->where('is_active', true)
        ->whereNull('is_variant')
        ->select('id', 'name', 'code', 'price', 'qty', 'shelf')
        ->get();

    foreach ($products as $product) {
        $productArray[] = 'Code: ' . $product->code .
            ' | Name: ' . preg_replace('/[\n\r]/', " ", $product->name) .
            ' | Price: ' . $product->price .
            ' | Qty: ' . $product->qty .
            ' | Shelf: ' . preg_replace('/[\n\r]/', " ", $product->shelf ?? '');
    }

    // Variant products
    $variant_products = Product::join('product_variants', 'products.id', 'product_variants.product_id')
        ->whereIn('products.id', $product_ids)
        ->where('products.is_active', true)
        ->whereNotNull('products.is_variant')
        ->select('products.id', 'products.name', 'product_variants.item_code', 'products.price', 'products.qty', 'products.shelf')
        ->orderBy('product_variants.position')
        ->get();

    foreach ($variant_products as $product) {
        $productArray[] = 'Code: ' . $product->item_code .
            ' | Name: ' . preg_replace('/[\n\r]/', " ", $product->name) .
            ' | Price: ' . $product->price .
            ' | Qty: ' . $product->qty .
            ' | Shelf: ' . preg_replace('/[\n\r]/', " ", $product->shelf ?? '');
    }

    return response()->json($productArray);
}

    public function importSupplier(Request $request)
    {
        $upload=$request->file('file');
        $ext = pathinfo($upload->getClientOriginalName(), PATHINFO_EXTENSION);
        if($ext != 'csv')
            return redirect()->back()->with('not_permitted', 'Please upload a CSV file');
        $filename =  $upload->getClientOriginalName();
        $filePath=$upload->getRealPath();
        //open and read
        $file=fopen($filePath, 'r');
        $header= fgetcsv($file);
        $escapedHeader=[];
        //validate
        foreach ($header as $key => $value) {
            $lheader=strtolower($value);
            $escapedItem=preg_replace('/[^a-z]/', '', $lheader);
            array_push($escapedHeader, $escapedItem);
        }
        //looping through othe columns
        while($columns=fgetcsv($file))
        {
            if($columns[0]=="")
                continue;
            foreach ($columns as $key => $value) {
                $value=preg_replace('/\D/','',$value);
            }
           $data= array_combine($escapedHeader, $columns);

           $supplier = Supplier::firstOrNew(['company_name'=>$data['companyname']]);
           $supplier->name = $data['name'];
           $supplier->image = $data['image'];
           $supplier->vat_number = $data['vatnumber'];
           $supplier->email = $data['email'];
           $supplier->phone_number = $data['phonenumber'];
           $supplier->address = $data['address'];
           $supplier->city = $data['city'];
           $supplier->state = $data['state'];
           $supplier->postal_code = $data['postalcode'];
           $supplier->country = $data['country'];
           $supplier->is_active = true;
           $supplier->save();
           $message = 'Supplier Imported Successfully';

           $mail_setting = MailSetting::latest()->first();


           if($data['email'] && $mail_setting) {
                try {
                    Mail::to($data['email'])->send(new SupplierCreate($data));
                }
                catch(\Excetion $e){
                    $message = 'Supplier imported successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
                }
            }
        }
        return redirect('supplier')->with('message', $message);
    }

    public function suppliersAll()
    {
        $lims_supplier_list = DB::table('suppliers')->where('is_active', true)->get();
        
        $html = '';
        foreach($lims_supplier_list as $supplier){
            $html .='<option value="'.$supplier->id.'">'.$supplier->name . ' (' . $supplier->phone_number. ')'.'</option>';
        }

        return response()->json($html);
    }

    public function allCompanies()
    {
        $lims_company_list = DB::table('suppliers')
            ->where('is_active', true)
            ->whereNotNull('company_name')
            ->where('company_name', '!=', '')
            ->select('company_name')
            ->distinct()
            ->orderBy('company_name')
            ->get();
        
        $html = '';
        foreach($lims_company_list as $company){
            $html .='<option value="'.$company->company_name.'">'.$company->company_name.'</option>';
        }

        return response()->json($html);
    }



    public function quickStoreSupplier(Request $request)
{
    $validator = \Validator::make($request->all(), [
        'name'         => 'required|string|max:255',
        'company_name' => 'nullable|string|max:255',
        'email'        => 'nullable|email|max:255',
        'phone_number' => 'nullable|string|max:50',
        'address'      => 'nullable|string|max:500',
        'city'         => 'nullable|string|max:100',
        'state'        => 'nullable|string|max:100',
        'country'      => 'nullable|string|max:100',
        'vat_number'   => 'nullable|string|max:100',
    ]);

    if ($validator->fails()) {
        return response()->json(['errors' => $validator->errors()], 422);
    }

    $data = $request->all();
    $data['is_active'] = true;


    $supplier = Supplier::create($data);

    return response()->json([
        'id'           => $supplier->id,
        'name'         => $supplier->name,
        'company_name' => $supplier->company_name ?? '',
        'message'      => 'Supplier created successfully'
    ]);
}
}
