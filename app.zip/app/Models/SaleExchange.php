<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SaleExchange extends Model
{
    use HasFactory;
    public $guarded = [];
    public $table = 'sale_exchanges';
}
