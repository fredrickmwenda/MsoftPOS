<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tax extends Model
{
    protected $fillable =[
        "name", "rate", "is_active", "woocommerce_tax_id"
    ];

 

    public function products()
    {
        return $this->belongsToMany(Product::class, 'product_tax', 'tax_id', 'product_id');
    }


}
