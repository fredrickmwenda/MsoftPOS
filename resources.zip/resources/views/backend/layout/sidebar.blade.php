<style>
    /* Modern Sidebar Styling */
    #side-main-menu {
        background: #ffffff;
        padding: 0;
        margin: 0;
        list-style: none;
        position: relative;
        border-right: 1px solid #e0e0e0;
        box-shadow: 2px 0 8px rgba(0, 0, 0, 0.08);
        overflow-y: auto;
        overflow-x: hidden;
        -webkit-overflow-scrolling: touch;
    }

    #side-main-menu li {
        margin: 0;
        border: none;
    }

    #side-main-menu > li > a {
        display: flex;
        align-items: center;
        padding: 16px 20px;
        color: #1a1a2e;
        text-decoration: none;
        font-size: 15px;
        font-weight: 500;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        border-left: 4px solid transparent;
    }

    #side-main-menu > li > a::before {
        content: '';
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        background: rgba(102, 126, 234, 0.08);
        opacity: 0;
        transition: opacity 0.3s ease;
        z-index: -1;
    }

    #side-main-menu > li > a:hover {
        border-left-color: #13bd60;
        padding-left: 24px;
        color: #13bd60;
    }

    #side-main-menu > li > a:hover::before {
        opacity: 1;
    }

    #side-main-menu > li.active > a,
    #side-main-menu > li > a.active {
        background: rgba(102, 126, 234, 0.12);
        border-left-color: #13bd60;
        color: #13bd60;
        font-weight: 600;
    }

    #side-main-menu i {
        color: inherit;
        font-size: 18px;
        margin-right: 14px;
        min-width: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: transform 0.3s ease;
    }

    #side-main-menu > li > a:hover i {
        transform: translateX(4px);
    }

    #side-main-menu span {
        flex: 1;
        text-transform: capitalize;
        letter-spacing: 0.3px;
    }

    /* Dropdown Arrow Indicator */
    #side-main-menu > li > a[data-toggle='collapse']::after {
        content: '';
        position: absolute;
        right: 20px;
        width: 6px;
        height: 6px;
        border-right: 2px solid currentColor;
        border-bottom: 2px solid currentColor;
        transform: rotate(-45deg);
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        opacity: 0.7;
    }

    #side-main-menu > li > a[aria-expanded='true']::after {
        transform: rotate(45deg);
    }

    /* Submenu Styling */
    #side-main-menu .collapse {
        background: #f8f9fa;
        padding: 8px 0;
        margin: 0;
        list-style: none;
        border-left: 2px solid #e0e0e0;
        max-height: 500px;
        overflow: hidden;
        transition: max-height 0.5s ease, padding 0.3s ease;
    }

    #side-main-menu .collapse.show {
        max-height: 1000px;
        padding: 8px 0;
    }

    #side-main-menu .collapse li {
        margin: 0;
    }

    #side-main-menu .collapse li a {
        display: block;
        padding: 12px 20px 12px 50px;
        color: #555555;
        text-decoration: none;
        font-size: 14px;
        font-weight: 400;
        transition: all 0.2s ease;
        position: relative;
        border: none;
    }

    #side-main-menu .collapse li a::before {
        content: '';
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 4px;
        height: 0;
        background: #13bd60;
        transition: height 0.3s ease;
    }

    #side-main-menu .collapse li a:hover {
        background: #f0f1f7;
        padding-left: 54px;
        color: #13bd60;
        font-weight: 500;
    }

    #side-main-menu .collapse li a:hover::before {
        height: 24px;
    }

    #side-main-menu .collapse li a.active {
        background: #e8ecf9;
        color: #13bd60;
        font-weight: 600;
        padding-left: 54px;
        border-left: 3px solid #13bd60;
    }

    #side-main-menu .collapse li a.active::before {
        height: 24px;
    }

    /* Nested Collapse */
    #side-main-menu .collapse .collapse {
        background: #f0f1f7;
        border-left: 2px solid #d0d0e0;
    }

    #side-main-menu .collapse .collapse li a {
        padding-left: 70px;
        font-size: 13px;
        color: #666666;
    }

    #side-main-menu .collapse .collapse li a:hover {
        padding-left: 74px;
        background: #e8ecf9;
    }

    #side-main-menu .collapse .collapse li a.active {
        padding-left: 74px;
    }

    /* Scrollbar Styling */
    #side-main-menu::-webkit-scrollbar {
        width: 6px;
    }

    #side-main-menu::-webkit-scrollbar-track {
        background: transparent;
    }

    #side-main-menu::-webkit-scrollbar-thumb {
        background: #d0d0d0;
        border-radius: 3px;
    }

    #side-main-menu::-webkit-scrollbar-thumb:hover {
        background: #999999;
    }

    /* Mobile Responsive */
    @media (max-width: 768px) {
        #side-main-menu {
            position: fixed;
            left: -100%;
            top: 0;
            width: 100%;
            max-width: 280px;
            height: 100vh;
            z-index: 1000;
            transition: left 0.3s ease;
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.2);
            border-right: none;
        }

        #side-main-menu.show {
            left: 0;
        }

        #side-main-menu > li > a {
            padding: 14px 16px;
            font-size: 14px;
        }

        #side-main-menu .collapse li a {
            padding: 10px 16px 10px 44px;
        }

        #side-main-menu > li > a:hover {
            padding-left: 20px;
        }
    }
</style>

<ul id="side-main-menu" class="side-menu list-unstyled" >
            <li><a href="{{url('/dashboard')}}"> <i class="dripicons dripicons-meter"></i><span>{{ __('file.dashboard') }}</span></a></li>
            <?php

                $index_permission_active = $role_has_permissions_list->where('name', 'products-index')->first();

                $category_permission_active = $role_has_permissions_list->where('name', 'category')->first();

                $print_barcode_active = $role_has_permissions_list->where('name', 'print_barcode')->first();

                $stock_count_active = $role_has_permissions_list->where('name', 'stock_count')->first();

                $adjustment_active = $role_has_permissions_list->where('name', 'adjustment')->first();
            ?>
            @if($category_permission_active || $index_permission_active || $print_barcode_active || $stock_count_active || $adjustment_active)
            <li><a href="#product" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-list"></i><span> {{__('file.product')}}s</span><span></a>
            <ul id="product" class="collapse list-unstyled ">
                @if($category_permission_active)
                <li id="category-menu"><a href="{{route('category.index')}}">{{__('file.category')}}</a></li>
                @endif
                @if($category_permission_active)
                <li id="category-department-menu"><a href="{{route('category-department.index')}}">Department</a></li>
                @endif
                @if($index_permission_active)
                <li id="product-list-menu"><a href="{{route('products.index')}}">{{__('file.product_list')}}</a></li>
                <?php
                    $add_permission_active = $role_has_permissions_list->where('name', 'products-add')->first();
                ?>
                @if($add_permission_active)
                <li id="product-create-menu"><a href="{{route('products.create')}}">{{__('file.add_product')}}</a></li>
                @endif
                @endif
                @if($print_barcode_active)
                <li id="printBarcode-menu"><a href="{{route('product.printBarcode')}}">{{__('file.print_barcode')}}</a></li>
                @endif
                @if($adjustment_active)
                <li id="adjustment-list-menu"><a href="{{route('qty_adjustment.index')}}">{{trans('file.Adjustment List')}}</a></li>
                <li id="adjustment-create-menu"><a href="{{route('qty_adjustment.create')}}">{{trans('file.Add Adjustment')}}</a></li>
                @endif
                @if($stock_count_active)
                <li id="stock-count-menu"><a href="{{route('stock-count.index')}}">{{trans('file.Stock Count')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
                $index_permission_active = $role_has_permissions_list->where('name', 'purchases-index')->first();
            ?>
            @if($index_permission_active)
            <li><a href="#purchase" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-card"></i><span> {{trans('file.Purchase')}}s</span></a>
            <ul id="purchase" class="collapse list-unstyled ">
                <li id="purchase-list-menu"><a href="{{route('purchases.index')}}">{{trans('file.Purchase List')}}</a></li>
                <?php
                $add_permission_active = $role_has_permissions_list->where('name', 'purchases-add')->first();
                ?>
                @if($add_permission_active)
                <li id="purchase-create-menu"><a href="{{route('purchases.create')}}">{{trans('file.Add Purchase')}}</a></li>
                <li id="purchase-import-menu"><a href="{{url('purchases/purchase_by_csv')}}">{{trans('file.Import Purchase By CSV')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
                $sale_index_permission_active = $role_has_permissions_list->where('name', 'sales-index')->first();

                $gift_card_permission_active = $role_has_permissions_list->where('name', 'gift_card')->first();

                $coupon_permission_active = $role_has_permissions_list->where('name', 'coupon')->first();

                $delivery_permission_active = $role_has_permissions_list->where('name', 'delivery')->first();

                $sale_add_permission_active = $role_has_permissions_list->where('name', 'sales-add')->first();
            ?>
            @if($sale_index_permission_active || $gift_card_permission_active || $coupon_permission_active || $delivery_permission_active)
            <li><a href="#sale" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-cart"></i><span> {{trans('file.Sale')}}s</span></a>
            <ul id="sale" class="collapse list-unstyled ">
                @if($sale_add_permission_active)
                <li id="sale-list-menu"><a href="{{route('sales.index')}}">{{trans('file.Sale List')}}</a></li>
                <li><a href="{{route('sale.pos')}}">POS</a></li>
                <li id="sale-create-menu"><a href="{{route('sales.create')}}">{{trans('file.Add Sale')}}</a></li>
                <li id="sale-import-menu"><a href="{{url('sales/sale_by_csv')}}">{{trans('file.Import Sale By CSV')}}</a></li>
                @endif

                @if($gift_card_permission_active)
                <li id="gift-card-menu"><a href="{{route('gift_cards.index')}}">{{trans('file.Gift Card List')}}</a> </li>
                @endif
                @if($coupon_permission_active)
                <li id="coupon-menu"><a href="{{route('coupons.index')}}">{{trans('file.Coupon List')}}</a> </li>
                @endif
                <li id="courier-menu"><a href="{{route('couriers.index')}}">{{trans('file.Courier List')}}</a> </li>
                @if($delivery_permission_active)
                <li id="delivery-menu"><a href="{{route('delivery.index')}}">{{trans('file.Delivery List')}}</a></li>
                @endif
                <li id="hire-purchase-menu"><a href="#hire-purchase" aria-expanded="false" data-toggle="collapse">Hire Purchase</a>
                  <ul id="hire-purchase" class="collapse list-unstyled">
                    <li><a href="{{route('hire_purchase.dashboard')}}">Dashboard</a></li>
                    <li><a href="{{route('hire_purchase.index')}}">All Contracts</a></li>
                    <li><a href="{{route('hire_purchase.pending')}}">Pending Installments</a></li>
                    <li><a href="{{route('hire_purchase.overdue')}}">Overdue Installments</a></li>
                  </ul>
                </li>
                  <!-- <li id="customer-list-menu"><a href="{{route('sales.orders')}}">Customer Orders</a></li>
                    <li id="courier-menu"><a href="{{route('ads.index')}}">Ads</a> </li>-->
            </ul>
            </li>
            @endif

            <?php
            $index_permission_active = $role_has_permissions_list->where('name', 'expenses-index')->first();
            ?>
            @if($index_permission_active)
            <li><a href="#expense" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-wallet"></i><span> {{trans('file.Expense')}}s</span></a>
            <ul id="expense" class="collapse list-unstyled ">
                <li id="exp-cat-menu"><a href="{{route('expense_categories.index')}}">{{trans('file.Expense Category')}}</a></li>
                <li id="exp-list-menu"><a href="{{route('expenses.index')}}">{{trans('file.Expense List')}}</a></li>
                <?php
                $add_permission_active = $role_has_permissions_list->where('name', 'expenses-add')->first();
                ?>
                @if($add_permission_active)
                <li><a id="add-expense" href=""> {{trans('file.Add Expense')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
            $approvals_index_active = $role_has_permissions_list->where('name', 'approvals-index')->first();
            ?>
            @if($approvals_index_active)
            <li id="approvals-menu"><a href="{{ route('approvals.index') }}"> <i class="dripicons dripicons-checkmark"></i><span> Approvals</span></a></li>
            @endif
            <?php
            $index_permission_active = $role_has_permissions_list->where('name', 'quotes-index')->first();
            ?>
            @if($index_permission_active)
            <li><a href="#quotation" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-document"></i><span> {{trans('file.Quotation')}}s</span><span></a>
            <ul id="quotation" class="collapse list-unstyled ">
                <li id="quotation-list-menu"><a href="{{route('quotations.index')}}">{{trans('file.Quotation List')}}</a></li>
                <?php
                $add_permission_active = $role_has_permissions_list->where('name', 'quotes-add')->first();
                ?>
                @if($add_permission_active)
                <li id="quotation-create-menu"><a href="{{route('quotations.create')}}">{{trans('file.Add Quotation')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
            $index_permission_active = $role_has_permissions_list->where('name', 'transfers-index')->first();
            ?>
            @if($index_permission_active)
            <li><a href="#transfer" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-export"></i><span> {{trans('file.Transfer')}}s</span></a>
            <ul id="transfer" class="collapse list-unstyled ">
                <li id="transfer-list-menu"><a href="{{route('transfers.index')}}">{{trans('file.Transfer List')}}</a></li>
                <?php
                $add_permission_active = $role_has_permissions_list->where('name', 'transfers-add')->first();
                ?>
                @if($add_permission_active)
                <li id="transfer-create-menu"><a href="{{route('transfers.create')}}">{{trans('file.Add Transfer')}}</a></li>
                <li id="transfer-import-menu"><a href="{{url('transfers/transfer_by_csv')}}">{{trans('file.Import Transfer By CSV')}}</a></li>
                @endif
            </ul>
            </li>
            @endif

            <?php
                $sale_return_index_permission_active = $role_has_permissions_list->where('name', 'returns-index')->first();

                $purchase_return_index_permission_active = $role_has_permissions_list->where('name', 'purchase-return-index')->first();
            ?>
            @if($sale_return_index_permission_active || $purchase_return_index_permission_active)
            <li><a href="#return" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-return"></i><span> {{trans('file.return')}}s</span></a>
            <ul id="return" class="collapse list-unstyled ">
                @if($sale_return_index_permission_active)
                <li id="sale-return-menu"><a href="{{route('return-sale.index')}}">{{trans('file.Sale')}}</a></li>
                @endif
                @if($purchase_return_index_permission_active)
                <li id="purchase-return-menu"><a href="{{route('return-purchase.index')}}">{{trans('file.Purchase')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
            $index_permission_active = $role_has_permissions_list->where('name', 'account-index')->first();

            $money_transfer_permission_active = $role_has_permissions_list->where('name', 'money-transfer')->first();

            $balance_sheet_permission_active = $role_has_permissions_list->where('name', 'balance-sheet')->first();

            $account_statement_permission_active = $role_has_permissions_list->where('name', 'account-statement')->first();

            ?>
            @if($index_permission_active || $balance_sheet_permission_active || $account_statement_permission_active || $money_transfer_permission_active)
            <li class=""><a href="#account" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-briefcase"></i><span>{{trans('file.Accounting')}}</span></a>
            <ul id="account" class="collapse list-unstyled ">
                @if($index_permission_active)
                <li id="account-list-menu"><a href="{{route('accounts.index')}}">{{trans('file.Account List')}}</a></li>
                <li><a id="add-account" href="">{{trans('file.Add Account')}}</a></li>
                @endif
                @if($money_transfer_permission_active)
                <li id="money-transfer-menu"><a href="{{route('money-transfers.index')}}">{{trans('file.Money Transfer')}}</a></li>
                @endif
                @if($balance_sheet_permission_active)
                <li id="balance-sheet-menu"><a href="{{route('accounts.balancesheet')}}">{{trans('file.Balance Sheet')}}</a></li>
                @endif
                @if($account_statement_permission_active)
                <li id="account-statement-menu"><a id="account-statement" href="">{{trans('file.Account Statement')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php
                $department_active = $role_has_permissions_list->where('name', 'department')->first();

                $index_employee_active = $role_has_permissions_list->where('name', 'employees-index')->first();

                $attendance_active = $role_has_permissions_list->where('name', 'attendance')->first();

                $payroll_active = $role_has_permissions_list->where('name', 'payroll')->first();

                $holiday_active = $role_has_permissions_list->where('name', 'holiday')->first();
            ?>

            @if($department_active || $index_employee_active || $attendance_active || $payroll_active || $holiday_active)
            <li class=""><a href="#hrm" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-user-group"></i><span>HRMIS</span></a>
            <ul id="hrm" class="collapse list-unstyled ">
                @if($department_active)
                <li id="dept-menu"><a href="{{route('departments.index')}}">{{trans('file.Department')}}</a></li>
                @endif
                @if($index_employee_active)
                <li id="employee-menu"><a href="{{route('employees.index')}}">{{trans('file.Employee')}}</a></li>
                @endif
                @if($attendance_active)
                <li id="attendance-menu"><a href="{{route('attendance.index')}}">{{trans('file.Attendance')}}</a></li>
                @endif
                @if($payroll_active)
                <li id="payroll-menu"><a href="{{route('payroll.index')}}">{{trans('file.Payroll')}}</a></li>
                @endif
                @if($holiday_active)
                <li id="holiday-menu"><a href="{{route('holidays.index')}}">{{trans('file.Holiday')}}</a></li>
                @endif
            </ul>
            </li>
            @endif
            <?php

                $user_index_permission_active = $role_has_permissions_list->where('name', 'users-index')->first();

                $customer_index_permission_active = $role_has_permissions_list->where('name', 'customers-index')->first();

                $biller_index_permission_active = $role_has_permissions_list->where('name', 'billers-index')->first();

                $supplier_index_permission_active = $role_has_permissions_list->where('name', 'suppliers-index')->first();

            ?>
           <!-- <li><a href="{{url('/shippings')}}"> <i class="dripicons dripicons-meter"></i><span> Shippings</span></a></li>-->
            @if($user_index_permission_active || $customer_index_permission_active || $biller_index_permission_active || $supplier_index_permission_active)
            <li><a href="#people" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-user"></i><span> {{trans('file.People')}}</span></a>
            <ul id="people" class="collapse list-unstyled ">

                @if($user_index_permission_active)
                <li id="user-list-menu"><a href="{{route('user.index')}}">{{trans('file.User List')}}</a></li>
                <?php
                    $user_add_permission_active = $role_has_permissions_list->where('name', 'users-add')->first();
                ?>
                @if($user_add_permission_active)
                <li id="user-create-menu"><a href="{{route('user.create')}}">{{trans('file.Add User')}}</a></li>
                @endif
                @endif

                @if($customer_index_permission_active)
                <!--<li id="customer-list-menu"><a href="{{url('customers/black-list-customers')}}">Black List Customers</a></li>-->
                <li id="customer-list-menu"><a href="{{route('customer.index')}}">{{trans('file.Customer List')}}</a></li>
              
                <?php
                    $customer_add_permission_active = $role_has_permissions_list->where('name', 'customers-add')->first();
                ?>
                @if($customer_add_permission_active)
                <li id="customer-create-menu"><a href="{{route('customer.create')}}">{{trans('file.Add Customer')}}</a></li>
                @endif
                @endif

                @if($biller_index_permission_active)
                <li id="biller-list-menu"><a href="{{route('biller.index')}}">{{trans('file.Biller List')}}</a></li>
                <?php
                    $biller_add_permission_active = $role_has_permissions_list->where('name', 'billers-add')->first();
                ?>
                @if($biller_add_permission_active)
                <li id="biller-create-menu"><a href="{{route('biller.create')}}">{{trans('file.Add Biller')}}</a></li>
                @endif
                @endif

                @if($supplier_index_permission_active)
                <li id="supplier-list-menu"><a href="{{route('supplier.index')}}">{{trans('file.Supplier List')}}</a></li>
                <?php
                    $supplier_add_permission_active = $role_has_permissions_list->where('name', 'suppliers-add')->first();
                ?>
                @if($supplier_add_permission_active)
                <li id="supplier-create-menu"><a href="{{route('supplier.create')}}">{{trans('file.Add Supplier')}}</a></li>
                @endif
                @endif
            </ul>
            </li>
            @endif

            <?php

                $profit_loss_active = $role_has_permissions_list->where('name', 'profit-loss')->first();

                $best_seller_active = $role_has_permissions_list->where('name', 'best-seller')->first();

                $warehouse_report_active = $role_has_permissions_list->where('name', 'warehouse-report')->first();

                $warehouse_stock_report_active = $role_has_permissions_list->where('name', 'warehouse-stock-report')->first();

                $product_report_active = $role_has_permissions_list->where('name', 'product-report')->first();

                $daily_sale_active = $role_has_permissions_list->where('name', 'daily-sale')->first();

                $monthly_sale_active = $role_has_permissions_list->where('name', 'monthly-sale')->first();

                $daily_purchase_active = $role_has_permissions_list->where('name', 'daily-purchase')->first();

                $monthly_purchase_active = $role_has_permissions_list->where('name', 'monthly-purchase')->first();

                $purchase_report_active = $role_has_permissions_list->where('name', 'purchase-report')->first();

                $sale_report_active = $role_has_permissions_list->where('name', 'sale-report')->first();

                $sale_report_chart_active = $role_has_permissions_list->where('name', 'sale-report-chart')->first();

                $payment_report_active = $role_has_permissions_list->where('name', 'payment-report')->first();

                $product_expiry_report_active = $role_has_permissions_list->where('name', 'product-expiry-report')->first();

                $product_qty_alert_active = $role_has_permissions_list->where('name', 'product-qty-alert')->first();

                $dso_report_active = $role_has_permissions_list->where('name', 'dso-report')->first();

                $user_report_active = $role_has_permissions_list->where('name', 'user-report')->first();

                $customer_report_active = $role_has_permissions_list->where('name', 'customer-report')->first();

                $supplier_report_active = $role_has_permissions_list->where('name', 'supplier-report')->first();

                $due_report_active = $role_has_permissions_list->where('name', 'due-report')->first();

                $supplier_due_report_active = $role_has_permissions_list->where('name', 'supplier-due-report')->first();

                // $department_report_active = $role_has_permissions_list->where('name', 'department-report')->first();

            ?>
            <!-- incase needed add the permission -->
            @if($profit_loss_active || $best_seller_active || $warehouse_report_active || $warehouse_stock_report_active || $product_report_active || $daily_sale_active || $monthly_sale_active || $daily_purchase_active || $monthly_purchase_active || $purchase_report_active || $sale_report_active || $sale_report_chart_active || $payment_report_active || $product_expiry_report_active || $product_qty_alert_active || $dso_report_active || $user_report_active || $customer_report_active || $supplier_report_active || $due_report_active || $supplier_due_report_active )
            <li><a href="{{ route('report.dashboard') }}"> <i class="dripicons dripicons-document-remove"></i><span>Reports</span></a></li>
            @endif
            @if(!config('database.connections.saleprosaas_landlord') && 1 == 0)
            <li><a href="{{url('addon-list')}}" id="addon-list"> <i class="dripicons dripicons-flag"></i><span>{{trans('file.Addons')}}</span></a></li>
            @if (\Schema::hasColumn('products', 'woocommerce_product_id'))
                <li><a href="{{route('woocommerce.index')}}"> <i class="fa fa-wordpress"></i><span>WooCommerce</span></a></li>
            @endif
            @if(in_array('ecommerce',explode(',',$general_setting->modules)))
            <li><a href="#ecommerce" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-shopping-bag"></i><span>{{trans('file.ecommerce')}}</span></a>
                <ul id="ecommerce" class="collapse list-unstyled ">
                    @include('ecommerce::backend.layout.sidebar-menu')
                </ul>
            </li>
            @endif
            @endif
            <li><a href="#setting" aria-expanded="false" data-toggle="collapse"> <i class="dripicons dripicons-gear"></i><span>{{trans('file.settings')}}</span></a>
                <ul id="setting" class="collapse list-unstyled ">
                    <?php
                        $all_notification_permission_active = $role_has_permissions_list->where('name', 'all_notification')->first();

                        $send_notification_permission_active = $role_has_permissions_list->where('name', 'send_notification')->first();

                        $warehouse_permission_active = $role_has_permissions_list->where('name', 'warehouse')->first();

                        $customer_group_permission_active = $role_has_permissions_list->where('name', 'customer_group')->first();

                        $brand_permission_active = $role_has_permissions_list->where('name', 'brand')->first();

                        $unit_permission_active = $role_has_permissions_list->where('name', 'unit')->first();

                        $currency_permission_active = $role_has_permissions_list->where('name', 'currency')->first();

                        $tax_permission_active = $role_has_permissions_list->where('name', 'tax')->first();

                        $general_setting_permission_active = $role_has_permissions_list->where('name', 'general_setting')->first();

                        $backup_database_permission_active = $role_has_permissions_list->where('name', 'backup_database')->first();

                        $mail_setting_permission_active = $role_has_permissions_list->where('name', 'mail_setting')->first();

                        $sms_setting_permission_active = $role_has_permissions_list->where('name', 'sms_setting')->first();

                        $create_sms_permission_active = $role_has_permissions_list->where('name', 'create_sms')->first();

                        $pos_setting_permission_active = $role_has_permissions_list->where('name', 'pos_setting')->first();

                        $hrm_setting_permission_active = $role_has_permissions_list->where('name', 'hrm_setting')->first();

                        $reward_point_setting_permission_active = $role_has_permissions_list->where('name', 'reward_point_setting')->first();

                        $discount_plan_permission_active = $role_has_permissions_list->where('name', 'discount_plan')->first();

                        $discount_permission_active = $role_has_permissions_list->where('name', 'discount')->first();

                        $custom_field_permission_active = $role_has_permissions_list->where('name', 'custom_field')->first();
                    ?>
                    @php
                    $is_admin = \Auth::user()->roles->contains(fn($r) => $r->id <= 2);
                    @endphp

                    @if($is_admin)
                    <li id="role-menu"><a href="{{route('role.index')}}">{{trans('file.Role Permission')}}</a></li>
                    @endif
                    @if($custom_field_permission_active)
                    <li id="custom-field-list-menu"><a href="{{route('custom-fields.index')}}">{{trans('file.Custom Field List')}}</a></li>
                    @endif
                  
                    @if($discount_plan_permission_active)
                    <li id="discount-plan-list-menu"><a href="{{route('discount-plans.index')}}">{{trans('file.Discount Plan')}}</a></li>
                    @endif
                    @if($discount_permission_active)
                    <li id="discount-list-menu"><a href="{{route('discounts.index')}}">{{trans('file.Discount')}}</a></li>
                    @endif
                    @if($all_notification_permission_active)
                    <li id="notification-list-menu">
                        <a href="{{route('notifications.index')}}">{{trans('file.All Notification')}}</a>
                    </li>
                    @endif
                    @if($send_notification_permission_active)
                    <li id="notification-menu">
                    <a href="" id="send-notification">{{trans('file.Send Notification')}}</a>
                    </li>
                    @endif
                    @if($warehouse_permission_active)
                    <li id="warehouse-menu"><a href="{{route('warehouse.index')}}">{{trans('file.Warehouse')}}</a></li>
                    @endif
                    @if($customer_group_permission_active)
                    <li id="customer-group-menu"><a href="{{route('customer_group.index')}}">{{trans('file.Customer Group')}}</a></li>
                    @endif
                    @if($brand_permission_active)
                    <li id="brand-menu"><a href="{{route('brand.index')}}">{{trans('file.Brand')}}/Make</a></li>
                    @endif
                    @if($unit_permission_active)
                    <li id="unit-menu"><a href="{{route('unit.index')}}">{{trans('file.Unit')}}</a></li>
                    @endif
                    @if($currency_permission_active)
                    <li id="currency-menu"><a href="{{route('currency.index')}}">{{trans('file.Currency')}}</a></li>
                    @endif
                    @if($tax_permission_active)
                    <li id="tax-menu"><a href="{{route('tax.index')}}">{{trans('file.Tax')}}</a></li>
                    @endif
                    <li id="user-menu"><a href="{{route('user.profile', ['id' => Auth::id()])}}">{{trans('file.User Profile')}}</a></li>
                    @if($create_sms_permission_active)
                    <li id="create-sms-menu"><a href="{{route('setting.createSms')}}">{{trans('file.Create SMS')}}</a></li>
                    @endif
                    @if($backup_database_permission_active)
                    <li><a href="{{route('setting.backup')}}">{{trans('file.Backup Database')}}</a></li>
                    @endif
                    @if($general_setting_permission_active)
                    <li id="general-setting-menu"><a href="{{route('setting.general')}}">{{trans('file.General Setting')}}</a></li>
                    @endif
                    @if($mail_setting_permission_active)
                    <li id="mail-setting-menu"><a href="{{route('setting.mail')}}">{{trans('file.Mail Setting')}}</a></li>
                    @endif
                    @if($reward_point_setting_permission_active)
                    <li id="reward-point-setting-menu"><a href="{{route('setting.rewardPoint')}}">{{trans('file.Reward Point Setting')}}</a></li>
                    @endif
                    @if($sms_setting_permission_active)
                    <li id="sms-setting-menu"><a href="{{route('setting.sms')}}">{{trans('file.SMS Setting')}}</a></li>
                    @endif
                    @if($pos_setting_permission_active)
                    <li id="pos-setting-menu"><a href="{{route('setting.pos')}}">POS {{trans('file.settings')}}</a></li>
                    @endif
                    @if($hrm_setting_permission_active)
                    <li id="hrm-setting-menu"><a href="{{route('setting.hrm')}}"> {{trans('file.HRM Setting')}}</a></li>
                    @endif
                </ul>
            </li>
            @if((!Auth::user()->roles->contains(fn($r) => $r->id == 5)) && 1 == 0)
            <li><a target="_blank" href="{{url('/documentation')}}"> <i class="dripicons dripicons-information"></i><span>{{trans('file.Documentation')}}</span></a></li>
            @endif
        </ul>
